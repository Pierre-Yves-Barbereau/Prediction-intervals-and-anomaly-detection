# Databricks notebook source
# MAGIC %run /Tools/library/CFM

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/IC_functions

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/preprocessing

# COMMAND ----------

lib_instance = Cfm()

# COMMAND ----------

#dbutils.widgets.removeAll()

# COMMAND ----------

# ["EncPDV", "DecPDV", "EncUP", "DecUP", "DecPet", "DecTaxAlc", "DecTaxPet", "EncRist", "EncRprox"]

# COMMAND ----------

#Variables widget
groupe = lib_instance.define_widget("groupe") 
confidence = float(lib_instance.define_widget('confidence'))/100

val_size = int(lib_instance.define_widget("val_size")) #365
cal_size = int(lib_instance.define_widget("cal_size")) # 365
#PAth notebooks
path_notebook_preproc_preprocessing = lib_instance.define_widget("path_notebook_preproc_preprocessing") #'/Notebooks/Shared/Industrialisation/PrepocFolder/Preprocessing'

# COMMAND ----------

#import libraries
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from lightgbm import LGBMRegressor
import math
import copy
from datetime import timedelta
from jours_feries_france import JoursFeries
import warnings
from sklearn import preprocessing
warnings.filterwarnings("ignore")

# COMMAND ----------

dataloader = Dataloader(path_notebook_preproc_preprocessing = path_notebook_preproc_preprocessing)
df_train, df_predict = dataloader.load_train_predict(groupe = groupe)

# COMMAND ----------

preproc = Preprocessing()
df_predict = preproc.set_DT_VALR(df_predict,df_train)
df_predict["DT_VALR"] = pd.to_datetime(df_predict["DT_VALR"])
preproc.set_df(df_predict)
df_predict  = preproc.label()
preproc.set_df(df_train)
df_train  = preproc.label()
letrain = preprocessing.LabelEncoder()
lepredict = preprocessing.LabelEncoder()
df_train["label"] = letrain.fit_transform(df_train["label"])
df_predict["label"] = lepredict.fit_transform(df_predict["label"])
df_predict = df_predict.drop(["DT_VALR"],axis = 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Predict

# COMMAND ----------

#dev temporaire en cas de modification du notebook IC_functions

# COMMAND ----------

alphas = [np.round((1-confidence)/2,2),np.round(1-(1-confidence)/2,2)]

# COMMAND ----------

ci_predict = Conformal_Inference(alphas = alphas,val_size = val_size,cal_size = cal_size)
ci_predict.fit(df_train)
pred_down,pred_up,pred_median = ci_predict.asymetric_conformal_IC(df_predict,plot = True)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Test

# COMMAND ----------

for groupe in ["EncPDV", "DecPDV", "EncUP", "DecUP", "DecPet", "DecTaxAlc", "DecTaxPet", "EncRist", "EncRprox"]:
  dataloader = Dataloader(path_notebook_preproc_preprocessing = path_notebook_preproc_preprocessing)
  df_train, df_predict = dataloader.load_train_predict(groupe = groupe)
  print(groupe)
  preproc = Preprocessing()
  df_predict = preproc.set_DT_VALR(df_predict,df_train)
  df_predict["DT_VALR"] = pd.to_datetime(df_predict["DT_VALR"])
  preproc.set_df(df_predict)
  df_predict  = preproc.label()
  preproc.set_df(df_train)
  df_train  = preproc.label()
  letrain = preprocessing.LabelEncoder()
  lepredict = preprocessing.LabelEncoder()
  df_train["label"] = letrain.fit_transform(df_train["label"])
  df_predict["label"] = lepredict.fit_transform(df_predict["label"])
  df_predict = df_predict.drop(["DT_VALR"],axis = 1)

  ci_test = Conformal_Inference(alphas,cal_size = cal_size,val_size = val_size,test_size = 365,mode = "test")
  ci_test.fit(df_train)
  ci_test.asymetric_conformal_IC(plot = True)

# COMMAND ----------



# COMMAND ----------

#pip install scikit-garden

# COMMAND ----------

#pip install quantile-forest

# COMMAND ----------

from quantile_forest import RandomForestQuantileRegressor
rfqr = RandomForestQuantileRegressor(random_state=0)
rfqr.fit(df_train.Drop(["Valeur"],axis = 1), df_train["Valeur"])
y_mean = rfqr.predict(de_predict,0.8)

# COMMAND ----------

from skgarden import RandomForestQuantileRegressor


# COMMAND ----------

pip install scikit-garden