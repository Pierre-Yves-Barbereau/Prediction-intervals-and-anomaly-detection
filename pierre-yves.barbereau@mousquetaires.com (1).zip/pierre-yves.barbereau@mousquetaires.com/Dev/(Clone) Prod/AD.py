# Databricks notebook source
# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/preprocessing

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/AD_functions

# COMMAND ----------

from sklearn.svm import OneClassSVM
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from sklearn.ensemble import GradientBoostingRegressor
from lightgbm import LGBMRegressor
import xgboost as xgb

# COMMAND ----------

#dbutils.widgets.removeAll()

# COMMAND ----------

groupe = lib_instance.define_widget("groupe")
confidence = float(lib_instance.define_widget('confidence'))/100

path_notebook_preproc_preprocessing = lib_instance.define_widget("path_notebook_preproc_preprocessing") #'/Notebooks/Shared/Industrialisation/PrepocFolder/Preprocessing'


# COMMAND ----------

preproc = preprocessing(path_notebook_preproc_preprocessing = path_notebook_preproc_preprocessing)
df_train = preproc.load_train(groupe = groupe)

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/AD_functions

# COMMAND ----------

AD = Anomaly_Detection(confidence =  confidence)
AD.fit_predict(df_train,plot = True)


# COMMAND ----------

AD.df

# COMMAND ----------

AD.plot("Xgb")

# COMMAND ----------

AD.plot("Lgbm")

# COMMAND ----------

AD.plot("Gb")

# COMMAND ----------

df_train