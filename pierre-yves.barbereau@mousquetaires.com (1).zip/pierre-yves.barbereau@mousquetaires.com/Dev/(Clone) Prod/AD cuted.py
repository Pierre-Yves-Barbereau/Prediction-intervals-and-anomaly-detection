# Databricks notebook source
# MAGIC %run /Tools/library/CFM

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/preprocessing

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/AD_functions

# COMMAND ----------



# COMMAND ----------

lib_instance = Cfm()

# COMMAND ----------

from sklearn.svm import OneClassSVM
from sklearn.ensemble import IsolationForest
from sklearn.neighbors import LocalOutlierFactor
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from sklearn.ensemble import GradientBoostingRegressor
from lightgbm import LGBMRegressor
import xgboost as xgb
import warnings
warnings.filterwarnings("ignore")

# COMMAND ----------

groupe = lib_instance.define_widget("groupe")
confidence = float(lib_instance.define_widget('confidence'))/100
path_notebook_preproc_preprocessing = lib_instance.define_widget("path_notebook_preproc_preprocessing") #'/Notebooks/Shared/Industrialisation/PrepocFolder/Preprocessing'

# COMMAND ----------

dataloader = Dataloader(path_notebook_preproc_preprocessing = path_notebook_preproc_preprocessing)
df_train,df_predict = dataloader.load_train_predict(groupe = groupe)

# COMMAND ----------

preproc = preprocessing()
preproc.set_df(df_train)
df_labelised = preproc.label()

# COMMAND ----------

ADC = Anomaly_Detection_cuted()
ADC.fit_predict(df_labelised,plot = True)

# COMMAND ----------

