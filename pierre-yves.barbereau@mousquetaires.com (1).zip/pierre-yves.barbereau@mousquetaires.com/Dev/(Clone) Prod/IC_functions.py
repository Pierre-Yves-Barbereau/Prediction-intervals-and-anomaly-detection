# Databricks notebook source
class Conformal_Inference():
  def __init__(self,alphas, cal_size , val_size ,test_size = 0,mode = "normal"):
    self.alphas = alphas
    self.confidence = self.alphas[1] - self.alphas[0]
    self.cal_size = cal_size
    self.val_size = val_size
    self.test_size = test_size
    self.fitted = False
    self.mode = mode
    self.adaptative = False
    model_down_set = []
    model_up_set = []
    model_median_set = []
    #GradientBoosting init
    model_down_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[0],n_estimators = 1000,
                                                      learning_rate = 0.01))
    model_up_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[1],n_estimators = 1000,
                                                    learning_rate = 0.01))
    model_median_set.append(GradientBoostingRegressor(loss="quantile", alpha=0.5,n_estimators = 1000,
                                                    learning_rate = 0.01))
    
    #LGBM init
    model_down_set.append(LGBMRegressor(alpha=self.alphas[0],  objective='quantile'))
    model_up_set.append(LGBMRegressor(alpha=self.alphas[1],  objective='quantile'))
    model_median_set.append(LGBMRegressor(alpha=0.5,  objective='quantile'))

    #LSTM init
    """
    To do here, cf LSTM_VAE dev notebook
    """
    #Enbpi Init:
    #model_down_set.append(EnbPi(alpha = ,n_bootstrap = 100))

    self.model_down_set = model_down_set
    self.model_up_set = model_up_set
    self.model_median_set = model_median_set

    if len(self.model_down_set) != (len(self.model_up_set)):
      print(" len(self.model_down_set != len(self.model_up_set))")    

  def fit(self,df_train):
    """
    Fit the model
    """
    self.target_train = df_train["Valeur"]
    self.df_train = df_train

    if self.mode == "normal" or self.adaptative:
      self.train_cal_val_split()
    if self.mode == "test" and not self.adaptative:
      self.train_cal_val_test_split()
      print("len(self.X_test) = ",len(self.X_test))
      print("len(self.y_test) = ",len(self.y_test))
    for i in range(len(self.model_down_set)):
      self.model_down_set[i] = self.model_down_set[i].fit(self.X_train,self.y_train)
      self.model_up_set[i] = self.model_up_set[i].fit(self.X_train,self.y_train)
      self.model_median_set[i] = self.model_median_set[i].fit(self.X_train,self.y_train)
    self.predict_cal_val()
    print("len(self.X_cal) = ",len(self.X_cal))
    print("len(self.y_cal) = ",len(self.y_cal))
    print("len(self.X_val) = ",len(self.X_val))
    print("len(self.y_val) = ",len(self.y_val))
    self.fitted = True

  def train_cal_val_split(self):
    "split data into train, calibration and validation set, used in normal mode"
    self.X_train, self.X_val , self.y_train, self.y_val = train_test_split(self.df_train, self.target_train,test_size = self.val_size,shuffle = False)
    self.X_train, self.X_cal , self.y_train, self.y_cal = train_test_split(self.X_train, self.y_train ,test_size = self.cal_size,shuffle = False)
    self.xX_train = self.X_train["DT_VALR"]
    self.X_train = self.X_train.drop(["DT_VALR","Valeur"],axis = 1)
    self.xX_cal = self.X_cal["DT_VALR"]
    self.xX_val = self.X_val["DT_VALR"]
    self.X_cal = self.X_cal.drop(["DT_VALR","Valeur"], axis = 1)
    self.X_val = self.X_val.drop(["DT_VALR","Valeur"], axis = 1)
    #return self.xX_train, self.xX_cal, self.xX_val, self.xX_test, self.X_train, self.X_cal, self.X_val, self.X_test, self.y_train, self.y_cal, self.y_val, self.y_test
    self.y_train = list(self.y_train)
    self.y_cal = list(self.y_cal)
    self.y_val = list(self.y_val)
    self.X_calval = pd.concat([self.X_cal,self.X_val], sort = False)
    self.y_calval = list(self.y_cal) + list(self.y_val)
    print("train_size = ", self.X_train.shape[0])

  def train_cal_val_test_split(self):
    """
    split data into train, calibration validation and test set, used in test mode
    return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_val,self.X_val, self.y_val, self.xX_test, self.X_test, self.y_test
    """
    self.X_train, self.X_test , self.y_train, self.y_test = train_test_split(self.df_train, self.target_train,test_size = self.test_size,shuffle = False)
    self.X_train, self.X_val , self.y_train, self.y_val = train_test_split(self.X_train, self.y_train,test_size = self.val_size,shuffle = False)
    self.X_train, self.X_cal , self.y_train, self.y_cal = train_test_split(self.X_train, self.y_train,test_size = self.cal_size,shuffle = False)
    self.xX_train = self.X_train["DT_VALR"]
    self.X_train = self.X_train.drop(["DT_VALR","Valeur"],axis = 1)
    self.xX_cal = self.X_cal["DT_VALR"]
    self.xX_val = self.X_val["DT_VALR"]
    self.X_cal = self.X_cal.drop(["DT_VALR","Valeur"], axis = 1)
    self.X_val = self.X_val.drop(["DT_VALR","Valeur"], axis = 1)
    self.xX_test = self.X_test["DT_VALR"]
    self.X_test = self.X_test.drop(["DT_VALR","Valeur"], axis = 1)
    self.y_train = list(self.y_train)
    self.y_cal = list(self.y_cal)
    self.y_val = list(self.y_val)
    self.X_calval = pd.concat([self.X_cal,self.X_val], sort = False)
    self.y_calval = list(self.y_cal) + list(self.y_val)
    print("train_size = ", self.X_train.shape[0])
    return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_val,self.X_val, self.y_val, self.xX_test, self.X_test, self.y_test

  def predict_cal_val(self):
    "predict on calibration and validation set"
    #self.model_down_set = []
    #self.model_up_set = []
    pred_down_cal_set = []
    pred_up_cal_set = []
    pred_median_cal_set = []
    pred_down_val_set = []
    pred_up_val_set = []
    pred_median_val_set = []
    pred_down_calval_set = []
    pred_up_calval_set = []
    pred_median_calval_set = []
                                               
    for i in range(len(self.model_down_set)):
      pred_down_cal_set.append(self.model_down_set[i].predict(self.X_cal))
      pred_up_cal_set.append(self.model_up_set[i].predict(self.X_cal))
      pred_median_cal_set.append(self.model_median_set[i].predict(self.X_cal))
      pred_down_val_set.append(self.model_down_set[i].predict(self.X_val))
      pred_up_val_set.append(self.model_up_set[i].predict(self.X_val))
      pred_median_val_set.append(self.model_median_set[i].predict(self.X_val))
      pred_down_calval_set.append(self.model_down_set[i].predict(self.X_calval))
      pred_up_calval_set.append(self.model_up_set[i].predict(self.X_calval))
      pred_median_calval_set.append(self.model_median_set[i].predict(self.X_calval))

    #Aggregation
    self.ag_up = aggregation_IC(pred_up_calval_set,self.y_calval)
    self.ag_down = aggregation_IC(pred_down_calval_set,self.y_calval)
    self.ag_median = aggregation_IC(pred_median_calval_set,self.y_calval)
    self.ag_down.faboa(self.alphas[0])
    self.ag_up.faboa(self.alphas[1])
    self.ag_median.faboa(0.5)
    self.pred_down_cal = np.dot(self.ag_down.pi_t_j[-1],[pred_down_cal_set[i] for i in range(len(pred_down_cal_set))])
    self.pred_up_cal = np.dot(self.ag_up.pi_t_j[-1],[pred_up_cal_set[i] for i in range(len(pred_up_cal_set))])
    self.pred_median_cal = np.dot(self.ag_median.pi_t_j[-1],[pred_median_cal_set[i] for i in range(len(pred_median_cal_set))])
    self.pred_down_val = np.dot(self.ag_down.pi_t_j[-1],[pred_down_val_set[i] for i in range(len(pred_down_val_set))])
    self.pred_up_val = np.dot(self.ag_up.pi_t_j[-1],[pred_up_val_set[i] for i in range(len(pred_up_val_set))])
    self.pred_median_val = np.dot(self.ag_median.pi_t_j[-1],[pred_median_val_set[i] for i in range(len(pred_median_val_set))])
    """
    #Conformity score conformal inference
    self.conformity_score = self.f_conformity_score(self.pred_down_cal,self.pred_up_cal,self.y_cal)
    self.conformity_score_down = self.f_conformity_score_down(self.pred_down_cal,self.y_cal)
    self.conformity_score_up = self.f_conformity_score_up(self.pred_up_cal,self.y_cal)
    """

  def predict_test(self,X):
    "predict on predict_set"
    pred_down_set = []
    pred_up_set = []
    pred_median_set = []
    for _ in range(len(self.model_down_set)):
      pred_down_set.append(self.model_down_set[_].predict(X))
      pred_up_set.append(self.model_up_set[_].predict(X))
      pred_median_set.append(self.model_median_set[_].predict(X))
    pred_down = np.dot(self.ag_down.pi_t_j[-1],[pred_down_set[i] for i in range(len(pred_down_set))])
    pred_up = np.dot(self.ag_up.pi_t_j[-1],[pred_up_set[i] for i in range(len(pred_up_set))])
    pred_median = np.dot(self.ag_median.pi_t_j[-1],[pred_median_set[i] for i in range(len(pred_median_set))])
    return(pred_down,pred_up,pred_median)

  def asymetric_conformal_IC(self,X_predict = None,plot = False):
    """
    Compute Asymetric Conformal Inference for predict set,
    X_predict = None,plot = False
    return self.pred_down_predict_asymetric_conformal,self.pred_up_predict_asymetric_conformal
    """
    self.X_predict = X_predict
    if self.mode == "test":
      self.X_predict = self.X_test
    self.pred_down_predict,self.pred_up_predict,self.pred_median_predict = self.predict_test(self.X_predict)
    self.betas = np.arange(0,1,0.0001)
    try:
      alpha_star_down = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_down(self.pred_down_cal,self.pred_down_val,self.y_cal,self.y_val,alpha = b) < self.alphas[0])])
      alpha_star_up = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_up(self.pred_up_cal,self.pred_up_val,self.y_cal,self.y_val,alpha = b) < 1 - self.alphas[1])])
      alpha_star_median = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_median(self.pred_median_cal,self.pred_median_val,self.y_cal,self.y_val,alpha = b) < 0.5)])
      self.pred_down_predict_asymetric_conformal = self.pred_down_predict - np.quantile(self.f_conformity_score_down(self.pred_down_cal,self.y_cal),1-alpha_star_down)
      self.pred_up_predict_asymetric_conformal = self.pred_up_predict + np.quantile(self.f_conformity_score_up(self.pred_up_cal,self.y_cal),1-alpha_star_up)
      self.pred_median_predict_asymetric_conformal = self.pred_median_predict - np.quantile(self.f_conformity_score_median(self.pred_median_cal,self.y_cal),1-alpha_star_median)
    except:
      model = IC_model(self.alphas)
      model.fit(self.df_train)
      return(model.predict(self.X_predict,plot = True))


    if plot :
      #Show plot pred test 
      if self.mode == "normal":
        fig = go.Figure()
        fig.add_trace(go.Scatter( y=self.pred_up_predict_asymetric_conformal,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))

        fig.add_trace(go.Scatter( y=self.pred_down_predict_asymetric_conformal,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter( y=self.pred_median_predict_asymetric_conformal,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        
        fig.update_layout(title = f"{int(np.round(100*self.confidence))}% Asymetric conformal prediction interval")
        fig.show()

      if self.mode == "test":
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=self.xX_test, y=self.y_test,
                      mode='lines',
                      name=f'y_true',
                      line=dict(
                          color='rgb(0,0, 256)',
                          width=1),
                      showlegend = True))
                
        fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_up_predict_asymetric_conformal,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))

        fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_down_predict_asymetric_conformal,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_median_predict_asymetric_conformal,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        
        error = (np.sum(self.y_test<self.pred_down_predict_asymetric_conformal) + np.sum(self.y_test>self.pred_up_predict_asymetric_conformal))/len(self.y_test)
        fig.update_traces(mode='lines')
        fig.update_layout(title = f"Test : {1-error}% asymetric conformal prediction test")                      
        fig.show()
    return self.pred_down_predict_asymetric_conformal,self.pred_up_predict_asymetric_conformal, self.pred_median_predict_asymetric_conformal

  def f_conformity_score(self,pred_down_cal,pred_up_cal,y_cal):
    """
    Compute the symetric conformity score
    """
    return np.max([pred_down_cal-y_cal,y_cal-pred_up_cal],axis = 0)
  
  def f_conformity_score_down(self,pred_down_cal,y_cal):
    """
    Compute the asymetric conformity score for down bound
    """
    return [pred_down_cal-y_cal]

  def f_conformity_score_up(self,pred_up_cal,y_cal):
    """
    Compute the asymetric conformity score for upper bound
    """
    return [y_cal-pred_up_cal]
  
  def f_conformity_score_median(self,pred_median_cal,y_cal):
    """
    Compute the asymetric conformity score for upper bound
    """
    return [pred_median_cal-y_cal]
  
  def f_miscoverage_rate(self,pred_down_cal,pred_up_cal,pred_down_val,pred_up_val,y_cal,y_val,alpha):
    """
    Compute the miscoverage rate
    """
    csq = np.quantile(self.f_conformity_score(pred_down_cal,pred_up_cal,y_cal),1-alpha)
    return(np.sum(np.max([pred_down_val-y_val,y_val-pred_up_val],axis = 0)>csq)/len(y_val))

  def f_miscoverage_rate_down(self,pred_down_cal,pred_down_val,y_cal,y_val,alpha):
    """
    Compute the asymetric miscoverage rate for down bound
    """
    csq_low = np.quantile(self.f_conformity_score_down(pred_down_cal,y_cal),1-alpha)
    return(np.sum((pred_down_val-y_val)>csq_low)/len(y_val))
  
  def f_miscoverage_rate_median(self,pred_median_cal,pred_median_val,y_cal,y_val,alpha):
    """
    Compute the asymetric miscoverage rate for median bound
    """
    csq_median = np.quantile(self.f_conformity_score_median(pred_median_cal,y_cal),1-alpha)
    return(np.sum((pred_median_val-y_val)>csq_median)/len(y_val))

  def f_miscoverage_rate_up(self,pred_up_cal,pred_up_val,y_cal,y_val,alpha):
    """
    Compute the asymetric miscoverage rate for upper bound
    """
    csq_up = np.quantile(self.f_conformity_score_up(pred_up_cal,y_cal),1 - alpha)
    return(np.sum((y_val-pred_up_val)>csq_up)/len(y_val))

# COMMAND ----------

class aggregation_IC():
  import math
  def __init__(self,pred_set,y_true):
    from sklearn.preprocessing import MinMaxScaler
    self.scaler = MinMaxScaler()
    self.scaler.fit(pred_set)
    self.normalised = False
    self.coef_factor = np.max(y_true)
    self.pred_set = self.scaler.transform(pred_set)
    self.y = list(y_true)
    self.J = len(pred_set)
    self.len_y = len(y_true)
    #self.normalisation()

  def normalisation(self):
    if self.normalised == False:
      self.normalisation_coef = np.max(self.y)
      self.y = self.y/self.normalisation_coef
      self.pred_set = [pred/self.normalisation_coef for pred in self.pred_set]
      self.normalised = True

  def denormalisation(self):
    if self.normalised == True:
      self.y = self.y*self.normalisation_coef
      self.pred_set = self.pred_set*self.normalisation_coef
      self.normalised = False

  def pinball_loss(self,pred,true,alpha):
    return (alpha*(true-pred)*(true-pred >= 0) + (alpha-1)*(true-pred)*(true-pred < 0))
  
  def mse(self,pred,true,alpha = None):
    return(math.sqrt(np.sum([(t-p)**2 for t,p in zip(true,pred)])))

  def boa(self,eta,alpha): 
    self.eta_boa = eta
    self.pi_t_j = [np.ones(self.J)/self.J]
    self.l_t_j = []
    self.epi = None
    for t in range(self.len_y):
      self.epi = np.dot(self.pi_t_j[-1],[self.loss(self.pred_set[i][t],self.y[t],alpha = alpha) for i in range(self.J)])
      self.l_t_j.append([self.loss(self.pred_set[i][t],self.y[t],alpha = alpha) - self.epi for i in range(self.J)])
      self.regularisation = np.sum([np.exp(-self.eta_boa*self.l_t_j[-1][j]*(1 + self.eta_boa*self.l_t_j[-1][j]))*self.pi_t_j[-1][j] for j in range(self.J)])
      self.pi_t_j.append([np.exp(-self.eta_boa*self.l_t_j[-1][j]*(1 + self.eta_boa*self.l_t_j[-1][j]))*self.pi_t_j[-1][j] / self.regularisation for j in range(self.J)])
      return self.pi_t_j[-1]

  def faboa(self,alpha): 
    np.seterr(divide='ignore', invalid='ignore')
    self.pi_t_j = [np.ones(self.J)/self.J]
    self.L_t_j = [np.zeros(self.J)]
    self.n_t_j = [np.zeros(self.J)]
    self.E_t_j = 2*np.ones(self.J)
    self.l_t_j = []
    self.epi = None
    for t in range(self.len_y):
      self.epi = np.dot(self.pi_t_j[-1],[self.pinball_loss(self.pred_set[i][t],self.y[t],alpha = alpha) for i in range(self.J)])
      self.l_t_j.append([self.pinball_loss(self.pred_set[i][t],self.y[t],alpha = alpha) - self.epi for i in range(self.J)])
      self.L_t_j.append([self.L_t_j[-1][j] + self.l_t_j[-1][j]*(1 + self.n_t_j[-1][j]*self.l_t_j[-1][j])/2 + self.E_t_j[j]*(self.n_t_j[-1][j]*self.l_t_j[-1][j]>0.5) for j in range(self.J)])
      for j in range(self.J):
        if self.l_t_j[-1][j] > self.E_t_j[j]:
          k=0
          while self.l_t_j[-1][j] <= 2**k:
            k=k+1
          self.E_t_j[j] = 2**(k+1)
      self.n_t_j.append([np.min([1/self.E_t_j[j], math.sqrt(math.log(1/self.pi_t_j[0][j])/np.sum([self.l_t_j[s][j]**2 for s in range(t)]))]) for j in range(self.J)])
      self.regularisation = np.sum([np.exp(-self.n_t_j[-1][j]*self.l_t_j[-1][j]*(1 + self.n_t_j[-1][j]*self.l_t_j[-1][j]))*self.pi_t_j[-1][j] for j in range(self.J)])
      self.pi_t_j.append([np.exp(-self.n_t_j[-1][j]*self.l_t_j[-1][j]*(1 + self.n_t_j[-1][j]*self.l_t_j[-1][j]))*self.pi_t_j[-1][j] / self.regularisation for j in range(self.J)])
    self.pi_t_j = self.pi_t_j[1:]
    return self.pi_t_j
  

  def faboamse(self): 
    np.seterr(divide='ignore', invalid='ignore')
    self.pi_t_j = [np.ones(self.J)/self.J]
    self.L_t_j = [np.zeros(self.J)]
    self.n_t_j = [np.zeros(self.J)]
    self.E_t_j = 2*np.ones(self.J)
    self.l_t_j = []
    self.epi = None
    for t in range(self.len_y):
      self.epi = np.dot(self.pi_t_j[-1],[self.mse(self.pred_set[i][t],self.y[t]) for i in range(self.J)])
      self.l_t_j.append([self.mse(self.pred_set[i][t],self.y[t]) - self.epi for i in range(self.J)])
      self.L_t_j.append([self.L_t_j[-1][j] + self.l_t_j[-1][j]*(1 + self.n_t_j[-1][j]*self.l_t_j[-1][j])/2 + self.E_t_j[j]*(self.n_t_j[-1][j]*self.l_t_j[-1][j]>0.5) for j in range(self.J)])
      for j in range(self.J):
        if self.l_t_j[-1][j] > self.E_t_j[j]:
          k=0
          while self.l_t_j[-1][j] <= 2**k:
            k=k+1
          self.E_t_j[j] = 2**(k+1)
      self.n_t_j.append([np.min([1/self.E_t_j[j], math.sqrt(math.log(1/self.pi_t_j[0][j])/np.sum([self.l_t_j[s][j]**2 for s in range(t)]))]) for j in range(self.J)])
      self.regularisation = np.sum([np.exp(-self.n_t_j[-1][j]*self.l_t_j[-1][j]*(1 + self.n_t_j[-1][j]*self.l_t_j[-1][j]))*self.pi_t_j[-1][j] for j in range(self.J)])
      self.pi_t_j.append([np.exp(-self.n_t_j[-1][j]*self.l_t_j[-1][j]*(1 + self.n_t_j[-1][j]*self.l_t_j[-1][j]))*self.pi_t_j[-1][j] / self.regularisation for j in range(self.J)])
    return self.pi_t_j
  

def AgACI(self, gammas : list, window = 20):
  for t in y_test_2:
    low_t = []
    high_t = []
    omega_t_low = []
    omega_t_high = []
    low = pred_down_test_2 - np.quantile(f_conformity_score_low(pred_down_test_1,y_test_1),1-alpha_star_low_updated)
    high = pred_up_test_2 + np.quantile(f_conformity_score_high(pred_up_test_1,y_test_1),1-alpha_star_high_updated)
    for gamma in gammas:
      alpha_star_low_upd = alpha_star_low_updated + gamma*(alphas[0] - np.mean([err_t_low(y_test_1,pred_down_test_1,i) for i in range(window)]))
      if 0<alpha_star_low_upd <1:
        low = pred_down_test_2 - np.quantile(f_conformity_score_low(pred_down_test_1,y_test_1),1-alpha_star_low_upd)
      else :
        print("alpha_star_low_updated out of 0-1")
      alpha_star_high_upd = alpha_star_high_updated + gamma*(1-alphas[1] - np.mean([err_t_high(y_test_1,pred_up_test_1,i) for i in range(window)]))
      if 0<alpha_star_high_upd <1:
        high = pred_up_test_2 + np.quantile(f_conformity_score_high(pred_up_test_1,y_test_1),1-alpha_star_high_upd)
      else :
        print("alpha_star_high_updated out of 0-1")
      low_t.append(low)
      high_t.append(high)
    C_low = np.mean(low_t,axis = 0)
    C_high = np.mean(high_t,axis = 0)
  return C_low,C_high


# COMMAND ----------

if 0 :
        #Show plot interactif :
        betas = np.arange(0,1,0.0001)
        self.alpha_star = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate(self.pred_down_cal,self.pred_up_cal,self.pred_down_val,self.pred_up_val,self.y_cal,self.y_val,alpha = b) < (1 - self.confidence))])
        self.alpha_star_low = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_up(self.pred_up_cal,self.pred_up_val,self.y_cal,self.y_val,alpha = b) < self.alphas[0])])
        self.alpha_star_high = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_down(self.pred_down_cal,self.pred_down_val,self.y_cal,self.y_val,alpha = b) < 1 - self.alphas[1])])
        self.alpha_star_low_updated = self.alpha_star_low
        self.alpha_star_high_updated = self.alpha_star_high
        self.alpha_star_updated = self.alpha_star
        # Create figure
        fig = go.Figure()
        self.error_adaptative = []
        # Add traces, one for each slider step
        for step in range(int(len(self.X_predict)/2 -1)):
          self.X_test_1, self.X_test_2, self.y_test_1, self.y_test_2 = train_test_split(self.X_test,self.y_test,test_size = int(len(self.X_test)/2) - step,shuffle = False)
          self.xX_test_1, self.xX_test_2 = train_test_split(self.xX_test,test_size = int(len(self.X_test)/2) - step,shuffle = False)
          self.pred_down_test_1 = self.predict(self.X_test_1)[0]
          print("self.pred_down_test_1 = ",self.pred_down_test_1)
          self.pred_up_test_1 = self.predict(self.X_test_1)[1]
          self.pred_down_test_2 = self.predict(self.X_test_2)[0]
          self.pred_up_test_2 = self.predict(self.X_test_2)[1]
          self.pred_down_test_1_conformal = self.pred_down_test_1 - np.quantile(self.f_conformity_score(self.pred_down_cal,self.pred_up_cal,self.y_cal), q = 1-self.alpha_star_low_updated)
          self.pred_up_test_1_conformal = self.pred_up_test_1 + np.quantile(self.f_conformity_score(self.pred_down_cal,self.pred_up_cal,self.y_cal), q = self.alpha_star_high_updated)

          self.alpha_star_upd = self.alpha_star_updated +self.gamma*(1-self.confidence - np.mean([self.err_t(self.y_test_1,self.pred_up_test_1,self.pred_down_test_1,i) for i in range(self.t)]))
          if 0<self.alpha_star_upd<1:
            self.alpha_star_updated = self.alpha_star_upd
          else :
            print("alpha_star_up",alpha_star_upd)
          self.pred_down_test_2_adaptative_conformal = self.pred_down_test_2 - np.quantile(self.f_conformity_score(self.pred_down_test_1,self.pred_up_test_1,self.y_test_1),1-self.alpha_star_updated)

          self.pred_up_test_2_adaptative_conformal = self.pred_up_test_2 + np.quantile(self.f_conformity_score(self.pred_down_test_1,self.pred_up_test_1,self.y_test_1),1-self.alpha_star_updated)

          self.error_adaptative.append((np.sum(self.y_test_2<self.pred_down_test_2_adaptative_conformal) + np.sum(self.y_test_2>self.pred_up_test_2_adaptative_conformal))/len(self.y_test_2))
          if step == 0:
            fig.add_trace(go.Scatter(x=self.xX_test, y=self.y_test,
                                mode='lines',
                                name='True'))
          fig.add_trace(go.Scatter(x=self.xX_test_1, y=self.pred_down_test_1_conformal,
                                mode='lines',
                                name=f'Conformalised_{self.alphas[0]}'))
          fig.add_trace(go.Scatter(x=self.xX_test_1, y=self.pred_up_test_1_conformal,
                                mode='lines',
                                name=f'Conformalised_{self.alphas[1]}'))

          fig.add_trace(go.Scatter(x=self.xX_test_2, y=self.pred_down_test_2_adaptative_conformal,
                                mode='lines',
                                name=f'Adaptative_Conformalised_{alphas[0]}'))
          fig.add_trace(go.Scatter(x=self.xX_test_2, y=self.pred_up_test_2_adaptative_conformal,
                                mode='lines',
                                name=f'Adaptative_Conformalised_{alphas[1]}'))

          #fig.add_vline(x=list(xX_test_1)[-1], line_width=3, line_dash="dash", line_color="black")
          steps = []
          for i in range(int(len(fig.data)/5)):
              step = dict(
                  method="update",
                  args=[{"visible": [False] * len(fig.data)},
                        {"title": f"Conformal IC predict, confidence_test_2 = {1 - self.error_adaptative[i]}, expected = {self.confidence}"}],  # layout attribute
              )
              step["args"][0]["visible"][0] = True #True line always visible
              step["args"][0]["visible"][4*i+1] = True  # Toggle i'th trace to "visible"
              step["args"][0]["visible"][4*i+2] = True  # Toggle i'th trace to "visible"
              step["args"][0]["visible"][4*i+3] = True  # Toggle i'th trace to "visible"
              step["args"][0]["visible"][4*i+4] = True  # Toggle i'th trace to "visible"
              steps.append(step)

          sliders = [dict(
              active=1,
              currentvalue={"prefix": "Frequency: "},
              pad={"t": 1},
              steps=steps
          )]

          fig.update_layout(
              sliders=sliders
          )

          fig.show()


# COMMAND ----------

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader

class LSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim):
        super(LSTM, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers

        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_().to(device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_().to(device)

        # we need to detach h0 and c0 here since we are doing back propagation through time (BPTT)
        out, (hn, cn) = self.lstm(x, (h0.detach(), c0.detach()))
        out = self.fc(out[:, -1, :])
        return out

class GRU(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim):
        super(GRU, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers

        self.gru = nn.GRU(input_dim, hidden_dim, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).requires_grad_().to(device)
        # we need to detach h0 here since we are doing back propagation through time (BPTT)
        out, (hn) = self.gru(x, (h0.detach()))
        out = self.fc(out[:, -1, :])
        return out
      
def train(net, x_train, y_train, x_test, y_test, criterion, optimizer):
  print(net)
  net.to(device)
  start_time = time.time()
  hist = []
  for t in range(num_epochs):
    x_train = x_train.to(device)
    y_train = y_train.to(device)
    y_train_pred = net(x_train)
    loss = criterion(y_train_pred, y_train)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    hist.append(loss.item())
    if t !=0 and t % 100 == 0 :
      print(' Epoch: {:.6f} \t Training loss: {:.6f} ' .format(t, loss.item()))
      test_loss = criterion(net(x_test.to(device)), y_test.to(device)).item()
      print(' Epoch: {:.6f} \t Test loss: {:.6f} ' .format(t, test_loss))
  training_time = time.time()-start_time
  print("Training time: {}".format(training_time))
  return np.array(hist)

# COMMAND ----------

class Analyse_Conformal_Inference(Conformal_Inference):
  def __init__(self,Conformal_Inference):
    self.mode = Conformal_Inference.mode
    self.cal_size = Conformal_Inference.cal_size
    self.val_size = Conformal_Inference.val_size
    self.test_size = Conformal_Inference.test_size
    self.model_down_set = Conformal_Inference.model_down_set
    self.model_up_set = Conformal_Inference.model_up_set
    self.model_median_set = Conformal_Inference.model_median_set

  def compare(self,model):
    model_pred = model.predict(self.X_test)
    return(np.sum((model_pred[i] -self.pred_median_predict_asymetric_conformal[i])**2 for i in range(len(self.X_test))))

# COMMAND ----------


if 0:
  fig = go.Figure()
  fig.add_trace(go.Scatter( y=pred_up_predict_asymetric_conformal,
                  mode='lines',
                  name=f'q_{alphas[1]}',
                  line=dict(
                      color='rgb(0, 256, 0)',
                      width=0),
                  showlegend = False))

  fig.add_trace(go.Scatter( y=self.pred_down_predict_asymetric_conformal,
                  mode='lines',
                  name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                  line=dict(
                      color='rgb(0, 256, 0)',
                      width=0),
                  fill='tonexty',
                  fillcolor='rgba(0,176,246,0.2)',
                  line_color='rgba(255,255,255,0)'))

  fig.add_trace(go.Scatter( y=self.pred_median_predict_asymetric_conformal,
                mode='lines',
                name=f'y_median',
                line=dict(
                    color='rgb(256,0, 0)',
                    width=1),
                showlegend = True))

  fig.add_trace(go.Scatter( y=self.y_test,
                mode='lines',
                name=f'y_true',
                line=dict(
                    color='rgb(0,0, 256)',
                    width=1),
                showlegend = True))

  error = (np.sum(self.y_test<self.pred_down_predict_asymetric_conformal) + np.sum(self.y_test>self.pred_up_predict_asymetric_conformal))/len(self.y_test)
  fig.update_traces(mode='lines')
  fig.update_layout(title = f"Test : {1-error}% Confidence Interval Prediction")                      
  fig.show()

# COMMAND ----------

class Adaptative_Conformal_Inference(Conformal_Inference):
  def __init__(self,alphas,adaptative_window_length,gamma,cal_size,val_size,mode = "normal"):
    Conformal_Inference.__init__(self,alphas, cal_size , val_size ,test_size = None,mode = mode)
    self.alphas = alphas
    self.confidence = self.alphas[1] - self.alphas[0]
    self.cal_size = cal_size
    self.val_size = val_size
    self.mode = mode
    self.adaptative_window_length = adaptative_window_length
    self.gamma = gamma
    self.adaptative_window_length = adaptative_window_length
    self.adaptative = True

  def predict(self,X_predict = None,plot = False):
    if self.fitted == False:
      print("please fit the model")

    self.pred_down_predict,self.pred_up_predict,self.pred_median_predict = self.predict_test(X_predict)
    #initialize adaptative alphas
    alpha_star_down_updated = self.alphas[0]
    alpha_star_up_updated = self.alphas[1]
    alpha_star_median_updated = 0.5
    pred_down_adaptative = self.pred_down_cal[-len(X_predict):].copy()
    pred_up_adaptative = self.pred_up_cal[-len(X_predict):].copy()
    pred_median_adaptative = self.pred_median_cal[-len(X_predict):].copy()
    y_cal_increased = self.y_cal[-len(X_predict):].copy()
    y_val = self.y_val.copy()
    #pred_up_val = self.pred_up_val.copy()
    #pred_down_val = self.pred_down_val.copy()
    pred_median_cal = self.pred_median_cal.copy()
    pred_median_val = self.pred_median_val.copy()
    
    self.alpha_star_down_updated_list = []
    self.alpha_star_up_updated_list = []
    self.alpha_star_median_updated_list = []
  
    #init alpha star
    try:
      alpha_star_down_updated = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_down(self.pred_down_cal,self.pred_down_val,self.y_cal,self.y_val,alpha = b) < self.alphas[0])])
      alpha_star_up_updated = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_up(self.pred_up_cal,self.pred_up_cal,self.y_cal,self.y_val,alpha = b) < 1 - self.alphas[1])])
      alpha_star_median_updated = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_median(self.pred_median_cal,self.pred_median_val,self.y_cal,self.y_val,alpha = b) < 0.5)])
    except ValueError:
      print("no quantile found to cover the shift")
      print("setting default value")
      alpha_star_down_updated = 0.5
      alpha_star_up_updated = 0.5
      alpha_star_median_updated = 0.5
    
    for it in range(len(self.X_val)):
      #compute alpha star updated
      alpha_star_up_updated = alpha_star_up_updated + self.gamma*(1 - self.alphas[1] - np.sum([self.err_t_up(y_cal_increased,pred_up_adaptative,w)*math.exp(-w) for w in range(self.adaptative_window_length)])/np.sum([math.exp(k) for k in range(self.adaptative_window_length)]))
      alpha_star_down_updated = alpha_star_down_updated + self.gamma*(self.alphas[0] - np.sum([self.err_t_down(y_cal_increased,pred_down_adaptative,w)*math.exp(-w) for w in range(self.adaptative_window_length)])/np.sum([math.exp(k) for k in range(self.adaptative_window_length)]))
      alpha_star_median_updated = alpha_star_median_updated + self.gamma*(0.5 - np.sum([self.err_t_median(y_cal_increased,pred_median_adaptative,w)*math.exp(-w) for w in range(self.adaptative_window_length)])/np.sum([math.exp(k) for k in range(self.adaptative_window_length)]))
      self.alpha_star_down_updated_list.append(alpha_star_down_updated)
      self.alpha_star_up_updated_list.append(alpha_star_up_updated)
      self.alpha_star_median_updated_list.append(alpha_star_median_updated)

      if 0<alpha_star_up_updated <1:
        pred_up_adaptative = np.append(pred_up_adaptative,self.pred_up_val[it] + np.quantile(self.f_conformity_score_up(self.y_cal,self.pred_up_cal),1-alpha_star_up_updated))
      elif alpha_star_up_updated <= 0:
        pred_up_adaptative = np.append(pred_up_adaptative,self.pred_up_val[it] + np.min(self.f_conformity_score_up(self.y_cal,self.pred_up_cal)))
        alpha_star_up_updated = 0.1
        print(f" i = {it} alpha_star_up_updated < 0")
      elif alpha_star_up_updated >=1:
        pred_up_adaptative = np.append(pred_up_adaptative,self.pred_up_val[it] + np.max(self.f_conformity_score_up(self.y_cal,self.pred_up_cal)))
        alpha_star_up_updated = 0.9
        print(f" i = {it} alpha_star_up_updated >1")
      #lower bound 
      if 0<alpha_star_down_updated <1:
        pred_down_adaptative = np.append(pred_down_adaptative,self.pred_down_val[it] - np.quantile(self.f_conformity_score_down(self.y_cal,self.pred_up_cal),1-alpha_star_down_updated))
      elif alpha_star_down_updated <= 0:
        pred_down_adaptative = np.append(pred_down_adaptative,self.pred_down_val[it] - np.max(self.f_conformity_score_down(self.y_cal,self.pred_up_cal)))
        alpha_star_down_updated = 0.001
        print(f" i = {it} alpha_star_down_updated < 0")
      elif alpha_star_down_updated >=1:
        pred_down_adaptative = np.append(pred_down_adaptative,self.pred_down_val[it] - np.min(self.f_conformity_score_down(self.y_cal,self.pred_up_cal)))
        alpha_star_down_updated = 0.999
        print(f" i = {it} alpha_star_down_updated >1")
      #Median 
      if 0<alpha_star_median_updated <1:
        pred_median_adaptative = np.append(pred_median_adaptative,self.pred_median_val[it] - np.quantile(self.f_conformity_score_median(self.y_cal,self.pred_up_cal),1-alpha_star_median_updated))
      elif alpha_star_median_updated <= 0:
        pred_median_adaptative = np.append(pred_median_adaptative,self.pred_median_val[it] - np.max(self.f_conformity_score_median(self.y_cal,self.pred_up_cal)))
        alpha_star_median_updated = 0.1
        print(f" i = {it} alpha_star_down_updated < 0")
      elif alpha_star_median_updated >=1:
        pred_median_adaptative = np.append(pred_median_adaptative,self.pred_median_val[it] - np.min(self.f_conformity_score_median(self.y_cal,self.pred_up_cal)))
        alpha_star_median_updated = 0.9
        print(f" i = {it} alpha_star_down_updated >1")

      y_cal_increased = np.append(y_cal_increased,self.y_val[it])
      y_cal_increased = np.delete(y_cal_increased,0)
      pred_up_adaptative = np.delete(pred_up_adaptative,0)
      pred_down_adaptative = np.delete(pred_down_adaptative,0)
      pred_median_adaptative = np.delete(pred_median_adaptative,0)
      print(it , "alpha_star_down_updated : ",alpha_star_down_updated)
      print(it , "alpha_star_up_updated : ",alpha_star_up_updated)
      print(it , "alpha_star_median_updated : ",alpha_star_median_updated)


    if self.mode =="normal":
      pred_down_adaptative = self.pred_down_predict - np.quantile(self.f_conformity_score_down(self.y_cal,self.pred_up_cal), 1-alpha_star_down_updated)
      pred_up_adaptative = self.pred_up_predict - np.quantile(self.f_conformity_score_up(self.y_cal,self.pred_up_cal),1-alpha_star_up_updated)
      pred_median_adaptative = self.pred_median_predict - np.quantile(self.f_conformity_score_median(self.y_cal,self.pred_up_cal),1-alpha_star_median_updated)

    if plot :
      if self.mode == "test":
        fig = go.Figure()
        fig.add_trace(go.Scatter( y=pred_up_adaptative,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))
        
        fig.add_trace(go.Scatter( y=pred_down_adaptative,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter( y=pred_median_adaptative,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        
        fig.add_trace(go.Scatter( y=self.y_val,
                      mode='lines',
                      name=f'y_true',
                      line=dict(
                          color='rgb(0,0, 256)',
                          width=1),
                      showlegend = True))
        error = (np.sum(self.y_val<pred_down_adaptative) + np.sum(self.y_val>pred_up_adaptative))/len(self.y_val)
        fig.update_layout(title = f"Test : {(1-error)*100}% Confidence Interval Prediction")


      if self.mode == "normal":
        fig = go.Figure()
        fig.add_trace(go.Scatter( y=pred_up_adaptative,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))
        
        fig.add_trace(go.Scatter( y=pred_down_adaptative,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter( y=pred_median_adaptative,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        fig.update_layout(title = f"Predict  adaptative Interval Prediction")
        
             
      fig.update_traces(mode='lines')                 
      fig.show()  
    print(len(X_predict))
    return pred_down_adaptative,pred_up_adaptative

  def err_t(self,y_true,pred_up,pred_down,t):
    """
    Compute the adaptative error of adaptative conformal inference at time t
    """
    return (list(y_true)[-t]>list(pred_up)[-t] or list(y_true)[-t]<list(pred_down)[-t])

  def err_t_down(self,y_true,pred_down,t):
    """
    Compute the adaptative error of asymetric adaptative conformal inference for down bound at time t
    """
    return list(y_true)[-t]<=list(pred_down)[-t]

  def err_t_up(self,y_true,pred_up,t):
    """
    Compute the adaptative error of asymetric adaptative conformal inference for upper down bound at time t
    """
    return list(y_true)[-t]>=list(pred_up)[-t]
  
  def err_t_median(self,y_true,pred_median,t):
    """
    Compute the adaptative error of asymetric adaptative conformal inference for down bound at time t
    """
    return list(y_true)[-t]<=list(pred_median)[-t]
  

# COMMAND ----------

""" note à moi même :
class bernstein
class quantile aggregate
class conformal inference
class adaptative conformal inference
class faci
fit from modeles module !
"""

# COMMAND ----------

class faci(Adaptative_Conformal_Inference):
  def __init__(self,alphas,adaptative_window_length,gamma,cal_size,val_size,mode = "normal"):
    Conformal_Inference.__init__(self,alphas, cal_size , val_size ,test_size = None,mode = mode)
    self.gammas = np.arange(0.001,1,0.001)
    self.alphas_i = [np.arange(0.001,1,0.001)]
    
  def FACI_up(self,sigma, eta):
    self.p_values = [np.max([b for b in np.arange(0,1,0.01) if (self.pred_up_val[t] + np.quantile(self.f_conformity_score_high(self.pred_up_cal,self.y_cal),1-b))>list(self.y_val)[t] ]) for t in range(len(self.pred_up_val))]
    k = len(self.pvalues)
    omegas = np.ones(len(gammas_k))
    output = []
    for t in range(k):
      p = omegas / np.sum(omegas)
      alpha_barre = np.dot(p,self.alphas_i)
      output.append(alpha_barre)
      omegas_barre = []
      for i in range(len(alphas_i)):
        omegas_barre.append(omegas[i]*np.exp(-eta*(self.alphas[1]*(self.pvalues[t]-self.alphas_i[i]) - min(0,self.pvalues[t]-self.alphas_i[i]))))
      omegas = (np.multiply((1-sigma),omegas_barre) + np.sum(omegas_barre)*sigma/k)
      err_t_i = [(self.pred_up_cal[t] + np.quantile(self.f_conformity_score_high(self.pred_up_cal,y_tcal),1-alpha_i))>list(y_cal)[t] for alpha_i in self.alphas_i]
      for i in range(len(self.alphas_i)):
        self.alphas_i[i] = max(0,min(1,self.alphas_i[i] + self.gammas[i]*(self.alphas[1] - err_t_i[i])))
    return output

# COMMAND ----------

class AgACI(Conformal_Inference):
  def __init__(self,alphas,adaptative_window_length,cal_size,val_size,gammas : list,mode = "normal"):
    Conformal_Inference.__init__(self,alphas, cal_size , val_size ,test_size = None,mode = mode)
    self.gammas = gammas
  def predict(self,X_test):
    #Initialisation 
    cal_test_iterative = self.X_cal
    for x_test_i in X_test:
      low_t = []
      high_t = []
      omega_t_low = []
      omega_t_high = []
      alpha_star_low_updated = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_down(self.pred_down_cal,self.pred_down_val,self.y_cal,self.y_val,alpha = b) < self.alphas[0])])
      alpha_star_high_updated = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_up(self.pred_up_cal,self.pred_up_val,self.y_cal,self.y_val,alpha = b) < 1 - self.alphas[1])])
      alpha_star_median = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_median(self.pred_median_cal,self.pred_median_val,self.y_cal,self.y_val,alpha = b) < 0.5)])
      pred_down_test,pred_up_test,pred_median_test = super().predict_test(X_test)
      low = pred_down_test - np.quantile(self.f_conformity_score_down(self.pred_down_cal,self.y_cal),1-self.alphas[0])
      high = pred_up_test + np.quantile(self.f_conformity_score_up(self.pred_up_cal,self.y_cal),1-self.alphas[1])
      med = pred_median_test + np.quantile(self.f_conformity_score_median(self.pred_median_cal,self.y_cal),0.5)

      for gamma in self.gammas:
        alpha_star_low_upd = alpha_star_low_updated + gamma*(self.alphas[0] - np.mean([self.err_t_low(y_test_1,pred_down_test_1,i) for i in range(adaptative_window_length)]))
        if 0<alpha_star_low_upd <1:
          low = pred_down_test - np.quantile(self.f_conformity_score_low(self.pred_down_val,self.y_val,1-alpha_star_low_upd))
        else :
          print("alpha_star_low_updated out of 0-1")
        alpha_star_high_upd = alpha_star_high_updated + gamma*(1-self.alphas[1] - np.mean([err_t_high(y_test_1,pred_up_test_1,i) for i in range(adaptative_window_length)]))
        if 0<alpha_star_high_upd <1:
          high = pred_up_test_2 + np.quantile(f_conformity_score_high(pred_up_test_1,y_test_1),1-alpha_star_high_upd)
        else :
          print("alpha_star_high_updated out of 0-1")
        low_t.append(low)
        high_t.append(high)
      agup = aggregation_IC(high_t)
      agdown = aggregation_IC(low_t)
      agup.faboa()
      agdown.faboa()
      C_low = np.mean(low_t,axis = 0)
      C_high = np.mean(high_t,axis = 0)
    return C_low,C_high

# COMMAND ----------

class Multiplicative_Adaptative_Conformal_Inference(Conformal_Inference):
  def __init__(self,alphas,adaptative_window_length,gamma,cal_size,val_size,mode = "normal"):
    Conformal_Inference.__init__(self,alphas, cal_size , val_size ,test_size = None,mode = mode)
    self.alphas = alphas
    self.confidence = self.alphas[1] - self.alphas[0]
    self.cal_size = cal_size
    self.val_size = val_size
    self.mode = mode
    self.adaptative_window_length = adaptative_window_length
    self.gamma = gamma
    self.adaptative_window_length = adaptative_window_length
    self.adaptative = True

  def predict(self,X_predict = None,plot = False):
    if self.fitted == False:
      print("please fit the model")

    self.pred_down_predict,self.pred_up_predict,self.pred_median_predict = self.predict_test(X_predict)
    #initialize adaptative alphas
    alpha_star_down_updated = self.alphas[0]
    alpha_star_up_updated = self.alphas[1]
    alpha_star_median_updated = 0.5
    pred_down_adaptative = self.pred_down_cal[-len(X_predict):].copy()
    pred_up_adaptative = self.pred_up_cal[-len(X_predict):].copy()
    pred_median_adaptative = self.pred_median_cal[-len(X_predict):].copy()
    y_cal_increased = self.y_cal[-len(X_predict):].copy()
    y_val = self.y_val.copy()
    #pred_up_val = self.pred_up_val.copy()
    #pred_down_val = self.pred_down_val.copy()
    pred_median_cal = self.pred_median_cal.copy()
    pred_median_val = self.pred_median_val.copy()
    
    self.alpha_star_down_updated_list = []
    self.alpha_star_up_updated_list = []
    self.alpha_star_median_updated_list = []

    #init beta star
    
    beta_star_down_updated = np.min([b for b in np.arange(0,10,0.001) if ((np.sum(pred_median_adaptative - b*np.abs(np.array(pred_down_adaptative)-np.array(pred_median_adaptative)) >= np.array(y_cal_increased))/len(y_cal_increased)) < self.alphas[0])])
    beta_star_up_updated = np.min([b for b in np.arange(0,10,0.001) if ((np.sum(pred_median_adaptative + b*np.abs(np.array(pred_up_adaptative)-np.array(pred_up_adaptative)) <= np.array(y_cal_increased))/len(y_cal_increased)) < self.alphas[1])])

    
    for it in range(len(self.X_val)):
      #compute beta star updated
      beta_star_up_updated = beta_star_up_updated + self.gamma*(self.alphas[1] - np.sum([self.err_t_up(y_cal_increased,pred_up_adaptative,w)*math.exp(-w) for w in range(self.adaptative_window_length)])/np.sum([math.exp(k) for k in range(self.adaptative_window_length)]))
      beta_star_down_updated = alpha_star_down_updated + self.gamma*(1 - self.alphas[0] - np.sum([self.err_t_down(y_cal_increased,pred_down_adaptative,w)*math.exp(-w) for w in range(self.adaptative_window_length)])/np.sum([math.exp(k) for k in range(self.adaptative_window_length)]))




      pred_median_adaptative = np.append(pred_median_adaptative,pred_median_val[it])
      pred_up_adaptative = np.append(pred_up_adaptative,pred_median_adaptative[-1] + beta_star_up_updated*(np.abs(self.pred_up_val[it] - pred_median_adaptative[-1])))
      pred_down_adaptative = np.append(pred_down_adaptative,pred_median_adaptative[-1] - beta_star_down_updated*(np.abs(self.pred_down_val[it] - pred_median_adaptative[-1])))

     

      y_cal_increased = np.append(y_cal_increased,self.y_val[it])
      y_cal_increased = np.delete(y_cal_increased,0)
      pred_up_adaptative = np.delete(pred_up_adaptative,0)
      pred_down_adaptative = np.delete(pred_down_adaptative,0)
      pred_median_adaptative = np.delete(pred_median_adaptative,0)
      print(it , "beta_star_down_updated : ",beta_star_down_updated)
      print(it , "beta_star_up_updated : ",beta_star_up_updated)
      print(it , "alpha_star_median_updated : ",alpha_star_median_updated)
      print("len(pred_down_adaptative) : ",len(pred_down_adaptative))

    if self.mode =="normal":
      pred_down_adaptative = self.pred_down_predict - np.quantile(self.f_conformity_score_down(self.y_cal,self.pred_up_cal), 1-alpha_star_down_updated)
      pred_up_adaptative = self.pred_up_predict - np.quantile(self.f_conformity_score_up(self.y_cal,self.pred_up_cal),1-alpha_star_up_updated)
      pred_median_adaptative = self.pred_median_predict - np.quantile(self.f_conformity_score_median(self.y_cal,self.pred_up_cal),1-alpha_star_median_updated)

    if plot :
      if self.mode == "test":
        fig = go.Figure()
        fig.add_trace(go.Scatter( y=pred_up_adaptative,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))
        
        fig.add_trace(go.Scatter( y=pred_down_adaptative,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter( y=pred_median_adaptative,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        
        fig.add_trace(go.Scatter( y=self.y_val,
                      mode='lines',
                      name=f'y_true',
                      line=dict(
                          color='rgb(0,0, 256)',
                          width=1),
                      showlegend = True))
        print("len(pred_down_adaptative) : ",len(pred_down_adaptative))
        error = (np.sum(self.y_val<pred_down_adaptative) + np.sum(self.y_val>pred_up_adaptative))/len(self.y_val)
        fig.update_layout(title = f"Test : {(1-error)*100}% Confidence Interval Prediction")


      if self.mode == "normal":
        fig = go.Figure()
        fig.add_trace(go.Scatter( y=pred_up_adaptative,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))
        
        fig.add_trace(go.Scatter( y=pred_down_adaptative,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter( y=pred_median_adaptative,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        fig.update_layout(title = f"Predict  adaptative Interval Prediction")
        
             
      fig.update_traces(mode='lines')                 
      fig.show()  
    print(len(X_predict))
    return pred_down_adaptative,pred_up_adaptative

  def err_t(self,y_true,pred_up,pred_down,t):
    """
    Compute the adaptative error of adaptative conformal inference at time t
    """
    return (list(y_true)[-t]>list(pred_up)[-t] or list(y_true)[-t]<list(pred_down)[-t])

  def err_t_down(self,y_true,pred_down,t):
    """
    Compute the adaptative error of asymetric adaptative conformal inference for down bound at time t
    """
    return list(y_true)[-t]<=list(pred_down)[-t]

  def err_t_up(self,y_true,pred_up,t):
    """
    Compute the adaptative error of asymetric adaptative conformal inference for upper down bound at time t
    """
    return list(y_true)[-t]>=list(pred_up)[-t]
  
  def err_t_median(self,y_true,pred_median,t):
    """
    Compute the adaptative error of asymetric adaptative conformal inference for down bound at time t
    """
    return list(y_true)[-t]<=list(pred_median)[-t]
  

# COMMAND ----------

class EnbPi:
  def __init__(self,alpha,n_bootstrap : int, batch_size : int = 84):
    self.n_bootstrap = n_bootstrap
    self.batch_size = batch_size
    self.alpha = alpha
    self.model = XGBRegressor()

  def fit(self,X_train,y_train):
    self.X_train=X_train
    self.y_train = y_train
    self.T = len(self.X_train)
    self.len_train = len(self.X_train)
    self.S_b = []
    self.f_b = []
    
    for b in range(self.n_bootstrap):
      print("1/3 Train 1/2 : ",int(100*b/self.n_bootstrap),"%")
      self.S_b.append(np.random.choice(list(self.X_train.index),self.T,replace = True))
      self.f_b.append(self.model.fit(self.X_train.loc[self.S_b[-1]],np.take(self.y_train, self.S_b[-1])))
    self.eps =[]
    self.f_phi_i = []
    for i in range(self.len_train):
      print("2/3 train 2/2 : ",int(100*i/self.len_train),"%")
      self.f_phi_temp = []
      for bi,b in enumerate(self.S_b):
        if i not in b:
          self.f_phi_temp.append(self.f_b[bi].predict(self.X_train.iloc[i:i+1]))
        self.f_phi_i.append(np.mean(self.f_phi_temp))
      self.eps_phi_i = np.abs(self.y_train[i]-self.f_phi_i[i])
      if math.isnan(self.eps_phi_i) == False:
        self.eps.append(self.eps_phi_i)


  def predict(self,X_test):
    self.X_test = X_test
    self.len_test = len(self.X_test)
    self.X_test = X_test
    self.C_t_low = []
    self.C_t_high = []
    self.f_phi_t = [] 
    for t in range(len(self.X_test)):
      print(t,"/",self.len_test)
      print(int(100*t/self.len_test),"%")
      self.f_phi_temp = []
      for bi,b in enumerate(self.S_b):
        if t not in b:
          self.f_phi_temp.append(self.f_b[bi].predict(self.X_test.iloc[t:t+1]))
      print("eps : ",self.eps)
      self.f_phi_t.append(np.quantile(self.f_phi_temp,1-self.alpha))
      self.w_phi_t = np.quantile(self.eps,1-self.alpha)
      print("f_phi_t : ",self.f_phi_t)
      print("w_phi_t : ",self.w_phi_t)
      self.C_t_low.append(self.f_phi_t - self.w_phi_t)
      self.C_t_high.append(self.f_phi_t + self.w_phi_t)
      """
      if t % self.batch_size == 0:
        for j in range(self.batch_size):
          self.e_phi_j = float(np.abs(self.y_test[j]-self.f_phi_t[j]))
          print("e_phi_j",self.e_phi_j)
          print("type e_phi_j",type(self.e_phi_j))
          print("eps_preappend :", len(self.eps))
          print("type eps preappend :", type(self.eps))
          self.eps.append(self.e_phi_j)
          print("eps_post_append " , len(self.eps))
          del self.eps[0]
          print("eps_postdel :", len(self.eps))
      """
    return self.C_t_low, self.C_t_high

# COMMAND ----------

class Asymetric_EnbPi:
  def __init__(self,alpha,n_bootstrap : int, batch_size : int = 84):
    self.n_bootstrap = n_bootstrap
    self.batch_size = batch_size
    self.alpha = alpha
    self.model = XGBRegressor()

  def fit(self,X_train,y_train):
    self.X_train=X_train
    self.y_train = y_train
    self.T = len(self.X_train)
    self.len_train = len(self.X_train)
    self.S_b = []
    self.f_b = []
    
    for b in range(self.n_bootstrap):
      print("1/3 Train 1/2 : ",int(100*b/self.n_bootstrap),"%")
      self.S_b.append(np.random.choice(list(self.X_train.index),self.T,replace = True))
      self.f_b.append(self.model.fit(self.X_train.loc[self.S_b[-1]],np.take(self.y_train, self.S_b[-1])))
    self.eps =[]
    self.f_phi_i = []
    for i in range(self.len_train):
      print("2/3 train 2/2 : ",int(100*i/self.len_train),"%")
      self.f_phi_temp = []
      for bi,b in enumerate(self.S_b):
        if i not in b:
          self.f_phi_temp.append(self.f_b[bi].predict(self.X_train.iloc[i:i+1]))
        self.f_phi_i.append(np.mean(self.f_phi_temp))
      self.eps_phi_i = np.abs(self.y_train[i]-self.f_phi_i[i])
      if math.isnan(self.eps_phi_i) == False:
        self.eps.append(self.eps_phi_i)


  def predict(self,X_test):
    self.X_test = X_test
    self.len_test = len(self.X_test)
    self.X_test = X_test
    self.C_t_low = []
    self.C_t_high = []
    self.f_phi_t = [] 
    for t in range(len(self.X_test)):
      print(t,"/",self.len_test)
      print(int(100*t/self.len_test),"%")
      self.f_phi_temp = []
      for bi,b in enumerate(self.S_b):
        if t not in b:
          self.f_phi_temp.append(self.f_b[bi].predict(self.X_test.iloc[t:t+1]))
      print("eps : ",self.eps)
      self.f_phi_t.append(np.quantile(self.f_phi_temp,1-self.alpha))
      self.w_phi_t = np.quantile(self.eps,1-self.alpha)
      print("f_phi_t : ",self.f_phi_t)
      print("w_phi_t : ",self.w_phi_t)
      self.C_t_low.append(self.f_phi_t - self.w_phi_t)
      self.C_t_high.append(self.f_phi_t + self.w_phi_t)
      """
      if t % self.batch_size == 0:
        for j in range(self.batch_size):
          self.e_phi_j = float(np.abs(self.y_test[j]-self.f_phi_t[j]))
          print("e_phi_j",self.e_phi_j)
          print("type e_phi_j",type(self.e_phi_j))
          print("eps_preappend :", len(self.eps))
          print("type eps preappend :", type(self.eps))
          self.eps.append(self.e_phi_j)
          print("eps_post_append " , len(self.eps))
          del self.eps[0]
          print("eps_postdel :", len(self.eps))
      """
    return self.C_t_low, self.C_t_high

# COMMAND ----------

class Conformal_Inferenc_cuted():
  def __init__(self,alphas, cal_size , val_size ,test_size = 0,mode = "normal"):
    self.alphas = alphas
    self.confidence = self.alphas[1] - self.alphas[0]
    self.cal_size = cal_size
    self.val_size = val_size
    self.test_size = test_size
    self.fitted = False
    self.mode = mode
    self.adaptative = False
    model_down_set = []
    model_up_set = []
    model_median_set = []
    #GradientBoosting init
    model_down_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[0],n_estimators = 1000,
                                                      learning_rate = 0.01))
    model_up_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[1],n_estimators = 1000,
                                                    learning_rate = 0.01))
    model_median_set.append(GradientBoostingRegressor(loss="quantile", alpha=0.5,n_estimators = 1000,
                                                    learning_rate = 0.01))
    
    #LGBM init
    model_down_set.append(LGBMRegressor(alpha=self.alphas[0],  objective='quantile'))
    model_up_set.append(LGBMRegressor(alpha=self.alphas[1],  objective='quantile'))
    model_median_set.append(LGBMRegressor(alpha=0.5,  objective='quantile'))

    #LSTM init
    """
    To do here, cf LSTM_VAE dev notebook
    """
    #Enbpi Init:
    #model_down_set.append(EnbPi(alpha = ,n_bootstrap = 100))

    self.model_down_set = model_down_set
    self.model_up_set = model_up_set
    self.model_median_set = model_median_set

    if len(self.model_down_set) != (len(self.model_up_set)):
      print(" len(self.model_down_set != len(self.model_up_set))")    

  def fit(self,df_train):
    """
    Fit the model
    """
    self.target_train = df_train["Valeur"]
    self.df_train = df_train

    if self.mode == "normal" or self.adaptative:
      self.train_cal_val_split()
    if self.mode == "test" and not self.adaptative:
      self.train_cal_val_test_split()
      print("len(self.X_test) = ",len(self.X_test))
      print("len(self.y_test) = ",len(self.y_test))
    for i in range(len(self.model_down_set)):
      self.model_down_set[i] = self.model_down_set[i].fit(self.X_train,self.y_train)
      self.model_up_set[i] = self.model_up_set[i].fit(self.X_train,self.y_train)
      self.model_median_set[i] = self.model_median_set[i].fit(self.X_train,self.y_train)
    self.predict_cal_val()
    print("len(self.X_cal) = ",len(self.X_cal))
    print("len(self.y_cal) = ",len(self.y_cal))
    print("len(self.X_val) = ",len(self.X_val))
    print("len(self.y_val) = ",len(self.y_val))
    self.fitted = True

  def train_cal_val_split(self):
    "split data into train, calibration and validation set, used in normal mode"
    self.X_train, self.X_val , self.y_train, self.y_val = train_test_split(self.df_train, self.target_train,test_size = self.val_size,shuffle = False)
    self.X_train, self.X_cal , self.y_train, self.y_cal = train_test_split(self.X_train, self.y_train ,test_size = self.cal_size,shuffle = False)
    self.xX_train = self.X_train["DT_VALR"]
    self.X_train = self.X_train.drop(["DT_VALR","Valeur"],axis = 1)
    self.xX_cal = self.X_cal["DT_VALR"]
    self.xX_val = self.X_val["DT_VALR"]
    self.X_cal = self.X_cal.drop(["DT_VALR","Valeur"], axis = 1)
    self.X_val = self.X_val.drop(["DT_VALR","Valeur"], axis = 1)
    #return self.xX_train, self.xX_cal, self.xX_val, self.xX_test, self.X_train, self.X_cal, self.X_val, self.X_test, self.y_train, self.y_cal, self.y_val, self.y_test
    self.y_train = list(self.y_train)
    self.y_cal = list(self.y_cal)
    self.y_val = list(self.y_val)
    self.X_calval = pd.concat([self.X_cal,self.X_val], sort = False)
    self.y_calval = list(self.y_cal) + list(self.y_val)
    print("train_size = ", self.X_train.shape[0])

  def train_cal_val_test_split(self):
    """
    split data into train, calibration validation and test set, used in test mode
    return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_val,self.X_val, self.y_val, self.xX_test, self.X_test, self.y_test
    """
    self.X_train, self.X_test , self.y_train, self.y_test = train_test_split(self.df_train, self.target_train,test_size = self.test_size,shuffle = False)
    self.X_train, self.X_val , self.y_train, self.y_val = train_test_split(self.X_train, self.y_train,test_size = self.val_size,shuffle = False)
    self.X_train, self.X_cal , self.y_train, self.y_cal = train_test_split(self.X_train, self.y_train,test_size = self.cal_size,shuffle = False)
    self.xX_train = self.X_train["DT_VALR"]
    self.X_train = self.X_train.drop(["DT_VALR","Valeur"],axis = 1)
    self.xX_cal = self.X_cal["DT_VALR"]
    self.xX_val = self.X_val["DT_VALR"]
    self.X_cal = self.X_cal.drop(["DT_VALR","Valeur"], axis = 1)
    self.X_val = self.X_val.drop(["DT_VALR","Valeur"], axis = 1)
    self.xX_test = self.X_test["DT_VALR"]
    self.X_test = self.X_test.drop(["DT_VALR","Valeur"], axis = 1)
    self.y_train = list(self.y_train)
    self.y_cal = list(self.y_cal)
    self.y_val = list(self.y_val)
    self.X_calval = pd.concat([self.X_cal,self.X_val], sort = False)
    self.y_calval = list(self.y_cal) + list(self.y_val)
    print("train_size = ", self.X_train.shape[0])
    return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_val,self.X_val, self.y_val, self.xX_test, self.X_test, self.y_test

  def predict_cal_val(self):
    "predict on calibration and validation set"
    #self.model_down_set = []
    #self.model_up_set = []
    pred_down_cal_set = []
    pred_up_cal_set = []
    pred_median_cal_set = []
    pred_down_val_set = []
    pred_up_val_set = []
    pred_median_val_set = []
    pred_down_calval_set = []
    pred_up_calval_set = []
    pred_median_calval_set = []
                                               
    for i in range(len(self.model_down_set)):
      pred_down_cal_set.append(self.model_down_set[i].predict(self.X_cal))
      pred_up_cal_set.append(self.model_up_set[i].predict(self.X_cal))
      pred_median_cal_set.append(self.model_median_set[i].predict(self.X_cal))
      pred_down_val_set.append(self.model_down_set[i].predict(self.X_val))
      pred_up_val_set.append(self.model_up_set[i].predict(self.X_val))
      pred_median_val_set.append(self.model_median_set[i].predict(self.X_val))
      pred_down_calval_set.append(self.model_down_set[i].predict(self.X_calval))
      pred_up_calval_set.append(self.model_up_set[i].predict(self.X_calval))
      pred_median_calval_set.append(self.model_median_set[i].predict(self.X_calval))

    #Aggregation
    self.ag_up = aggregation_IC(pred_up_calval_set,self.y_calval)
    self.ag_down = aggregation_IC(pred_down_calval_set,self.y_calval)
    self.ag_median = aggregation_IC(pred_median_calval_set,self.y_calval)
    self.ag_down.faboa(alphas[0])
    self.ag_up.faboa(alphas[1])
    self.ag_median.faboa(0.5)
    self.pred_down_cal = np.dot(self.ag_down.pi_t_j[-1],[pred_down_cal_set[i] for i in range(len(pred_down_cal_set))])
    self.pred_up_cal = np.dot(self.ag_up.pi_t_j[-1],[pred_up_cal_set[i] for i in range(len(pred_up_cal_set))])
    self.pred_median_cal = np.dot(self.ag_median.pi_t_j[-1],[pred_median_cal_set[i] for i in range(len(pred_median_cal_set))])
    self.pred_down_val = np.dot(self.ag_down.pi_t_j[-1],[pred_down_val_set[i] for i in range(len(pred_down_val_set))])
    self.pred_up_val = np.dot(self.ag_up.pi_t_j[-1],[pred_up_val_set[i] for i in range(len(pred_up_val_set))])
    self.pred_median_val = np.dot(self.ag_median.pi_t_j[-1],[pred_median_val_set[i] for i in range(len(pred_median_val_set))])
    """
    #Conformity score conformal inference
    self.conformity_score = self.f_conformity_score(self.pred_down_cal,self.pred_up_cal,self.y_cal)
    self.conformity_score_down = self.f_conformity_score_down(self.pred_down_cal,self.y_cal)
    self.conformity_score_up = self.f_conformity_score_up(self.pred_up_cal,self.y_cal)
    """

  def predict_test(self,X):
    "predict on predict_set"
    pred_down_set = []
    pred_up_set = []
    pred_median_set = []
    for _ in range(len(self.model_down_set)):
      pred_down_set.append(self.model_down_set[_].predict(X))
      pred_up_set.append(self.model_up_set[_].predict(X))
      pred_median_set.append(self.model_median_set[_].predict(X))
    pred_down = np.dot(self.ag_down.pi_t_j[-1],[pred_down_set[i] for i in range(len(pred_down_set))])
    pred_up = np.dot(self.ag_up.pi_t_j[-1],[pred_up_set[i] for i in range(len(pred_up_set))])
    pred_median = np.dot(self.ag_median.pi_t_j[-1],[pred_median_set[i] for i in range(len(pred_median_set))])
    return(pred_down,pred_up,pred_median)

  def asymetric_conformal_IC(self,X_predict = None,plot = False):
    """
    Compute Asymetric Conformal Inference for predict set,
    X_predict = None,plot = False
    return self.pred_down_predict_asymetric_conformal,self.pred_up_predict_asymetric_conformal
    """
    self.X_predict = X_predict
    if self.mode == "test":
      self.X_predict = self.X_test
    self.pred_down_predict,self.pred_up_predict,self.pred_median_predict = self.predict_test(self.X_predict)
    self.betas = np.arange(0,1,0.0001)
    alpha_star_down = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_down(self.pred_down_cal,self.pred_down_val,self.y_cal,self.y_val,alpha = b) < self.alphas[0])])
    alpha_star_up = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_up(self.pred_up_cal,self.pred_up_val,self.y_cal,self.y_val,alpha = b) < 1 - self.alphas[1])])
    alpha_star_median = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_median(self.pred_median_cal,self.pred_median_val,self.y_cal,self.y_val,alpha = b) < 0.5)])
    print("self.alpha_star_down = ", alpha_star_down)

    self.pred_down_predict_asymetric_conformal = self.pred_down_predict - np.quantile(self.f_conformity_score_down(self.pred_down_cal,self.y_cal),1-alpha_star_down)
    self.pred_up_predict_asymetric_conformal = self.pred_up_predict + np.quantile(self.f_conformity_score_up(self.pred_up_cal,self.y_cal),1-alpha_star_up)
    self.pred_median_predict_asymetric_conformal = self.pred_median_predict - np.quantile(self.f_conformity_score_median(self.pred_median_cal,self.y_cal),1-alpha_star_median)

    if plot :
      #Show plot pred test 
      if self.mode == "normal":
        fig = go.Figure()
        fig.add_trace(go.Scatter( y=self.pred_up_predict_asymetric_conformal,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))

        fig.add_trace(go.Scatter( y=self.pred_down_predict_asymetric_conformal,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter( y=self.pred_median_predict_asymetric_conformal,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        
        fig.update_layout(title = f"{int(np.round(100*self.confidence))}% Asymetric conformal prediction interval")
        fig.show()

      if self.mode == "test":
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=self.xX_test, y=self.y_test,
                      mode='lines',
                      name=f'y_true',
                      line=dict(
                          color='rgb(0,0, 256)',
                          width=1),
                      showlegend = True))
                
        fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_up_predict_asymetric_conformal,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))

        fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_down_predict_asymetric_conformal,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_median_predict_asymetric_conformal,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        
        error = (np.sum(self.y_test<self.pred_down_predict_asymetric_conformal) + np.sum(self.y_test>self.pred_up_predict_asymetric_conformal))/len(self.y_test)
        fig.update_traces(mode='lines')
        fig.update_layout(title = f"Test : {1-error}% asymetric conformal prediction test")                      
        fig.show()
    return self.pred_down_predict_asymetric_conformal,self.pred_up_predict_asymetric_conformal

  def f_conformity_score(self,pred_down_cal,pred_up_cal,y_cal):
    """
    Compute the symetric conformity score
    """
    return np.max([pred_down_cal-y_cal,y_cal-pred_up_cal],axis = 0)
  
  def f_conformity_score_down(self,pred_down_cal,y_cal):
    """
    Compute the asymetric conformity score for down bound
    """
    return [pred_down_cal-y_cal]

  def f_conformity_score_up(self,pred_up_cal,y_cal):
    """
    Compute the asymetric conformity score for upper bound
    """
    return [y_cal-pred_up_cal]
  
  def f_conformity_score_median(self,pred_median_cal,y_cal):
    """
    Compute the asymetric conformity score for upper bound
    """
    return [pred_median_cal-y_cal]
  
  def f_miscoverage_rate(self,pred_down_cal,pred_up_cal,pred_down_val,pred_up_val,y_cal,y_val,alpha):
    """
    Compute the miscoverage rate
    """
    csq = np.quantile(self.f_conformity_score(pred_down_cal,pred_up_cal,y_cal),1-alpha)
    return(np.sum(np.max([pred_down_val-y_val,y_val-pred_up_val],axis = 0)>csq)/len(y_val))

  def f_miscoverage_rate_down(self,pred_down_cal,pred_down_val,y_cal,y_val,alpha):
    """
    Compute the asymetric miscoverage rate for down bound
    """
    csq_low = np.quantile(self.f_conformity_score_down(pred_down_cal,y_cal),1-alpha)
    return(np.sum((pred_down_val-y_val)>csq_low)/len(y_val))
  
  def f_miscoverage_rate_median(self,pred_median_cal,pred_median_val,y_cal,y_val,alpha):
    """
    Compute the asymetric miscoverage rate for median bound
    """
    csq_median = np.quantile(self.f_conformity_score_median(pred_median_cal,y_cal),1-alpha)
    return(np.sum((pred_median_val-y_val)>csq_median)/len(y_val))

  def f_miscoverage_rate_up(self,pred_up_cal,pred_up_val,y_cal,y_val,alpha):
    """
    Compute the asymetric miscoverage rate for upper bound
    """
    csq_up = np.quantile(self.f_conformity_score_up(pred_up_cal,y_cal),1 - alpha)
    return(np.sum((y_val-pred_up_val)>csq_up)/len(y_val))

# COMMAND ----------

class IC_model:
  def __init__(self,alphas):
    self.alphas = alphas
    self.confidence = self.alphas[1]-self.alphas[0]
    self.model_down_set = []
    self.model_up_set = []
    self.model_median_set = []
    #GradientBoosting init
    self.model_down_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[0],n_estimators = 1000,
                                                      learning_rate = 0.01))
    self.model_up_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[1],n_estimators = 1000,
                                                    learning_rate = 0.01))
    self.model_median_set.append(GradientBoostingRegressor(loss="quantile", alpha=0.5,n_estimators = 1000,
                                                    learning_rate = 0.01))
    
    #LGBM init
    self.model_down_set.append(LGBMRegressor(alpha=self.alphas[0],  objective='quantile'))
    self.model_up_set.append(LGBMRegressor(alpha=self.alphas[1],  objective='quantile'))
    self.model_median_set.append(LGBMRegressor(alpha=0.5,  objective='quantile'))


  def fit(self,df_train):
    """
    Fit the model
    """
    self.y_train = df_train["Valeur"]
    self.index_train = df_train["DT_VALR"]
    self.X_train = df_train.drop(["Valeur","DT_VALR"],axis = 1)
    for i in range(len(self.model_down_set)):
      self.model_down_set[i] = self.model_down_set[i].fit(self.X_train,self.y_train)
      self.model_up_set[i] = self.model_up_set[i].fit(self.X_train,self.y_train)
      self.model_median_set[i] = self.model_median_set[i].fit(self.X_train,self.y_train)
    self.fitted = True

  def predict(self,df_test,plot = "False"):
    "predict on predict_set"
    X = df_test
    pred_down_set = []
    pred_up_set = []
    pred_median_set = []
    """
    self.ag_up = aggregation_IC(pred_up_calval_set,self.y_calval)
    self.ag_down = aggregation_IC(pred_down_calval_set,self.y_calval)
    self.ag_median = aggregation_IC(pred_median_calval_set,self.y_calval)
    self.ag_down.faboa(self.alphas[0])
    self.ag_up.faboa(self.alphas[1])
    self.ag_median.faboa(0.5)
    """
    for _ in range(len(self.model_down_set)):
      pred_down_set.append(self.model_down_set[_].predict(X))
      pred_up_set.append(self.model_up_set[_].predict(X))
      pred_median_set.append(self.model_median_set[_].predict(X))
      """
    self.pred_down = np.dot(self.ag_down.pi_t_j[-1],[pred_down_set[i] for i in range(len(pred_down_set))])
    self.pred_up = np.dot(self.ag_up.pi_t_j[-1],[pred_up_set[i] for i in range(len(pred_up_set))])
    self.pred_median = np.dot(self.ag_median.pi_t_j[-1],[pred_median_set[i] for i in range(len(pred_median_set))])
    """
    self.pred_down = np.mean(pred_down_set,axis = 0)
    self.pred_up = np.mean(pred_up_set,axis = 0)
    self.pred_median = np.mean(pred_median_set,axis = 0)
    if plot :
      fig = go.Figure()
      fig.add_trace(go.Scatter( y=self.pred_up,
                      mode='lines',
                      name=f'q_{alphas[1]}',
                      line=dict(
                          color='rgb(0, 256, 0)',
                          width=0),
                      showlegend = False))

      fig.add_trace(go.Scatter( y=self.pred_down,
                      mode='lines',
                      name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                      line=dict(
                          color='rgb(0, 256, 0)',
                          width=0),
                      fill='tonexty',
                      fillcolor='rgba(0,176,246,0.2)',
                      line_color='rgba(255,255,255,0)'))
      
      fig.add_trace(go.Scatter( y=self.pred_median,
                    mode='lines',
                    name=f'y_median',
                    line=dict(
                        color='rgb(256,0, 0)',
                        width=1),
                    showlegend = True))
      
      fig.update_layout(title = f"{int(np.round(100*self.confidence))} Prediction interval")
      fig.show()
    return(self.pred_down,self.pred_up,self.pred_median)

# COMMAND ----------

class Conformal_Inference_cuted_loo():
  def __init__(self,alphas, cal_size , val_size ,test_size = 0,mode = "normal"):
    self.alphas = alphas
    self.confidence = self.alphas[1] - self.alphas[0]
    self.cal_size = cal_size
    self.val_size = val_size
    self.test_size = test_size
    self.fitted = False
    self.mode = mode
    self.adaptative = False
    model_down_set = []
    model_up_set = []
    model_median_set = []
    #GradientBoosting init
    model_down_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[0],n_estimators = 1000,
                                                      learning_rate = 0.01))
    model_up_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[1],n_estimators = 1000,
                                                    learning_rate = 0.01))
    model_median_set.append(GradientBoostingRegressor(loss="quantile", alpha=0.5,n_estimators = 1000,
                                                    learning_rate = 0.01))
    
    #LGBM init
    model_down_set.append(LGBMRegressor(alpha=self.alphas[0],  objective='quantile'))
    model_up_set.append(LGBMRegressor(alpha=self.alphas[1],  objective='quantile'))
    model_median_set.append(LGBMRegressor(alpha=0.5,  objective='quantile'))

    #LSTM init
    """
    To do here, cf LSTM_VAE dev notebook
    """
    #Enbpi Init:
    #model_down_set.append(EnbPi(alpha = ,n_bootstrap = 100))

    self.model_down_set = model_down_set
    self.model_up_set = model_up_set
    self.model_median_set = model_median_set

    if len(self.model_down_set) != (len(self.model_up_set)):
      print(" len(self.model_down_set != len(self.model_up_set))")    

  def fit(self,df_train):
    """
    Fit the model
    """
    self.target_train = df_train["Valeur"]
    self.df_train = df_train

    if self.mode == "normal" or self.adaptative:
      self.train_cal_val_split()
    if self.mode == "test" and not self.adaptative:
      self.train_cal_val_test_split()
      print("len(self.X_test) = ",len(self.X_test))
      print("len(self.y_test) = ",len(self.y_test))
    for i in range(len(self.model_down_set)):
      self.model_down_set[i] = self.model_down_set[i].fit(self.X_train,self.y_train)
      self.model_up_set[i] = self.model_up_set[i].fit(self.X_train,self.y_train)
      self.model_median_set[i] = self.model_median_set[i].fit(self.X_train,self.y_train)
    self.predict_cal_val()
    print("len(self.X_cal) = ",len(self.X_cal))
    print("len(self.y_cal) = ",len(self.y_cal))
    print("len(self.X_val) = ",len(self.X_val))
    print("len(self.y_val) = ",len(self.y_val))
    self.fitted = True

  def train_cal_val_split(self):
    "split data into train, calibration and validation set, used in normal mode"
    self.X_train, self.X_val , self.y_train, self.y_val = train_test_split(self.df_train, self.target_train,test_size = self.val_size,shuffle = False)
    self.X_train, self.X_cal , self.y_train, self.y_cal = train_test_split(self.X_train, self.y_train ,test_size = self.cal_size,shuffle = False)
    self.xX_train = self.X_train["DT_VALR"]
    self.X_train = self.X_train.drop(["DT_VALR","Valeur"],axis = 1)
    self.xX_cal = self.X_cal["DT_VALR"]
    self.xX_val = self.X_val["DT_VALR"]
    self.X_cal = self.X_cal.drop(["DT_VALR","Valeur"], axis = 1)
    self.X_val = self.X_val.drop(["DT_VALR","Valeur"], axis = 1)
    #return self.xX_train, self.xX_cal, self.xX_val, self.xX_test, self.X_train, self.X_cal, self.X_val, self.X_test, self.y_train, self.y_cal, self.y_val, self.y_test
    self.y_train = list(self.y_train)
    self.y_cal = list(self.y_cal)
    self.y_val = list(self.y_val)
    self.X_calval = pd.concat([self.X_cal,self.X_val], sort = False)
    self.y_calval = list(self.y_cal) + list(self.y_val)
    print("train_size = ", self.X_train.shape[0])

  def train_cal_val_test_split(self):
    """
    split data into train, calibration validation and test set, used in test mode
    return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_val,self.X_val, self.y_val, self.xX_test, self.X_test, self.y_test
    """
    self.X_train, self.X_test , self.y_train, self.y_test = train_test_split(self.df_train, self.target_train,test_size = self.test_size,shuffle = False)
    self.X_train, self.X_val , self.y_train, self.y_val = train_test_split(self.X_train, self.y_train,test_size = self.val_size,shuffle = False)
    self.X_train, self.X_cal , self.y_train, self.y_cal = train_test_split(self.X_train, self.y_train,test_size = self.cal_size,shuffle = False)
    self.xX_train = self.X_train["DT_VALR"]
    self.X_train = self.X_train.drop(["DT_VALR","Valeur"],axis = 1)
    self.xX_cal = self.X_cal["DT_VALR"]
    self.xX_val = self.X_val["DT_VALR"]
    self.X_cal = self.X_cal.drop(["DT_VALR","Valeur"], axis = 1)
    self.X_val = self.X_val.drop(["DT_VALR","Valeur"], axis = 1)
    self.xX_test = self.X_test["DT_VALR"]
    self.X_test = self.X_test.drop(["DT_VALR","Valeur"], axis = 1)
    self.y_train = list(self.y_train)
    self.y_cal = list(self.y_cal)
    self.y_val = list(self.y_val)
    self.X_calval = pd.concat([self.X_cal,self.X_val], sort = False)
    self.y_calval = list(self.y_cal) + list(self.y_val)
    print("train_size = ", self.X_train.shape[0])
    return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_val,self.X_val, self.y_val, self.xX_test, self.X_test, self.y_test

  def predict_cal_val(self):
    "predict on calibration and validation set"
    #self.model_down_set = []
    #self.model_up_set = []
    pred_down_cal_set = []
    pred_up_cal_set = []
    pred_median_cal_set = []
    pred_down_val_set = []
    pred_up_val_set = []
    pred_median_val_set = []
    pred_down_calval_set = []
    pred_up_calval_set = []
    pred_median_calval_set = []
                                               
    for i in range(len(self.model_down_set)):
      pred_down_cal_set.append(self.model_down_set[i].predict(self.X_cal))
      pred_up_cal_set.append(self.model_up_set[i].predict(self.X_cal))
      pred_median_cal_set.append(self.model_median_set[i].predict(self.X_cal))
      pred_down_val_set.append(self.model_down_set[i].predict(self.X_val))
      pred_up_val_set.append(self.model_up_set[i].predict(self.X_val))
      pred_median_val_set.append(self.model_median_set[i].predict(self.X_val))
      pred_down_calval_set.append(self.model_down_set[i].predict(self.X_calval))
      pred_up_calval_set.append(self.model_up_set[i].predict(self.X_calval))
      pred_median_calval_set.append(self.model_median_set[i].predict(self.X_calval))

    #Aggregation
    self.ag_up = aggregation_IC(pred_up_calval_set,self.y_calval)
    self.ag_down = aggregation_IC(pred_down_calval_set,self.y_calval)
    self.ag_median = aggregation_IC(pred_median_calval_set,self.y_calval)
    self.ag_down.faboa(self.alphas[0])
    self.ag_up.faboa(self.alphas[1])
    self.ag_median.faboa(0.5)
    self.pred_down_cal = np.dot(self.ag_down.pi_t_j[-1],[pred_down_cal_set[i] for i in range(len(pred_down_cal_set))])
    self.pred_up_cal = np.dot(self.ag_up.pi_t_j[-1],[pred_up_cal_set[i] for i in range(len(pred_up_cal_set))])
    self.pred_median_cal = np.dot(self.ag_median.pi_t_j[-1],[pred_median_cal_set[i] for i in range(len(pred_median_cal_set))])
    self.pred_down_val = np.dot(self.ag_down.pi_t_j[-1],[pred_down_val_set[i] for i in range(len(pred_down_val_set))])
    self.pred_up_val = np.dot(self.ag_up.pi_t_j[-1],[pred_up_val_set[i] for i in range(len(pred_up_val_set))])
    self.pred_median_val = np.dot(self.ag_median.pi_t_j[-1],[pred_median_val_set[i] for i in range(len(pred_median_val_set))])
    """
    #Conformity score conformal inference
    self.conformity_score = self.f_conformity_score(self.pred_down_cal,self.pred_up_cal,self.y_cal)
    self.conformity_score_down = self.f_conformity_score_down(self.pred_down_cal,self.y_cal)
    self.conformity_score_up = self.f_conformity_score_up(self.pred_up_cal,self.y_cal)
    """

  def predict_test(self,X):
    "predict on predict_set"
    pred_down_set = []
    pred_up_set = []
    pred_median_set = []
    for _ in range(len(self.model_down_set)):
      pred_down_set.append(self.model_down_set[_].predict(X))
      pred_up_set.append(self.model_up_set[_].predict(X))
      pred_median_set.append(self.model_median_set[_].predict(X))
    pred_down = np.dot(self.ag_down.pi_t_j[-1],[pred_down_set[i] for i in range(len(pred_down_set))])
    pred_up = np.dot(self.ag_up.pi_t_j[-1],[pred_up_set[i] for i in range(len(pred_up_set))])
    pred_median = np.dot(self.ag_median.pi_t_j[-1],[pred_median_set[i] for i in range(len(pred_median_set))])
    return(pred_down,pred_up,pred_median)

  def asymetric_conformal_IC(self,X_predict = None,plot = False):
    """
    Compute Asymetric Conformal Inference for predict set,
    X_predict = None,plot = False
    return self.pred_down_predict_asymetric_conformal,self.pred_up_predict_asymetric_conformal
    """
    self.X_predict = X_predict
    if self.mode == "test":
      self.X_predict = self.X_test
    self.pred_down_predict,self.pred_up_predict,self.pred_median_predict = self.predict_test(self.X_predict)
    self.betas = np.arange(0,1,0.0001)
    try:
      alpha_star_down = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_down(self.pred_down_cal,self.pred_down_val,self.y_cal,self.y_val,alpha = b) < self.alphas[0])])
      alpha_star_up = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_up(self.pred_up_cal,self.pred_up_val,self.y_cal,self.y_val,alpha = b) < 1 - self.alphas[1])])
      alpha_star_median = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_median(self.pred_median_cal,self.pred_median_val,self.y_cal,self.y_val,alpha = b) < 0.5)])
      self.pred_down_predict_asymetric_conformal = self.pred_down_predict - np.quantile(self.f_conformity_score_down(self.pred_down_cal,self.y_cal),1-alpha_star_down)
      self.pred_up_predict_asymetric_conformal = self.pred_up_predict + np.quantile(self.f_conformity_score_up(self.pred_up_cal,self.y_cal),1-alpha_star_up)
      self.pred_median_predict_asymetric_conformal = self.pred_median_predict - np.quantile(self.f_conformity_score_median(self.pred_median_cal,self.y_cal),1-alpha_star_median)
    except:
      model = IC_model(self.alphas)
      model.fit(self.df_train)
      return(model.predict(self.X_predict,plot = True))


    if plot :
      #Show plot pred test 
      if self.mode == "normal":
        fig = go.Figure()
        fig.add_trace(go.Scatter( y=self.pred_up_predict_asymetric_conformal,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))

        fig.add_trace(go.Scatter( y=self.pred_down_predict_asymetric_conformal,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter( y=self.pred_median_predict_asymetric_conformal,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        
        fig.update_layout(title = f"{int(np.round(100*self.confidence))}% Asymetric conformal prediction interval")
        fig.show()

      if self.mode == "test":
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=self.xX_test, y=self.y_test,
                      mode='lines',
                      name=f'y_true',
                      line=dict(
                          color='rgb(0,0, 256)',
                          width=1),
                      showlegend = True))
                
        fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_up_predict_asymetric_conformal,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))

        fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_down_predict_asymetric_conformal,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))
        
        fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_median_predict_asymetric_conformal,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        
        error = (np.sum(self.y_test<self.pred_down_predict_asymetric_conformal) + np.sum(self.y_test>self.pred_up_predict_asymetric_conformal))/len(self.y_test)
        fig.update_traces(mode='lines')
        fig.update_layout(title = f"Test : {1-error}% asymetric conformal prediction test")                      
        fig.show()
    return self.pred_down_predict_asymetric_conformal,self.pred_up_predict_asymetric_conformal, self.pred_median_predict_asymetric_conformal

  def f_conformity_score(self,pred_down_cal,pred_up_cal,y_cal):
    """
    Compute the symetric conformity score
    """
    return np.max([pred_down_cal-y_cal,y_cal-pred_up_cal],axis = 0)
  
  def f_conformity_score_down(self,pred_down_cal,y_cal):
    """
    Compute the asymetric conformity score for down bound
    """
    return [pred_down_cal-y_cal]

  def f_conformity_score_up(self,pred_up_cal,y_cal):
    """
    Compute the asymetric conformity score for upper bound
    """
    return [y_cal-pred_up_cal]
  
  def f_conformity_score_median(self,pred_median_cal,y_cal):
    """
    Compute the asymetric conformity score for upper bound
    """
    return [pred_median_cal-y_cal]
  
  def f_miscoverage_rate(self,pred_down_cal,pred_up_cal,pred_down_val,pred_up_val,y_cal,y_val,alpha):
    """
    Compute the miscoverage rate
    """
    csq = np.quantile(self.f_conformity_score(pred_down_cal,pred_up_cal,y_cal),1-alpha)
    return(np.sum(np.max([pred_down_val-y_val,y_val-pred_up_val],axis = 0)>csq)/len(y_val))

  def f_miscoverage_rate_down(self,pred_down_cal,pred_down_val,y_cal,y_val,alpha):
    """
    Compute the asymetric miscoverage rate for down bound
    """
    csq_low = np.quantile(self.f_conformity_score_down(pred_down_cal,y_cal),1-alpha)
    return(np.sum((pred_down_val-y_val)>csq_low)/len(y_val))
  
  def f_miscoverage_rate_median(self,pred_median_cal,pred_median_val,y_cal,y_val,alpha):
    """
    Compute the asymetric miscoverage rate for median bound
    """
    csq_median = np.quantile(self.f_conformity_score_median(pred_median_cal,y_cal),1-alpha)
    return(np.sum((pred_median_val-y_val)>csq_median)/len(y_val))

  def f_miscoverage_rate_up(self,pred_up_cal,pred_up_val,y_cal,y_val,alpha):
    """
    Compute the asymetric miscoverage rate for upper bound
    """
    csq_up = np.quantile(self.f_conformity_score_up(pred_up_cal,y_cal),1 - alpha)
    return(np.sum((y_val-pred_up_val)>csq_up)/len(y_val))