# Databricks notebook source
# MAGIC %md
# MAGIC # Introduction to scientific computing with Python
# MAGIC *Maxime Sangnier*
# MAGIC
# MAGIC September, 2020
# MAGIC
# MAGIC ## Part 1: Basics of Python

# COMMAND ----------

# MAGIC %md
# MAGIC # Table of contents
# MAGIC 1. [What is and why Python](#part1)
# MAGIC     - [Overview](#part1sec1)
# MAGIC     - [Comparison with other languages](#part1sec2)
# MAGIC 1. [Practical points](#part2)
# MAGIC     - [Versions of Python](#part2sec1)
# MAGIC     - [Installation](#part2sec2)
# MAGIC     - [Usage](#part2sec3)
# MAGIC     - [Getting help](#part2sec4)
# MAGIC 1. [An introduction to JupyterLab](#part3)
# MAGIC     - [Survival kit](#part3sec1)
# MAGIC     - [Useful features](#part3sec2)
# MAGIC     - [Text and equations](#part3sec3)
# MAGIC 1. [Basics of the Python language](#part4)
# MAGIC     - [Numbers](#part4sec1)
# MAGIC     - [Data structures](#part4sec2)
# MAGIC     - [Conditional statements](#part4sec3)
# MAGIC     - [For loop](#part4sec4)
# MAGIC     - [While loop](#part4sec5)
# MAGIC     - [Function](#part4sec6)
# MAGIC     - [Modules](#part4sec7)
# MAGIC 1. [Exercises](#part5)
# MAGIC     - [Exercise 1](#part5sec1)
# MAGIC     - [Exercise 2](#part5sec2)
# MAGIC     - [Exercise 3](#part5sec3)
# MAGIC     - [Exercise 4](#part5sec4)
# MAGIC     - [Exercise 5](#part5sec5)
# MAGIC     - [Exercise 6](#part5sec6)
# MAGIC 1. [References](#part6)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # What is and why Python <a id="part1"></a>
# MAGIC ## Overview <a id="part1sec1"></a>
# MAGIC For scientific computing, one mainly needs three things:
# MAGIC - workable toolboxes to applied mathematics, such as for sampling data, loading real-world data, processing, visualizing and analyzing them, solving equations, computing Fourier transformations, manipulating mathematical objects (polynomials, matrices, tensors), etc.
# MAGIC - a perfect trade-off between power and easiness of the programming language (scientists are not developers);
# MAGIC - efficient computations: code should execute quickly.
# MAGIC
# MAGIC As a consequence, a good language for scientific computing should gather these three aspects while providing also easy ways of communicating with collaborators (and students), as well as re-using and maintaining ad-hoc code produced by researchers.
# MAGIC Python (in union with IPython and available packages such as Scipy) is a scripting language that is suitable for scientific computing regarding the previous requirements.
# MAGIC The reasons of its popularity in the scientific community are that Python:
# MAGIC - is free and open-source, making its development fast and the Python community excited;
# MAGIC - comes with a rich collection of packages for scientific computing (not exhaustive yet);
# MAGIC - can do much more than scientific computing (web server management, data bases, etc.). This is very useful since scientists interact with other domains of computer science;
# MAGIC - is easy to learn, easy to write and easy to read;
# MAGIC - can be structured and maintained efficiently (packages, modules, object oriented programming);
# MAGIC - quite fast to execute thanks to a *precompilation*;
# MAGIC - computationally demanding parts can be converted from Python to C ([Cython](http://cython.org/)).
# MAGIC
# MAGIC However, Python has also some drawbacks.
# MAGIC In particular, it:
# MAGIC - requires a more advanced knowledge in development (low-level commands, many types and containers) than other scientific languages such as Matlab and R, even though it is few compared to C;
# MAGIC - comes with less packages than Matlab and R *in their own domain of research*;
# MAGIC - is a language in progress. In particular, differences between Python 2 (still often used by operating systems) and Python 3 (used by researchers and scientists) can confuse the practitioner.
# MAGIC
# MAGIC ## Comparison with other languages <a id="part1sec2"></a>
# MAGIC ### R
# MAGIC Advantages:
# MAGIC - free and open-source;
# MAGIC - very advanced features for statistics.
# MAGIC
# MAGIC Drawbacks:
# MAGIC - the language is not so powerful;
# MAGIC - dedicated to a single domain (statistics).
# MAGIC
# MAGIC ### Matlab
# MAGIC Advantages:
# MAGIC - rich collection of toolboxes for many scientific domains. Each toolbox contains implementations of numerous common algorithms;
# MAGIC - by default linked with a fast linear algebra library ([MKL](https://software.intel.com/en-us/intel-mkl));
# MAGIC - easy to learn, easy to write (not so easy to read).
# MAGIC
# MAGIC Drawbacks:
# MAGIC - not free;
# MAGIC - parallel computation not available in the base version;
# MAGIC - language not so powerful.
# MAGIC
# MAGIC ### C,  C++
# MAGIC Advantages:
# MAGIC - very fast execution (optimized compilers). Such a compiled language serves as a baseline for measuring running times of implementations;
# MAGIC - common and very powerful language.
# MAGIC
# MAGIC Drawbacks:
# MAGIC - may be difficult to learn (language addressed to developers);
# MAGIC - painful usage: no interactivity, compilation mandatory.
# MAGIC
# MAGIC # Practical points <a id="part2"></a>
# MAGIC ## Versions of Python <a id="part2sec1"></a>
# MAGIC There are currently two versions of Python: 2 and 3.
# MAGIC The most commonly used version in the research and industrial community is now Python 3, even though Python 2 may still be the default choice on several operating systems.
# MAGIC
# MAGIC Let us remark that Python 3 is not backwards-compatible (see [differences between both versions](https://docs.python.org/3/whatsnew/3.0.html)).
# MAGIC In practice, this means that a Python 2 script cannot always be interpreted by Python 3 (and respectively).
# MAGIC
# MAGIC In this tutorial, we focus on Python 3.
# MAGIC
# MAGIC ## Installation <a id="part2sec2"></a>
# MAGIC ### Windows and macOS
# MAGIC A Python essential kit can be easily obtained by installing [Anaconda](https://docs.anaconda.com/anaconda/install/).
# MAGIC It includes all you need for scientific computing.
# MAGIC In addition, an alternative to Anaconda is [Enthought Canopy](https://store.enthought.com/downloads/#default).
# MAGIC Even though it is a commercial product, Canopy is free for academic purposes.
# MAGIC Finally, another workable option on Windows is [Python(x,y)](http://python-xy.github.io/).
# MAGIC
# MAGIC ### Linux
# MAGIC On Debian and Ubuntu, a good option is to install Python and its package manager pip:
# MAGIC
# MAGIC     sudo apt-get install python3 python3-pip spyder3
# MAGIC     
# MAGIC Then, use pip to install the packages needed for scientific computing:
# MAGIC
# MAGIC     sudo pip3 install jupyterlab numpy scipy matplotlib pillow scikit-learn seaborn pandas statsmodels cvxopt ipympl tensorflow
# MAGIC
# MAGIC If you have trouble installing a package, use instead:
# MAGIC
# MAGIC     sudo apt-get install python3-[package_name]
# MAGIC     
# MAGIC ## Usage <a id="part2sec3"></a>
# MAGIC Since Python is a scripting language, there are several ways to use it.
# MAGIC The main ones are detailed below.
# MAGIC
# MAGIC ### Command line
# MAGIC In a shell, execute:
# MAGIC
# MAGIC     python3
# MAGIC
# MAGIC Then, start using it:
# MAGIC
# MAGIC     a = 3.14
# MAGIC     print("hello world")
# MAGIC
# MAGIC <img src="http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/img/console2.png" width=700>
# MAGIC
# MAGIC Press CTRL+D or type:
# MAGIC
# MAGIC     quit()
# MAGIC
# MAGIC to exit.
# MAGIC
# MAGIC If your code is written in a file *script.py*, you can run it from a shell with:
# MAGIC
# MAGIC     python3 script.py
# MAGIC
# MAGIC or in Python with:
# MAGIC
# MAGIC     execfile('script.py')
# MAGIC
# MAGIC ### IPython
# MAGIC [IPython](http://ipython.org/) is a powerful interactive shell that comes with numerous useful features such as:
# MAGIC - interactivity;
# MAGIC - tab-completion;
# MAGIC - command history;
# MAGIC - object introspection;
# MAGIC - special (magic) commands;
# MAGIC - numbered input/output.
# MAGIC
# MAGIC <img src="http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/img/iconsole2.png" width=700>
# MAGIC
# MAGIC One can use up and down arrows to access command history, tab for completion and %[command] for [magic commands](http://ipython.org/ipython-doc/3/interactive/magics.html) (or directly [command]).
# MAGIC The most used are:
# MAGIC - *cd [path]*: change the current working directory;
# MAGIC - *history*: print input history;
# MAGIC - *load [file]*: load code into the current frontend;
# MAGIC - *matplotlib [gui]*: set up matplotlib to work interactively;
# MAGIC - *pwd*: return the current working directory path;
# MAGIC - *reset*: reset the namespace;
# MAGIC - *run [file]*: run the script inside IPython as a program;
# MAGIC - *whos*: print all interactive variables with extra information.
# MAGIC
# MAGIC To run a script, use:
# MAGIC
# MAGIC     run script.py
# MAGIC
# MAGIC ### Spyder
# MAGIC [Spyder](http://pythonhosted.org/spyder/) is a Matlab-like IDE that shows both an editor and a Python shell.
# MAGIC It is an efficient tool for developing and testing codes.
# MAGIC
# MAGIC <img src="http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/img/spyder2.png" width=700>
# MAGIC In particular feature, it enables to run only part of the script while keeping the previous results (variable states) in memory.
# MAGIC
# MAGIC To run a script, you can edit it and press F5.
# MAGIC If you want to execute only a selection of it, select the part of interest and press F9.
# MAGIC
# MAGIC ### JupyterLab
# MAGIC JupyterLab is a novel web-based IDE to produce easy-to-read reports with text, equations, code and results (called a notebook).
# MAGIC This is what is used here!
# MAGIC
# MAGIC <img src="http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/img/jupyterlab.png" width=700>
# MAGIC
# MAGIC To launch it, write in a shell:
# MAGIC
# MAGIC     jupyter-lab
# MAGIC
# MAGIC ## Getting help <a id="part2sec4"></a>
# MAGIC Python and related modules are very well documented in local (docstrings) and on the Internet (documentation on the Internet may be clearer and updated compared to the local one).
# MAGIC To access the docstring, use *help*:

# COMMAND ----------

help(print)

# COMMAND ----------

# MAGIC %md
# MAGIC In a notebook (or IPython), you can also use *?* and SHIFT+TAB:
# MAGIC
# MAGIC <img src="http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/img/help.png" width=1000>

# COMMAND ----------

# MAGIC %md
# MAGIC Otherwise, you can search the net for an answer.
# MAGIC The easiest way is to google your query: [vandermonde matrix python](https://www.google.fr/?client=ubuntu#channel=fs&q=vandermonde+matrix+python&gfe_rd=cr).
# MAGIC
# MAGIC Finally, you can go directly to a package documentation website.
# MAGIC The following links provide the documentation of the packages used in this introduction (see next sections for details on the packages):
# MAGIC - [official documentation](https://docs.python.org/3.5/tutorial/index.html);
# MAGIC - [Scipy](http://docs.scipy.org/doc/scipy/reference/);
# MAGIC - [Numpy](http://docs.scipy.org/doc/numpy/reference/);
# MAGIC - [Statsmodels](http://www.statsmodels.org/stable/index.html);
# MAGIC - [Scikit-learn](http://scikit-learn.org/stable/documentation.html).
# MAGIC
# MAGIC # An introduction to JupyterLab <a id="part3"></a>
# MAGIC A notebook is a sequence of cells that may be of two types:
# MAGIC - code: it enables to edit, execute and see the output of a small Python script;
# MAGIC - markdown: if offers a way to write text and equations, as well as to import images.
# MAGIC
# MAGIC ## Survival kit <a id="part3sec1"></a>
# MAGIC A Jupyter notebook can be modified in two modes:
# MAGIC - the command mode: we can add, delete and modify cells;
# MAGIC - the edit mode: we can edit and run the script inside a cell.
# MAGIC
# MAGIC The forthcoming sections describe the most useful keyboard shortcuts.
# MAGIC An exhaustive list of the available actions and shortcuts can be found by hitting the palette in the menu bar (or CTRL+SHIFT+C).
# MAGIC
# MAGIC It is highly recommended to experience these shortcuts on your own on the test cell below.
# MAGIC
# MAGIC ### Command shortcuts
# MAGIC If you are in the edit mode, press ESC to enter the command mode.
# MAGIC
# MAGIC - To edit a cell (enter the edit mode), go to the desired cell and press ENTER.
# MAGIC - To add a cell below, press B.
# MAGIC - To add a cell above, press A.
# MAGIC - To cut a cell, press X.
# MAGIC - To copy a cell, press C.
# MAGIC - To paste a cell below, press V.
# MAGIC - To delete a cell, press DD.
# MAGIC - To convert a cell to a markdown cell, press M.
# MAGIC - To convert a cell to a code cell, press Y.
# MAGIC
# MAGIC ### Edit shortcuts
# MAGIC If you are in the command mode, press ENTER to enter the edit mode.
# MAGIC
# MAGIC - To run a cell, press CTRL+ENTER.
# MAGIC - To run a cell and select the one below, press SHIFT+ENTER.
# MAGIC - To run a cell and add one below, press ALT+ENTER.
# MAGIC - To apply autocompletion, press TAB at the end of the word. For example, write "pri", then press TAB.
# MAGIC It gives "print".
# MAGIC - To get an inline help, press SHIFT+TAB.
# MAGIC - To indent several lines, select them and press TAB.
# MAGIC - To dedent several lines, select them and press SHIFT+TAB.
# MAGIC - To (un)comment a line (or several ones after selection), press CTRL+/.
# MAGIC - To exit the edit mode, press ESC.
# MAGIC

# COMMAND ----------

print("This is a test cell")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Useful features <a id="part3sec2"></a>
# MAGIC ### Code console
# MAGIC You can open a code console by clicking the + button in the file browser and selecting the kernel.
# MAGIC It enables you to run interactively small part of codes in a console, keeping the history in full view.
# MAGIC
# MAGIC Such a code console can also be opened or linked to a Python file.
# MAGIC This is a way to run a part of code directly from a Python file.
# MAGIC To do so, when editing this file, right-click in it and  select *Create Console for Editor*. Then, select a single line or a block of code and send it to the code console by hitting SHIFT+ENTER.
# MAGIC
# MAGIC ### Mirrored output
# MAGIC You can create a new synchronized view of a cell output by right-clicking a cell and hitting *Create New View for Output*.
# MAGIC This view can then be moved to a separate tab.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Text and equations <a id="part3sec3"></a>
# MAGIC By default, cells are for code but they can be converted to markdown cells (see the shortcut above).
# MAGIC Markdown cells accept both [Markdown](https://jupyter-notebook.readthedocs.io/en/stable/examples/Notebook/Working%20With%20Markdown%20Cells.html) (text formatting) and [LaTeX](https://fr.wikipedia.org/wiki/Aide:Formules_TeX) (equations).
# MAGIC
# MAGIC ### General formatting
# MAGIC Headings are defined with the symbol `#`:
# MAGIC     # First level
# MAGIC     ## Second level
# MAGIC     ### Third level
# MAGIC     #### Fourth level
# MAGIC     ##### Fifth level
# MAGIC     
# MAGIC Even though paragraphs are defined automatically, you can force a line break with the code `<br>` or draw a horizontal line with `***`.
# MAGIC ***
# MAGIC
# MAGIC ### Items, emphasis and colors
# MAGIC Lists can be characterized by bullets, using `-`:
# MAGIC - Bullet 1;
# MAGIC - Bullet 2;
# MAGIC or by numbers, using `1.`:
# MAGIC 1. first item;
# MAGIC 1. second item.
# MAGIC
# MAGIC Lists can also be nested thanks to indented symbols:
# MAGIC - Bullet 1;
# MAGIC     1. Item 1;
# MAGIC     2. Item 2.
# MAGIC - Bullet 2;
# MAGIC     1. a single item.
# MAGIC
# MAGIC Emphasis can be done by **bold** (using `**text**`) or *italic* font (using `*text*`).
# MAGIC
# MAGIC Colors are defined by the code `<font color=blue|red|green|pink|yellow>text</font>`.
# MAGIC This has to be used carefully since it is more html code than Markdown scripting.
# MAGIC
# MAGIC ### Raw text and quoting
# MAGIC You can use inline raw text for path and file names using the single quote symbol ` or indentation for blocs.
# MAGIC
# MAGIC For instance, this is a `# raw text`, while this is a raw bloc:
# MAGIC
# MAGIC     raw text
# MAGIC     with multiple lines.
# MAGIC     
# MAGIC You can also quote by using `>`:
# MAGIC     
# MAGIC > A mathematician is a device for turning coffee into theorems.<br>
# MAGIC Paul Erdos
# MAGIC
# MAGIC ### Images and references
# MAGIC
# MAGIC You can add an image with `![text](URL)`:
# MAGIC
# MAGIC ![Picture by Vincent Delerm](http://photo.vincent-delerm.com/wp-content/uploads/2018/03/F1060019.jpg)
# MAGIC
# MAGIC > Picture by [Vincent Delerm](http://vincent-delerm.com/).
# MAGIC
# MAGIC You may also use `<img src="URL" width=WIDTH>` to resize the image.
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC References can be made to external links with `[text](URL)` and to internal labels with `[text](#label)`, where a tag `<a id="label"></a>` has been put somewhere in the notebook.
# MAGIC
# MAGIC ### Equations
# MAGIC Equations should be written in the LaTeX language, for which help is [available](https://fr.wikipedia.org/wiki/Aide:Formules_TeX).
# MAGIC If you know the symbol and want to obtain the LaTeX command, you can [detexify](http://detexify.kirelabs.org/classify.html) it.
# MAGIC
# MAGIC You only need basics of LaTeX:
# MAGIC - Inline equation with `$equation$`: $x = \sqrt{2}$.    
# MAGIC - Centered equation with
# MAGIC
# MAGIC
# MAGIC         $$
# MAGIC         [equation]
# MAGIC     $$
# MAGIC
# MAGIC For instance:
# MAGIC $$
# MAGIC     \int_0^1 1 \, dx = 1.
# MAGIC $$
# MAGIC - Multiple line equation with
# MAGIC
# MAGIC
# MAGIC         \begin{align}
# MAGIC         item &= item \\
# MAGIC         &= item.
# MAGIC     \end{align}
# MAGIC
# MAGIC For instance:
# MAGIC \begin{align}
# MAGIC     \int_0^1 1 \, dx &= \frac{1}{2} \int_0^1 2 \, dx\\
# MAGIC     &= \frac{1}{2} \cdot 2 \\
# MAGIC     &= 1.
# MAGIC \end{align}
# MAGIC - Exponents and subscripts with `^` and `_`: $x_{i}^2$.
# MAGIC - Summation and product with `\sum_{i=1}^n` and `\prod_{i=1}^n`: $\sum_{i=1}^n \prod_{j=1}^m x_{ij}$.
# MAGIC - Real numbers with `\mathbb`: $\forall x \in \mathbb R^d$.
# MAGIC - Calligraphic letters with `\mathcal`: $\mathcal N(0, 1)$.
# MAGIC - Big parentheses with `\left(… \right)`: $\left( \frac{1}{n} \sum_{i=1}^n x_i \right)$.

# COMMAND ----------

# MAGIC %md
# MAGIC # Basics of the Python language <a id="part4"></a>
# MAGIC ## Numbers <a id="part4sec1"></a>
# MAGIC ### Integer, floats and complex

# COMMAND ----------

a = 1  # Integer
b = 1.  # Float
c = 1.+2.j  # Complex

# COMMAND ----------

print(a)
type(a)

# COMMAND ----------

print(b)
type(b)

# COMMAND ----------

print(c)
type(c)

# COMMAND ----------

print(c.real, c.imag)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC What are the result and the type of the following expressions:
# MAGIC - 3+5.;
# MAGIC - 16 * 4;
# MAGIC - 8 / 2;
# MAGIC - 2 * 10 / 2?

# COMMAND ----------

# Answer
x = 3 + 5.
print(x, type(x))

x = 16 * 4
print(x, type(x))

x = 8 / 2
print(x, type(x))

x = 2 * 10 / 2
print(x, type(x))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Booleans

# COMMAND ----------

test = True
type(test)

# COMMAND ----------

print(test and a == 1)

# COMMAND ----------

print(test or a == 2)

# COMMAND ----------

print(a != 1)

# COMMAND ----------

print(test and not a == 1)

# COMMAND ----------

# MAGIC %md
# MAGIC A Boolean is a number:

# COMMAND ----------

print(int(test))  # Cast Boolean to int

# COMMAND ----------

print(test+1, test-1, test*3.2)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Write an expression that returns:
# MAGIC - $-1$ if $x \le -1$;
# MAGIC - $1$ if $x \ge 1$;
# MAGIC - x otherwise.

# COMMAND ----------

# Answer
x = -10
print(-1 * (x<-1) + x * (-1<=x<=+1) + (x>1))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Swap variables in a concise manner

# COMMAND ----------

abis = 3
print(a, abis)

a, abis = abis, a  # Swap variables
print(a, abis)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Operations
# MAGIC Integers, floats, complex numbers and Booleans benefit from usual arithmetic operations.
# MAGIC
# MAGIC - Addition:

# COMMAND ----------

print(a+2.3)

# COMMAND ----------

# MAGIC %md
# MAGIC - Subtraction:

# COMMAND ----------

print(b-3)

# COMMAND ----------

# MAGIC %md
# MAGIC - Multiplication:

# COMMAND ----------

print(c * 3)

# COMMAND ----------

# MAGIC %md
# MAGIC - Division:
# MAGIC     Beware: integers inherit from integer division in Python 2 and floating division in Python 3.

# COMMAND ----------

print(1/2)  # Returns 0 in Python 2 and 0.5 in Python 3

# COMMAND ----------

# MAGIC %md
# MAGIC A good practice is to use floating numbers:

# COMMAND ----------

print(1./2)
print(a/2.)

# COMMAND ----------

# MAGIC %md
# MAGIC As well as explicit integer division (note that the result is of type *int*):

# COMMAND ----------

a = 3//2
print(a, type(a))

# COMMAND ----------

# MAGIC %md
# MAGIC - Power:

# COMMAND ----------

print(10**3)

# COMMAND ----------

# MAGIC %md
# MAGIC - Modulo:

# COMMAND ----------

print(5%2)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Given two integers $x$ and $y$ such that $x \ge y$, compute and print the quotient of the Euclidean division of $x$ by $y$.
# MAGIC Do the same for the remainder (with two different expressions).

# COMMAND ----------

# Answer
x = 8
y = 3

q = x // y
r1 = x - y*q
r2 = x % y

print("Quotient:", q)
print("Remainder (v1):", r1)
print("Remainder (v2):", r2)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Data structures <a id="part4sec2"></a>
# MAGIC ### Strings
# MAGIC Strings are immutable objects (they cannot be modified), that can be defined with simple, double or triple quotes.
# MAGIC Simple and double quotes are equivalent:

# COMMAND ----------

test1 = "Wilcoxon"
test2 = 'Chi2'
print(test1)

# COMMAND ----------

# MAGIC %md
# MAGIC … Except for quotes themselves.
# MAGIC We write:

# COMMAND ----------

print("\"" + " or " + '"')

# COMMAND ----------

# MAGIC %md
# MAGIC And:

# COMMAND ----------

print('\'' + ' or ' + "'")

# COMMAND ----------

# MAGIC %md
# MAGIC Triple quotes allow to have several lines:

# COMMAND ----------

txt1 = """This is
a Wilcoxon test"""
print(txt1)

# COMMAND ----------

# MAGIC %md
# MAGIC This is equivalent to using the special character *\\n*:

# COMMAND ----------

txt2 = "This is\na Chi2 test"
print(txt2)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Operations on strings
# MAGIC Strings can be concatenated and repeated.

# COMMAND ----------

print(test1 + ", p=" + str(0.1))  # Concatenation
print(test2 * 3)  # Repetition

# COMMAND ----------

# MAGIC %md
# MAGIC We can change the case of a string.

# COMMAND ----------

print(test1.lower())
print(test2.upper())
print("mr. ".capitalize() + "tickle".capitalize())

# COMMAND ----------

# MAGIC %md
# MAGIC Strings can be joined with a given separator.

# COMMAND ----------

"-".join([test1, test2])

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Given the three variables below, produce the string:
# MAGIC
# MAGIC     outcome ~ xx + yy + zz

# COMMAND ----------

x = "Xx"
y = "YY"
z = "zZ"

# COMMAND ----------

# Answer
print("outcome ~ " + " + ".join([x.lower(), y.lower(), z.lower()]))

# COMMAND ----------

# MAGIC %md
# MAGIC #### String formatting and printing
# MAGIC Python 3 provides an improved string formatting syntax, called f-string.
# MAGIC In a nutshell, it is enough to put an *f* at the beginning and curly braces around expressions that should be replaced with their values.

# COMMAND ----------

print(f"The first test is {test1}, while the second is {test2}.")

# COMMAND ----------

# MAGIC %md
# MAGIC Multiline f-strings are allowed:

# COMMAND ----------

pval = 0.03

(f"The p-value for the {test1} test is: "
 f"{pval}")

# COMMAND ----------

# MAGIC %md
# MAGIC Or escaping a return with *\*:

# COMMAND ----------

f"The p-value for the {test1} test is: " \
f"{pval}"

# COMMAND ----------

# MAGIC %md
# MAGIC Using triple " will lead to:

# COMMAND ----------

print(f"""The p-value for the {test1} test is:
{pval}""")

# COMMAND ----------

# MAGIC %md
# MAGIC Format specifiers: `{value:{width}.{precision}}` can be used, mainly for numbers:

# COMMAND ----------

root = 0.123456789
print(f"The root is {root:.3f}.")
print(f"The root is {root:.2e}.")
print(f"The root is {root:10.2f}.")

# COMMAND ----------

# MAGIC %md
# MAGIC For a full support, see the [Format Specification Mini-Language](https://docs.python.org/3.6/library/string.html#formatspec).

# COMMAND ----------

# MAGIC %md
# MAGIC Strings can also be formatted in the old way:

# COMMAND ----------

print("The first test is {}, while the second is {}.".format(test1, test2))  # With positional arguments
print("The first test is {1}, while the second is {0}.".format(test1, test2))  # With numbered arguments
print("The first test is {T1}, while the second is {T2}."
      .format(T1=test1, T2=test2))  # With keywords arguments
print("The first test is {}, while the second is {T2}."
      .format(test1, T2=test2))
print("The root is {}.".format(0.123456789))  # Numbers can be printed directly or converted
print("The root is {0:.3f}.".format(0.123456789))
print("The root is {0:.2e}.".format(0.123456789))
print("The root is {0:10.2f}.".format(0.123456789))

# COMMAND ----------

# MAGIC %md
# MAGIC In the expression *x:y.zA*,
# MAGIC - *x* is the positioning parameter;
# MAGIC - *y* is the (minimum) number of (potentially blank) numbers before .;
# MAGIC - *z* is the (maximum) number of numbers after .;
# MAGIC - *A* is the formatting letter:
# MAGIC     - f: float;
# MAGIC     - e: exponential notation;
# MAGIC     - d: integer.

# COMMAND ----------

# MAGIC %md
# MAGIC Strings can also be formatted in the very old way:

# COMMAND ----------

print("An integer: %d" % 2)
print("A float: %f" % 0.123456789)
print("A short float: %0.2f" % 0.123456789)
print("A nice p-value: %0.1e" % 0.05)
print("%s is %d years old" % ("Robert", 64))

# COMMAND ----------

# MAGIC %md
# MAGIC When several arguments are given, *print* prints them all (the behavior is slightly different between Python 2 and Python 3).

# COMMAND ----------

print("string 1", "string 2")

# COMMAND ----------

# MAGIC %md
# MAGIC One can also control the end character:

# COMMAND ----------

print("Something to say", end="")  # Python 3
#print("Something to say"),  # Python 2
print("… and something else")

# COMMAND ----------

# MAGIC %md
# MAGIC **Remark:** objects can be printed simply by evaluating them:

# COMMAND ----------

test1

# COMMAND ----------

# MAGIC %md
# MAGIC To remove this side effect, use a semicolon:

# COMMAND ----------

test1;

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Given the three variables below, produce the sentence:
# MAGIC
# MAGIC     The expression x+y*z = 3+1.4142*5 approximately equals 1.01e+01.

# COMMAND ----------

x = 3
y = 2**0.5
z = 5

# COMMAND ----------

# Answer
print("The expression x+y*z = {x}+{y:0.4f}*{z} approximately equals {res:0.2e}."
      .format(x=x, y=y, z=z, res=x+y*z))

# COMMAND ----------

# MAGIC %md
# MAGIC ### List
# MAGIC A list is an ordered collection of items, that may have different types.
# MAGIC A list is a mutable object and can thus be modified.

# COMMAND ----------

l = [1, 3, 5, 7, "odd numbers"]
print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Indexing and slicing
# MAGIC Indexing starts at 0.

# COMMAND ----------

print("First item: ", l[0])  # First item
print("Last item: ", l[-1])  # Last item

# COMMAND ----------

# MAGIC %md
# MAGIC The slicing syntax is: *l[start:stop:stride]*.
# MAGIC If some arguments are omitted, they are replaced by the *natural* ones (start=0, stride=1).

# COMMAND ----------

print("First two items: ", l[:2])  # Equivalent to l[0:2]
print("Sublists: ", l[::2], l[1:3])  # First sublist equivalent to l[0::2]
print("Reverse: ", l[::-1])

# COMMAND ----------

# MAGIC %md
# MAGIC Note that, when slicing, the last element is not considered.

# COMMAND ----------

print(l[0:2])  # Items numbered 0 and 1 (2 excluded)
print(l[2:])  # All items after number 2 included
print(l[2:-1])  # All items after number 2 included, last item exluced

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Given the list below (of size denoted by $n$), print its head (the first $n-1$ items) and its tail (the last $n-1$ items).

# COMMAND ----------

x = [5, 3, 7, 8, 3, 4, 6]

# COMMAND ----------

# Answer
print("Head:", x[:-1])
print("Tail:", x[1:])

# COMMAND ----------

# MAGIC %md
# MAGIC #### Concatenation, extension and repetition

# COMMAND ----------

l = l+[9]  # Concatenation
print(l)

# COMMAND ----------

l += [11]  # Concatenation
print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC Extension is an in-place operation.

# COMMAND ----------

l.extend(["extension"])  # Extension
print(l)

# COMMAND ----------

l *= 2  # Repetition
print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Adding, deleting and indexing an item

# COMMAND ----------

l.append(13)  # Add an item at the end of the list
print(l)

# COMMAND ----------

del l[0]  # Delete the first item
print(l)

# COMMAND ----------

print("9 is in position", l.index(9))

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Move the first item of $x$ to the last position.

# COMMAND ----------

x = [5, 3, 7, 8, 3, 4, 6]

# COMMAND ----------

# Answer
x.append(x[0])
del x[0]
print(x)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Presence

# COMMAND ----------

print("2 is in l: ", 2 in l)
print("3 is in l: ", 3 in l)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Other operations

# COMMAND ----------

print(len(l))

# COMMAND ----------

l.reverse()
print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC More details: use *help(list)* or *list?* in Ipython and Jupyter notebook.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tuple
# MAGIC Roughly speaking, a tuple is an immutable list (it cannot be changed).
# MAGIC It can be defined in two ways:

# COMMAND ----------

t = (1, 2)  # Definition with parentheses
type(t)

# COMMAND ----------

t = 1, 2  # Light definition
print(t)

# COMMAND ----------

t += ("three",)  # Concatenation with a singleton
print(t)

print("Length: ", len(t))  # Length

# COMMAND ----------

t0, t1, t2 = t  # Unpacking
print(t0, t1, t2)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Sets
# MAGIC A set is an unordered collection of unique items.
# MAGIC Usual mathematical operations (union, difference) can be performed.

# COMMAND ----------

odd = set([1, 3, 5, 5])
even = set([2, 4])

type(odd)
print(odd)

# COMMAND ----------

print(odd - set([1]))  # Difference of sets

# COMMAND ----------

print(odd | even)  # Union of sets

# COMMAND ----------

odd.add(2)
print(odd & even)  # Intersection of sets

# COMMAND ----------

print(odd ^ even)  # Complementary of the intersection of sets

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Print items that are simultaneously in $x$ and $y$.

# COMMAND ----------

x = [5, 3, 7, 8, 3, 4, 6]
y = [1, 9, 3, 7, 6, 2]

# COMMAND ----------

# Answer
print(set(x) & set(y))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Dictionary
# MAGIC A dictionary is a table key/value.
# MAGIC Keys can be any immutable type (string, numbers, …).

# COMMAND ----------

d = {'x': [[1, -0.5], [-2, 1]], 'y': [0, 1]}  # Definition
print(d['x'])

# COMMAND ----------

d[10] = "ten"  # Add an item
print(d)

# COMMAND ----------

# Print keys and values
print(d.keys())
print(d.values())

# COMMAND ----------

"x" in d  # Check if a key is in the dictionary

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Add a new item to the dictionary defined below, with key "sigma2" and value $sigma^2$.
# MAGIC Set $mu$ to $0$ and print the final dictionary.

# COMMAND ----------

db = {'mu': 3, 'sigma': 1.5}

# COMMAND ----------

# Answer
db['sigma2'] = db['sigma']**2
db['mu'] = 0

print(db)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Assignment operator
# MAGIC In Python the assignment operator *=* is used for two purposes:
# MAGIC - modify attributes and items of mutable objects;
# MAGIC - bind a name to a value.
# MAGIC
# MAGIC The last point means that ** *=* does not make a copy** but creates a new alias for an already existing value.
# MAGIC
# MAGIC Examples:
# MAGIC - Immutable objects:

# COMMAND ----------

a = 1.1
b = a
b is a  # two names, same data (in memory)

# COMMAND ----------

print(id(a), id(b))

# COMMAND ----------

a = "monday"
b = a
b is a  # two names, same data (in memory)

# COMMAND ----------

a = 3, 10
b = a
b is a  # two names, same data (in memory)

# COMMAND ----------

# MAGIC %md
# MAGIC - Mutable objects:

# COMMAND ----------

a = [1, 2]
b = a
b is a  # two names, same data (in memory)

# COMMAND ----------

b[-1] = 3
print(a)
print(b)

# COMMAND ----------

# MAGIC %md
# MAGIC Modifications appear on both a and b (same data).
# MAGIC To make a copy, use:

# COMMAND ----------

b = a.copy()  # In Python 3
#b = a[:]  # In Python 2
b is a

# COMMAND ----------

b[-1] = 2
print(a)
print(b)

# COMMAND ----------

# MAGIC %md
# MAGIC *a* and *b* are two different objects.
# MAGIC
# MAGIC This is the same for dictionaries and sets:

# COMMAND ----------

a = {"k": 1}
b = a
b is a

# COMMAND ----------

b = a.copy()
b is a

# COMMAND ----------

a = set([1, 2])
b = a
b is a

# COMMAND ----------

b = a.copy()
b is a

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conditional statements <a id="part4sec3"></a>
# MAGIC In Python, the blocks of the control flows are delimited by indentation.
# MAGIC See for instance the use of `if/elif/else` statement.
# MAGIC The comparisons are made with `==`, `!=`, `is`, `in`, `not`, `<`, `<=`, …

# COMMAND ----------

h = 3.14  # Target
i = 3  # Guess

print("The target is", end=" ")
if h < i:
    print("less than %d." % i)
elif h > i:
    print("greater than %d." % i)
else:
    print("exactly %d." % i)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Write a conditional statement that:
# MAGIC - add y to x if y is missing in x;
# MAGIC - change y to -y in x otherwise.

# COMMAND ----------

x = [4, 2, 7]
y = 6

# COMMAND ----------

# Answer
if y in x:
    x[x.index(y)] = -y
else:
    x.append(y)
print(x)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Evaluating objects
# MAGIC `if [object]` is false for
# MAGIC - 0, 0.0 numbers;
# MAGIC - empty structures;
# MAGIC - False and None;
# MAGIC
# MAGIC and true otherwise.
# MAGIC
# MAGIC **Example**: checking if a list is empty.

# COMMAND ----------

a = []

if not a:
    print("Empty list.")

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Write a script that prints the result of the operation $x/y$ if $y \neq 0$ and "infinity" otherwise.

# COMMAND ----------

x = 10
y = 0

# COMMAND ----------

if y:
    print(x/y)
else:
    print("infinity")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Assignment operator
# MAGIC Conditional statements can also be used in union with the assignment operator:

# COMMAND ----------

res = "greater or equal" if h >= i else "less"
print("The target is " + res + " than %d." % i)

# COMMAND ----------

# MAGIC %md
# MAGIC ## For loop <a id="part4sec4"></a>
# MAGIC Example of a for loop:

# COMMAND ----------

for it in range(10):
    print(it, end=" ")
else:
    print("\nthe loop was not broken")

# COMMAND ----------

# MAGIC %md
# MAGIC Here, the optional `else` part is executed when the loop goes until the end.
# MAGIC If the loop is broken (such as in the following example), the `else` part is not executed.
# MAGIC Besides `break`, another interested keyword is `continue`. It skips the end of the current iteration.

# COMMAND ----------

for it in range(10):
    if it % 2 == 0:  # Even numbers
        continue
    if it > 8:
        break
    print(it, end=" ")
else:
    print("\nthe loop was not broken")

# COMMAND ----------

# MAGIC %md
# MAGIC A special feature of Python is to being able to iterate over the items of any sequence (range, list, tuple, dictionary, …).
# MAGIC
# MAGIC ### Range
# MAGIC The syntax for the range function is:
# MAGIC `range(stop)` or `rang(start, stop, step)` with third parameter optional.

# COMMAND ----------

for it in range(5):
    print(it, end=" ")

# COMMAND ----------

for it in range(10, 20, 3):
    print(it, end=" ")

# COMMAND ----------

# MAGIC %md
# MAGIC ### List

# COMMAND ----------

for car in ['WV', 'BMW', 2016]:
    print(car)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Tuple

# COMMAND ----------

for it in ("My favorite number", "is", 7):
    print(it, end=" ")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Dictionary

# COMMAND ----------

conf = {"Name": "NIPS", "Date": 2016, "Location": "Barcelona"}

for key in conf:
    print(key)

# COMMAND ----------

for key, value in conf.items():
    print(key, ":", value)

# COMMAND ----------

for key, value in sorted(conf.items()):
    print(key, ":", value)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Compute and print the first 10 items of the sequence
# MAGIC $$
# MAGIC     \begin{cases}
# MAGIC         u_0 &= 0 \\
# MAGIC         u_{n+1} &= 3u_n+2, \forall n \in \mathbb N.
# MAGIC     \end{cases}
# MAGIC $$

# COMMAND ----------

# Answer
x = 0

for it in range(10):
    print(x, end=" - ")
    x = 3*x+2

# COMMAND ----------

# MAGIC %md
# MAGIC ### Useful commands: enumerate and zip
# MAGIC The enumerate command provides the number associated to each item while zip makes a collection of pairs of items from two lists.

# COMMAND ----------

for i, val in enumerate(['WV', 'BMW', 2016]):
    print(val, "(item %d)" % i)

# COMMAND ----------

for x, y in zip([1, 0, -1, 0], [0, 1, 0, -1]):
    print("x =", x, ", y =", y)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Produce the following output:
# MAGIC
# MAGIC     BBC was launched in 1992.
# MAGIC     CNN was launched in 1980.
# MAGIC     FOX NEWS was launched in 1996.

# COMMAND ----------

x = ['BBC', 'CNN', 'FOX NEWS']
y = [1992, 1980, 1996]

# COMMAND ----------

# Answer
for channel, year in zip(x, y):
    print("{} was launched in {}.".format(channel, year))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Making a list in a concise manner:
# MAGIC (also called *list comprehensions*)

# COMMAND ----------

l = [a**2 for a in range(10)]
print(l)

# COMMAND ----------

l = [a**2 for a in range(10) if a%2 == 0]
print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Build the list of square root values of items in $x$.

# COMMAND ----------

x = [1.5, 41., .413, 5.13, 3.4, 8.74]

# COMMAND ----------

# Answer
print([i**0.5 for i in x])

# COMMAND ----------

# MAGIC %md
# MAGIC ## While loop <a id="part4sec5"></a>
# MAGIC Akin to the `for` statement, the `while` loop benefits from the keywords `break`, `continue` and `else`.

# COMMAND ----------

v = 0
while v**2 < 10:
    v += .01
else:
    print("the loop was not broken")

print("sqrt(10) is approximately {0:.2f}".format(v-.01))

# COMMAND ----------

# MAGIC %md
# MAGIC Write a loop that finds the floor value of $x$.

# COMMAND ----------

x = 12.3

# COMMAND ----------

# Answer
y = 0
while y <= x:
    y += 1
y -= 1
print(y)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Function <a id="part4sec6"></a>
# MAGIC A function is defined with the keyword `def`:

# COMMAND ----------

def test():
    """Test function
    
    This function prints \"This is a test\"
    """
    print("This is a test")

test()

# COMMAND ----------

# MAGIC %md
# MAGIC The documentation string (or docstring) of the function appears when one uses *help* or *?*:

# COMMAND ----------

test?

# COMMAND ----------

# MAGIC %md
# MAGIC Note that a function is an object like an integer or a list.

# COMMAND ----------

type(test)

# COMMAND ----------

f = test
f()

# COMMAND ----------

# MAGIC %md
# MAGIC Functions can also return a result:

# COMMAND ----------

def add(a, b):
    return a+b

print(add(1, 2))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Parameters
# MAGIC A function can have two kinds of parameters:
# MAGIC - mandatory parameters;
# MAGIC - optional parameters.
# MAGIC Optional parameters always come after mandatory ones and are defined with default values.
# MAGIC In the following example, *name* is mandatory, while *age* and *job* are optional.

# COMMAND ----------

def identity(name, age=39, job="trader"):
    print("My name is %s." % name)
    print("I am a %s and I am %d years old." % (job, age))
    print()

identity("Picasso", 40, "painter")
identity("Kerviel")

# COMMAND ----------

# MAGIC %md
# MAGIC In this example, the function is called with positional arguments.
# MAGIC This means that the order of the parameters should be the same as in the definition.
# MAGIC However, parameters can also be passed with their keyword.
# MAGIC In this case, the order is not significant.

# COMMAND ----------

identity(job="musician", name="Armstrong", age=42)

# COMMAND ----------

# MAGIC %md
# MAGIC When both techniques are mixed, positional arguments always come before keyword arguments.

# COMMAND ----------

identity("Bach", job="composer")

# COMMAND ----------

# MAGIC %md
# MAGIC One can check if a parameter has been passed using the neutral value *None*:

# COMMAND ----------

def init_f(a, b=None):
    if b is None:
        b = a + 1
    return a, b

print(init_f(1, 3))
print(init_f(1))

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Write a function, called *sq*, that has two arguments: *x* and *gamma* (default value: 1) and that returns $gamma ~\times~ x^2$.

# COMMAND ----------

# Answer
def sq(x, gamma=1.):
    return gamma * x**2

sq(2)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Packing and unpacking arguments
# MAGIC Parameters can be packed in a tuple or a dictionary and unpacked when calling a function.

# COMMAND ----------

tuple_arg = ("Diniz", 38, "race walker")
identity(*tuple_arg)

# COMMAND ----------

dic_arg = {"job": "judoka", "age": 27, "name": "Riner"}
identity(**dic_arg)

# COMMAND ----------

# MAGIC %md
# MAGIC Respectively, a function can be defined with packed arguments.
# MAGIC This makes it possible to allow an arbitrary number of arguments.

# COMMAND ----------

def student(level="B1", *args, **kwargs):
    identity(**kwargs)
    print("I am also a student (level {}).".format(level))
    print("I study ", end="")
    for it in args[:-1]:
        print(it, end=", ")
    print("and ", args[-1], ".")

student("M2", "Statistics", "Machine learning", name="John", job="violonist", age=22)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Write a function that prints the number of arguments and each of its arguments on a separate line.

# COMMAND ----------

def my_print(*args):
    print("Number of arguments:", len(args))
    for arg in args:
        print(arg)
        
my_print(1, 2, "3")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Modifying parameters
# MAGIC Like in other languages, a function can modifier some parameters.
# MAGIC The rule is:
# MAGIC - if an argument is mutable, then it can be modified inside a function;
# MAGIC - if an argument is immutable, it cannot be modified.

# COMMAND ----------

def repeat(*args):
    for it in args:
        it *= 2

a = (1, 2)  # Immutable
b = [1, 2]  # Mutable

repeat(a, b)
print(a, b)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Lambda expressions
# MAGIC A lambda function is a small anonymous function, that is restricted to a single expression.
# MAGIC It is generally used as an argument to or an output from a usual function.

# COMMAND ----------

def apply(x, fun=lambda x: x):
    return [fun(item) for item in x]

def arithmetic_progression(a=0, b=1):
    return lambda n: a + n*b

# COMMAND ----------

f = arithmetic_progression(1, 2)

print(apply(range(10), f))

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Given the function $sq$ (created just before), define a lambda function that returns $4x^2$.

# COMMAND ----------

sq4 = lambda x: sq(x, gamma=4)

print(sq4(2))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Methods
# MAGIC Since Python is an object-oriented programming language, objects always come with functions linked to them.
# MAGIC These functions are called *methods* and generally modify directly the variable they are called with.
# MAGIC For instance:

# COMMAND ----------

l = [1, 3, 5]
l.reverse()  # l is reversed (thus modified)
print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC To know the methods associated to an object (here the list *l*), write:
# MAGIC     
# MAGIC     l.
# MAGIC     
# MAGIC then press TAB.
# MAGIC To obtain an inline help concerning a method (here list.reverse), write:
# MAGIC
# MAGIC     l.reverse
# MAGIC
# MAGIC then press SHIFT+TAB.

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Sort the previous list.

# COMMAND ----------

# Answer
l.sort()
print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Modules <a id="part4sec7"></a>
# MAGIC ### Loading modules
# MAGIC Up to now, we only experienced internal features of Python.
# MAGIC Yet, our interest will next focus on external tools.
# MAGIC These tools are stored in modules, which can be loaded in several manners.

# COMMAND ----------

import sys  # Load the sys module
import numpy as np  # Load the numpy module with the name np
from scipy import stats  # Load the stats submodule from the scipy module
from scipy.linalg import inv  # Load the matrix inversion function from a submodule
from statsmodels import *  # Import evrything from the statsmodels module

# COMMAND ----------

# MAGIC %md
# MAGIC The last manner is not recommended since it can create name clashes between modules and makes the code harder to read and to understand.
# MAGIC
# MAGIC To know the content of a module, use `dir`:

# COMMAND ----------

dir(sys)[-10:]

# COMMAND ----------

# MAGIC %md
# MAGIC Now, modules content can be accessed in the following manner:

# COMMAND ----------

print(np.pi)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Compute $e^{-1}$.

# COMMAND ----------

# Answer
print(np.exp(-1))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Handling the path and creating modules
# MAGIC To be found by Python, modules should be stored in a directory of *sys.path*:

# COMMAND ----------

sys.path

# COMMAND ----------

# MAGIC %md
# MAGIC If your module is stored in another directory, add it to the Python path:

# COMMAND ----------

sys.path.append('./aux/')

# COMMAND ----------

# MAGIC %md
# MAGIC Now, to create a module in the directory `./aux/`, store the functions and variables definitions (see cell below) in a Python file, named `my_module.py` (for example using Spyder).
# MAGIC Then, you can write:
# MAGIC
# MAGIC     %load aux/my_module.py
# MAGIC     
# MAGIC to know the content of the file `aux/my_module.py`.

# COMMAND ----------

# %load aux/my_module.py
"""
Test module.

Author: Maxime Sangnier
"""

def f1():
    print("Function 1")

def f2():
    print("Function 2")

pi = 3.14

if __name__ == "__main__":
    f1()  # Example of using this module



# COMMAND ----------

import my_module as m
m?

# COMMAND ----------

m.f2()

# COMMAND ----------

# MAGIC %md
# MAGIC In Python 2, if you modify your module, reload it this way:
# MAGIC
# MAGIC     reload(m)
# MAGIC    
# MAGIC otherwise changes won't be considered.

# COMMAND ----------

# MAGIC %md
# MAGIC The last part of the module is executed when `my_module.py` is run as a script:

# COMMAND ----------

run aux/my_module.py

# COMMAND ----------

# MAGIC %md
# MAGIC # Exercises <a id="part5"></a>
# MAGIC ## Exercise 1 <a id="part5sec1"></a>
# MAGIC
# MAGIC Create a separate notebook and reproduce the output provided below.
# MAGIC Then, export your new notebook to an `html` file and send it to this [remote repository](https://www.dropbox.com/request/mJw1HxVjOkMSAqD5WHZD).
# MAGIC
# MAGIC <img src="http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/img/example.png" width=1000>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 2 <a id="part5sec2"></a>
# MAGIC Create the following list with loops:
# MAGIC
# MAGIC     [['car', 0, 1, 4, 9, 16],
# MAGIC      ['bus', 1, 4, 9, 16, 25],
# MAGIC      ['train', 4, 9, 16, 25, 36]]
# MAGIC

# COMMAND ----------

# Answer
tab_list = []
for it, name in enumerate(['car', 'bus', 'train']):
    tab_list.append([name])
    tab_list[-1] += [n**2 for n in range(it, 5+it)]
tab_list

# COMMAND ----------

# MAGIC %md
# MAGIC Create a script that prints this list in the following manner:
# MAGIC
# MAGIC     car      0    1    4    9   16
# MAGIC     bus      1    4    9   16   25
# MAGIC     train    4    9   16   25   36
# MAGIC

# COMMAND ----------

# Answer
for row in tab_list:
    for item in row:
        if type(item) is str:
            print('{0:5s}'.format(item), end='')
        else:
            print('{0:5d}'.format(item), end='')
    print('')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 3 <a id="part5sec3"></a>
# MAGIC Create a function that returns the sum log of all its parameters (use the `log` function from the `math` module).
# MAGIC

# COMMAND ----------

# Answer
from math import log

def sumlog(*p):
    s = 0.
    for item in p:
        s += log(item)
    return s

sumlog(2, 3, 5, 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 4 <a id="part5sec4"></a>
# MAGIC For the following list of dictionaries, write a script that adds a field *registrations* which is twice the number of accepted papers.

# COMMAND ----------

confs = [{"Name": "NIPS", "Date": 2016, "Location": "Barcelona", "acc_papers": 300},
         {"Name": "ICML", "Date": 2016, "Location": "New York City", "acc_papers": 450},
         {"Name": "ICML", "Date": 2015, "Location": "Lille", "acc_papers": 250},
         {"Name": "AISTATS", "Date": 2016, "Location": "Cadiz", "acc_papers": 100}]

# COMMAND ----------

# Answer
for conf in confs:
    conf["registrations"] = 2*conf["acc_papers"]

confs

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 5 <a id="part5sec5"></a>
# MAGIC Write a function `append`, that produces the following results:
# MAGIC
# MAGIC     l = [1]
# MAGIC     append(l, 5)
# MAGIC     print(l)
# MAGIC     [1, 5]
# MAGIC     append(l, "-1")
# MAGIC     print(l)
# MAGIC     [1, 5, '-1']
# MAGIC     append(l)
# MAGIC     print(l)
# MAGIC     []
# MAGIC

# COMMAND ----------

# Answer
def append(l, a=None):
    if a is not None:
        l.append(a)
    else:
        l.clear()

l = [1]
append(l, 5)
print(l)
append(l, "-1")
print(l)
append(l)
print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 6 <a id="part5sec6"></a>
# MAGIC With the code editor, create a module, that contains two functions:
# MAGIC - fibonacci(n): computes the $n^{th}$ [Fibonacci number](https://en.wikipedia.org/wiki/Fibonacci_number);
# MAGIC - wallis(n): computes an approximation of $\pi$ using the [Wallis product](https://en.wikipedia.org/wiki/Wallis_product).
# MAGIC
# MAGIC Write a script, that uses these two functions.

# COMMAND ----------

# Answer
# %load aux/fibwallis.py
"""
A module to compute Fibonacci numbers and Wallis approximation of pi.

Author: Maxime Sangnier
"""


def fibonacci(n):
    """Compute a Fibonacci number.

    fibonacci(integer) -> integer

    With a non-negative parameter, return the nth Fibonacci number. Else,
    return None.
    """

    if n < 0:
        return None
    else:
        if n < 2:
            return 0 if n == 0 else 1
        else:
            return fibonacci(n-1) + fibonacci(n-2)


def wallis(n):
    """Compute an approximation of pi with Wallis product.

    wallis(integer) -> float

    Compute the product of the n first terms of Wallis product.
    """
    p = 1.
    for it in range(n):
        p *= 4.*(it+1)**2 / (4.*(it+1)**2-1)
    return 2*p

if __name__ == "__main__":
    print(fibonacci(12))
    print(wallis(500))


# COMMAND ----------

# Answer
from fibwallis import *
from math import pi
import matplotlib.pyplot as plt
%matplotlib inline

plt.plot([fibonacci(n) for n in range(10)])
plt.grid()

# COMMAND ----------

# Answer
plt.plot([wallis(n) for n in range(50)])
plt.plot((0, 49), (pi, pi), 'r')
plt.grid()

# COMMAND ----------

# MAGIC %md
# MAGIC # References <a id="part6"></a>
# MAGIC - [JupyterLab documentation](https://jupyterlab.readthedocs.io/en/latest/index.html).
# MAGIC - [Official documentation](https://docs.python.org/3/tutorial/index.html).
# MAGIC - [Scipy lecture notes](http://www.scipy-lectures.org/index.html).
# MAGIC - [Allen Downey's book](http://www.greenteapress.com/thinkpython/thinkpython.pdf).