# Databricks notebook source
# MAGIC %md
# MAGIC # Introduction to scientific computing with Python
# MAGIC *Maxime Sangnier*
# MAGIC
# MAGIC September, 2020
# MAGIC
# MAGIC ## Part 2: Plotting
# MAGIC This part is aimed at introducing the most used Python package for 2D-plotting: [Matplotlib](http://matplotlib.org/contents.html).

# COMMAND ----------

# MAGIC %md
# MAGIC # Table of contents
# MAGIC 1. [Plotting curves](#part1)
# MAGIC     - [First example](#part1sec1)
# MAGIC     - [Matplotlib APIs](#part1sec2)
# MAGIC     - [Customization](#part1sec3)
# MAGIC     - [Interactive mode](#part1sec4)
# MAGIC     - [Seaborn](#part1sec5)
# MAGIC 1. [Other plots ](#part2)
# MAGIC     - [Image](#part2sec1)
# MAGIC     - [Scatter](#part2sec2)
# MAGIC     - [Stem ](#part2sec3)
# MAGIC     - [Histogram](#part2sec4)
# MAGIC     - [Bar chart](#part2sec5)
# MAGIC     - [3D plotting](#part2sec6)
# MAGIC     - [Pie chart](#part2sec7)
# MAGIC 1. [Saving figures](#part3)
# MAGIC 1. [A detour to TensorBoard](#part4)
# MAGIC 1. [Exercises](#part5)
# MAGIC     - [Exercise 1](#part5sec1)
# MAGIC     - [Exercise 2](#part5sec2)
# MAGIC     - [Exercise 3](#part5sec3)
# MAGIC     - [Exercise 4](#part5sec4)
# MAGIC     - [Exercise 5](#part5sec5)
# MAGIC     - [Exercise 6](#part5sec6)
# MAGIC 1. [References](#part6)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Plotting curves <a id="part1"></a>
# MAGIC ## First example <a id="part1sec1"></a>
# MAGIC

# COMMAND ----------

import matplotlib.pyplot as plt
from numpy import abs, sin, cos, arange, pi, exp, linspace, random

# COMMAND ----------

# MAGIC %md
# MAGIC We give here a minimal example of plotting a sine curve with matplotlib.

# COMMAND ----------

x = arange(0, 2*pi, step=1e-1)
y1 = sin(x)

plt.plot(x, y1);
#plt.show()  # In Spyder only

# COMMAND ----------

# MAGIC %md
# MAGIC Remark: some functions (such as plot) return a `Line2D` object.
# MAGIC This may produce an additional output
# MAGIC
# MAGIC     [<matplotlib.lines.Line2D at 0x7fdafd5e7eb8>]
# MAGIC
# MAGIC To inhibt this, add `;` at the end of the last line.

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Plot $x \mapsto e^{-x}$ for $x \in [-1, 10]$.

# COMMAND ----------

# Answer
t = arange(-1, 10, step=1e-1)
plt.plot(t, exp(-t));

# COMMAND ----------

# MAGIC %md
# MAGIC ## Matplotlib APIs <a id="part1sec2"></a>
# MAGIC Matplotlib offers two application programming interfaces (APIs): the pyplot and the object-oriented API.
# MAGIC
# MAGIC The pyplot API is a procedural manner of plotting: the user defines a sequence of line codes for creating a figure, plotting, and so on.
# MAGIC In the example above, we have used the pyplot API.
# MAGIC With it, it is very easy to produce many kinds of plots quickly.
# MAGIC
# MAGIC Matplotlib can also be manipulated by way of the object-oriented API.
# MAGIC It is a more robust and customizable way of plotting.
# MAGIC Here, the user has to know that a plot is mainly made of two objects: a figure and a set of axes.
# MAGIC Roughly speaking, the figure is the big box in which everything is put (it is the top level container).
# MAGIC For instance, a figure is characterized by a size, a title and a facecolor.
# MAGIC
# MAGIC The axes are the plots themselves.
# MAGIC There can be several plots inside a figure (also called subplots) and they are, for example, characterized by ticks, limits on x and y, a legend and a title.
# MAGIC The axes contain the curves plotted.
# MAGIC
# MAGIC In this tutorial, we focus on the object-oriented API (even though scripts for the pyplot API are also given in comments), for which the minimal example given above is rewritten below.

# COMMAND ----------

fig, ax = plt.subplots()  # Create a figure with a single Axes object

# This is similar to:
# fig = plt.figure()
# ax = fig.add_subplot(1, 1, 1)  # 1 row, 1 column, first item

ax.plot(x, y1);  # Create a curve in ax
# fig.show()  # Show the figure (in Spyder only)

# COMMAND ----------

# MAGIC %md
# MAGIC Among many advantages of using the object-oriented interface of Matplotlib, one is to redraw a figure by calling it, and to add plots.

# COMMAND ----------

fig

# COMMAND ----------

ax.plot(x, y1+1)
fig

# COMMAND ----------

# MAGIC %md
# MAGIC ## Customization <a id="part1sec3"></a>
# MAGIC ### Grid
# MAGIC You can see here how to add a grid to the plot.
# MAGIC Grid intevals are defined by ticks.
# MAGIC To change these intervals, change the ticks (see below).
# MAGIC
# MAGIC For log-plots, you can use:
# MAGIC
# MAGIC     plt.grid(which="both")
# MAGIC     
# MAGIC to draw both major and minor tick grids.

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1)
ax.grid();

# Pyplot API
# plt.plot(x, y1);
# plt.grid()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Axes labels and title

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1)
ax.grid()
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title('Sine curve');

# Pyplot API
# plt.plot(x, y1)
# plt.grid()
# plt.xlabel("x")
# plt.ylabel("y")
# plt.title("Sine curve");

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Plot again $x \mapsto e^{-x}$ for $x \in [-1, 10]$ and add a grid, axis labels and a title.

# COMMAND ----------

# Answer
fig, ax = plt.subplots()
ax.plot(t, exp(-t))
ax.set_xlabel('x')
ax.set_ylabel('y')
ax.set_title('Exponential function')
ax.grid()

# Pyplot API
# plt.plot(t, exp(-t))
# plt.xlabel('x')
# plt.ylabel('y')
# plt.title('Exponential function')
# plt.grid()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Legend
# MAGIC There are two manners to plot a legend.
# MAGIC The first one is to label each curve separately.

# COMMAND ----------

y2 = cos(x)

fig, ax = plt.subplots()
ax.plot(x, y1, label="sin")
ax.plot(x, y2, label="cos")
ax.grid()
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("Sine and cosine curves")
ax.legend(loc="upper center");

# Pyplot API
# plt.plot(x, y1, label="sin")
# plt.plot(x, y2, label="cos")
# plt.grid()
# plt.xlabel("x")
# plt.ylabel("y")
# plt.title("Sine and cosine curves")
# plt.legend(loc="upper center");

# COMMAND ----------

# MAGIC %md
# MAGIC The second one is to give a list of labels to the function `legend`.

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1)
ax.plot(x, y2)
ax.grid()
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("Sine and cosine curves")
ax.legend(("sin", "cos"), loc="lower left");

# Pyplot API
# plt.plot(x, y1)
# plt.plot(x, y2)
# plt.grid()
# plt.xlabel("x")
# plt.ylabel("y")
# plt.title("Sine and cosine curves")
# plt.legend(("sin", "cos"), loc="lower left");

# COMMAND ----------

# MAGIC %md
# MAGIC Note that all location strings are available in the [legend properties](http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.legend).
# MAGIC Furthermore, the font size and the marker scale can be changed thanks to the properties `fontsize` and `markerscale` of `plt.legend`.
# MAGIC
# MAGIC Let us remark that the legend can be further modified and placed outside the curve box:

# COMMAND ----------

fig, ax = plt.subplots()
for p, s in [(0, '0'),
             (pi/2, r'$\pi/2$'),
             (pi, r'$\pi$'),
             (3*pi/2, r'$3\pi/2$')]:
    ax.plot(x, sin(x+p), label=r"phase " + s)
ax.grid()
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.legend(loc="upper center", bbox_to_anchor=(0.5, 1.3), ncol=2, shadow=True);

# Pyplot API
# for p, s in [(0, '0'),
#              (pi/2, r'$\pi/2$'),
#              (pi, r'$\pi$'),
#              (3*pi/2, r'$3\pi/2$')]:
#     plt.plot(x, sin(x+p), label=r"phase " + s)
# plt.grid()
# plt.xlabel("x")
# plt.ylabel("y")
# plt.legend(loc="upper center", bbox_to_anchor=(0.5, 1.3), ncol=2, shadow=True);

# COMMAND ----------

# MAGIC %md
# MAGIC Here:
# MAGIC - `r"…"` is for LaTeX support;
# MAGIC - `bbox_to_anchor=(0.5, 1.3)` means that the upper center of the legend is halfway through the x axis, and 0.3 above the curve box;
# MAGIC - `ncol=2` means that the legend spans two columns;
# MAGIC - `shadow=True` draws a shadow behind legend.

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Plot on the same figure the curves of $x \mapsto e^{- \gamma |x|}$ for $x \in [-1, 1]$ and $\gamma \in \{0.5, 1, \dots, 5\}$.
# MAGIC
# MAGIC Add a grid and a legend in a box outside on the right of the figure.

# COMMAND ----------

# Answer
t = arange(-1, 1, step=1e-2)

fig, ax = plt.subplots()
for gamma in arange(0.5, 5.5, step=0.5):
    ax.plot(t, exp(-gamma*abs(t)), label=r"$\gamma={}$".format(gamma))

ax.grid()
ax.legend(loc="right", bbox_to_anchor=(1.25, 0.5));

# Pyplot API
# for gamma in arange(0.5, 5.5, step=0.5):
#     plt.plot(t, exp(-gamma*abs(t)), label=r"$\gamma={}$".format(gamma))

# plt.grid()
# plt.legend(loc="right", bbox_to_anchor=(1.25, 0.5));

# COMMAND ----------

# MAGIC %md
# MAGIC ### Limits and ticks
# MAGIC The limits (in x and y) of the figure are automatically determined.
# MAGIC Nevertheless, they can be changed, as well as the ticks and their labels.

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1, label="sin")
ax.plot(x, y2, label="cos")

ax.set_xlim(0.0, 2*pi)  # Set x limits
ax.set_xticks([t*pi/2 for t in range(5)])  # Set x ticks
ax.set_xticklabels([r'$0$', r'$\pi/2$', r'$\pi$', r'$3\pi/2$', r'$2\pi$'],
                   fontsize=14)  # Set xlabels

ax.set_ylim(-1, 1)  # Set y limits
ax.set_yticks(linspace(-1, 1, 9, endpoint=True));  # Set y ticks

ax.grid()
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("Sine and cosine curves")
ax.legend(loc="upper center");

# Pyplot API
# plt.plot(x, y1, label="sin")
# plt.plot(x, y2, label="cos")

# plt.xlim(0.0, 2*pi)  # Set x limits
# plt.xticks([t*pi/2 for t in range(5)],
#           [r'$0$', r'$\pi/2$', r'$\pi$', r'$3\pi/2$', r'$2\pi$'],
#           fontsize=14)  # Set x ticks and labels

# plt.ylim(-1, 1)  # Set y limits
# plt.yticks(linspace(-1, 1, 9, endpoint=True));  # Set y ticks

# plt.grid()
# plt.xlabel("x")
# plt.ylabel("y")
# plt.title("Sine and cosine curves")
# plt.legend(loc="upper center");

# COMMAND ----------

# MAGIC %md
# MAGIC To define manually minor and major ticks, proceed in the following way.

# COMMAND ----------

from matplotlib.ticker import MultipleLocator, FormatStrFormatter

fig, ax = plt.subplots()
ax.plot(x, y1, label="sin")
ax.plot(x, y2, label="cos")

ax.xaxis.set_major_locator(MultipleLocator(pi/2))
ax.xaxis.set_major_formatter(FormatStrFormatter('%0.2f'))
ax.xaxis.set_minor_locator(MultipleLocator(pi/6))

ax.yaxis.set_major_locator(MultipleLocator(0.5))
ax.yaxis.set_minor_locator(MultipleLocator(0.25))

ax.grid()  # Set major grid
ax.grid(which="minor", linestyle=":")  # Set minor grid

ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("Sine and cosine curves")
ax.legend(loc="upper center");

# Pyplot API
# plt.plot(x, y1, label="sin")
# plt.plot(x, y2, label="cos")

# ax = plt.gca()  # gca stands for 'get current axis'
# ax.xaxis.set_major_locator(MultipleLocator(pi/2))
# ax.xaxis.set_major_formatter(FormatStrFormatter('%0.2f'))
# ax.xaxis.set_minor_locator(MultipleLocator(pi/6))

# ax.yaxis.set_major_locator(MultipleLocator(0.5))
# ax.yaxis.set_minor_locator(MultipleLocator(0.25))

# plt.grid()  # Set major grid
# plt.grid(which="minor", linestyle=":")  # Set minor grid

# plt.xlabel("x")
# plt.ylabel("y")
# plt.title("Sine and cosine curves")
# plt.legend(loc="upper center");

# COMMAND ----------

# MAGIC %md
# MAGIC It can be seen that the Pyplot API (on its own) is not sufficient for configuring major and minor locators.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Spines
# MAGIC The spines of the figure can be changes according to:
# MAGIC - axis positions;
# MAGIC - axis colors.

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1, label="sin")
ax.plot(x, y2, label="cos")
ax.grid()
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("Sine and cosine curves")
ax.legend(loc="upper center")

# Moving spines
ax.spines['right'].set_color('none')  # Erase right axis
ax.spines['top'].set_color('none')  # Erase upper axis
ax.spines['bottom'].set_position(('data', 0))  # Set x axis at y=0
ax.spines['left'].set_position(('data', 0))  # Set y axis at x=0
ax.xaxis.set_ticks_position('bottom')  # Set ticks below the x axis
ax.yaxis.set_ticks_position('left')

ax.set_xlim(0.0, 2*pi)  # Set x limits
ax.set_xticks([t*pi/2 for t in range(5)])
ax.set_xticklabels([r'$0$', r'$\pi/2$', r'$\pi$', r'$3\pi/2$', r'$2\pi$'],
                   fontsize=14)  # Set x ticks and labels

ax.set_ylim(-1, 1)  # Set y limits
ax.set_yticks(linspace(-1, 1, 9, endpoint=True));  # Set y ticks

# Pyplot API
# plt.plot(x, y1, label="sin")
# plt.plot(x, y2, label="cos")
# plt.grid()
# plt.xlabel("x")
# plt.ylabel("y")
# plt.title("Sine and cosine curves")
# plt.legend(loc="upper center")

# # Moving spines
# ax = plt.gca()  # gca stands for 'get current axis'
# ax.spines['right'].set_color('none')  # Erase right axis
# ax.spines['top'].set_color('none')  # Erase upper axis
# ax.spines['bottom'].set_position(('data', 0))  # Set x axis at y=0
# ax.spines['left'].set_position(('data', 0))  # Set y axis at x=0
# ax.xaxis.set_ticks_position('bottom')  # Set ticks below the x axis
# ax.yaxis.set_ticks_position('left')

# plt.xlim(0.0, 2*pi)  # Set x limits
# plt.xticks([t*pi/2 for t in range(5)],
#           [r'$0$', r'$\pi/2$', r'$\pi$', r'$3\pi/2$', r'$2\pi$'],
#           fontsize=14)  # Set x ticks and labels

# plt.ylim(-1, 1)  # Set y limits
# plt.yticks(linspace(-1, 1, 9, endpoint=True)); # Set y ticks

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Plot the curve of $x \mapsto e^{-x}$ for $x \in [-1, 10]$.
# MAGIC Apply the following changes:
# MAGIC - wipe off the right and top spines;
# MAGIC - move the left spine to $x=0$;
# MAGIC - display the major grid;
# MAGIC - modify minor y ticks with 0.25-interval;
# MAGIC - display the minor grid with the dotted line style.

# COMMAND ----------

# Answer
t = arange(-1, 10, step=1e-2)

fig, ax = plt.subplots()
ax.plot(t, exp(-t))

ax.spines['right'].set_color('none')
ax.spines['top'].set_color('none')
ax.spines['left'].set_position(('data', 0))

ax.yaxis.set_minor_locator(MultipleLocator(0.25))

ax.grid()
ax.grid(which='minor', linestyle=':')

# Pyplot API
# plt.plot(t, exp(-t))

# ax = plt.gca()
# ax.spines['right'].set_color('none')
# ax.spines['top'].set_color('none')
# ax.spines['left'].set_position(('data', 0))

# ax.yaxis.set_minor_locator(MultipleLocator(0.25))

# plt.grid()
# plt.grid(which='minor', linestyle=':')

# COMMAND ----------

# MAGIC %md
# MAGIC ### Line style
# MAGIC The line style can be changed either with explicit parameters:

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1, linestyle='dashed', color="red", linewidth=2)
ax.plot(x, y2, linestyle='dashdot', color='green', linewidth=2);

# COMMAND ----------

# MAGIC %md
# MAGIC Or with a concise code (check the [format string characters](http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.plot)):

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1, 'r--', linewidth=2)
ax.plot(x, y2, 'g-.', linewidth=2);

# COMMAND ----------

# MAGIC %md
# MAGIC One can also add markers on the curves:

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1, linestyle='', color="red", linewidth=2, marker='^', markersize=7, markevery=2)
ax.plot(x, y2, linestyle='', color='green', linewidth=2, marker='s', markersize=7, markevery=2);

# COMMAND ----------

# MAGIC %md
# MAGIC ### Fill between curves
# MAGIC With Matplotlib, it is conceivable to enhance the esthetics of a figure, for instance by filling the space between two curves.

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1, label="sin")
ax.plot(x, y2, label="cos")
ax.grid()
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("Sine and cosine curves")
ax.legend(loc="upper center")

ax.set_xlim(0.0, 2*pi)  # Set x limits
ax.set_xticks([t*pi/2 for t in range(5)])
ax.set_xticklabels([r'$0$', r'$\pi/2$', r'$\pi$', r'$3\pi/2$', r'$2\pi$'],
                   fontsize=14)  # Set x ticks and labels

ax.set_ylim(-1, 1)  # Set y limits
ax.set_yticks(linspace(-1, 1, 9, endpoint=True))  # Set y ticks

ax.fill_between(x, 0, y1, color="blue", alpha=0.1)
ax.fill_between(x, 0, y2, color="green", alpha=0.1);

# Pyplot API
# plt.plot(x, y1, label="sin")
# plt.plot(x, y2, label="cos")
# plt.grid()
# plt.xlabel("x")
# plt.ylabel("y")
# plt.title("Sine and cosine curves")
# plt.legend(loc="upper center")

# plt.xlim(0.0, 2*pi)  # Set x limits
# plt.xticks([t*pi/2 for t in range(5)],
#           [r'$0$', r'$\pi/2$', r'$\pi$', r'$3\pi/2$', r'$2\pi$'],
#           fontsize=14)  # Set x ticks and labels

# plt.ylim(-1, 1)  # Set y limits
# plt.yticks(linspace(-1, 1, 9, endpoint=True))  # Set y ticks

# plt.fill_between(x, 0, y1, color="blue", alpha=0.1)
# plt.fill_between(x, 0, y2, color="green", alpha=0.1);

# COMMAND ----------

# MAGIC %md
# MAGIC ### Figure and subplots
# MAGIC This example highlights two features:
# MAGIC - defining the size of a figure;
# MAGIC - drawing several subfigures on the same figure.
# MAGIC
# MAGIC The ticks in x and y can be shared, either in row (`sharex='row'` for instance), column (`sharey='row'` for instance) or for the whole figure (like here).

# COMMAND ----------

fig, ax = plt.subplots(1, 2, sharex=True, sharey=True, figsize=(10, 5))  # 1 row, 2 columns

# First subplot
ax[0].plot(x, y1, linewidth=2, color='red')
ax[0].grid()
ax[0].set_xlabel("x")
ax[0].set_ylabel("y")
ax[0].set_title("Sine curve")

# Second item
ax[1].plot(x, y2*exp(-x/2), linewidth=2, color='green')
ax[1].grid()
ax[1].set_xlabel("x")
ax[1].set_ylabel("y")
ax[1].set_title("Cos * exp curve");

# Pyplot API
# plt.figure(figsize=(10, 5))

# plt.subplot(1, 2, 1)  # 1 row, 2 columns, Item 1
# plt.plot(x, y1, linewidth=2, color='red')
# plt.grid()
# plt.xlabel("x")
# plt.ylabel("y")
# plt.title("Sine curve")

# plt.subplot(1, 2, 2)  # 1 row, 2 columns, Item 2
# plt.plot(x, y2*exp(-x/2), linewidth=2, color='green')
# plt.grid()
# plt.xlabel("x")
# plt.ylabel("y")
# plt.title("Cos * exp curve");

# COMMAND ----------

# MAGIC %md
# MAGIC You can have much more control on subplots with `GridSpec`.

# COMMAND ----------

from matplotlib.gridspec import GridSpec

gs = GridSpec(2, 2)  # 2 rows, 2 columns

fig = plt.figure(figsize=(10, 10))
ax = [fig.add_subplot(pos) for pos in [gs[0, :],  # First row, two columns
                                       gs[1, 0],  # Second row, left column
                                       gs[1, 1]]]  # Second row, right column

# First row, two columns
ax[0].plot(x, y2*exp(-x/2), linewidth=2, color='green')
ax[0].grid()
ax[0].set_xlabel("x")
ax[0].set_ylabel("y")
ax[0].set_title("Cos * exp curve");

# Second row, left column
ax[1].plot(x, y1, linewidth=2, color='red')
ax[1].grid()
ax[1].set_xlabel("x")
ax[1].set_ylabel("y")
ax[1].set_title("Sine curve")

# Second row, right column
ax[2].plot(x, cos(x), linewidth=2, color='red')
ax[2].grid()
ax[2].set_xlabel("x")
ax[2].set_ylabel("y")
ax[2].set_title("Cos curve");

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Plot on a 2x2 matrix the curves of the functions:
# MAGIC - $x \mapsto cos(x)$;
# MAGIC - $x \mapsto sin(x)$;
# MAGIC - $x \mapsto exp(x)$;
# MAGIC - $x \mapsto |x|$.
# MAGIC
# MAGIC You can consider $x \in [-5, 5]$.
# MAGIC In addition, set the following parameters:
# MAGIC - without sharing yticks;
# MAGIC - sharing xticks on each row;
# MAGIC - setting the figure size to (10, 10);
# MAGIC - adding a grid and a title for each subplot.

# COMMAND ----------

# Answer 1
t = arange(-5, 5, step=1e-1)

fig, ax = plt.subplots(2, 2, sharex='row', sharey=False, figsize=(10, 10))

# cos
ax[0, 0].plot(t, cos(t))
ax[0, 0].set_title('cos')
ax[0, 0].grid()

# sin
ax[0, 1].plot(t, sin(t))
ax[0, 1].set_title('sin')
ax[0, 1].grid()

# exp
ax[1, 0].plot(t, exp(t))
ax[1, 0].set_title('exp')
ax[1, 0].grid()

# abs
ax[1, 1].plot(t, abs(t))
ax[1, 1].set_title('absolute')
ax[1, 1].grid()

# Pyplot API
# plt.figure(figsize=(10, 10))

# # cos
# plt.subplot(2, 2, 1)
# plt.plot(t, cos(t))
# plt.title('cos')
# plt.grid()

# # sin
# plt.subplot(2, 2, 2)
# plt.plot(t, sin(t))
# plt.title('sin')
# plt.grid()

# # exp
# plt.subplot(2, 2, 3)
# plt.plot(t, exp(t))
# plt.title('exp')
# plt.grid()

# # abs
# plt.subplot(2, 2, 4)
# plt.plot(t, abs(t))
# plt.title('absolute')
# plt.grid()

# COMMAND ----------

# Answer 2
t = arange(-5, 5, step=1e-1)

fig, ax = plt.subplots(2, 2, sharex='row', sharey=False, figsize=(10, 10))

for axis, fun in zip(ax.flat, [cos, sin, exp, abs]):
    axis.plot(t, fun(t))
    axis.set_title(fun.__name__)
    axis.grid()

# Pyplot API
# plt.figure(figsize=(10, 10))
# for i, fun in enumerate([cos, sin, exp, abs]):
#     plt.subplot(2, 2, i+1)
#     plt.plot(t, fun(t))
#     plt.title(fun.__name__)
#     plt.grid()

# COMMAND ----------

# MAGIC %md
# MAGIC ### Adding text
# MAGIC Text can be added with the commands `text` and `annotate` (the main [text properties](http://matplotlib.org/users/text_props.html) are: `fontsize`, `fontweight` (bold), `fontstyle` (italic), `color` and so on).
# MAGIC In the last case, the arrow properties can be changed.

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, y1, linewidth=2, color='red')

ax.grid()
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("Sine curve")

ax.text(4, .5, r'$y = \sin(x)$', fontsize=18)

arrowprops = dict(facecolor='blue', width=2, headwidth=7, shrink=0.05)
ax.annotate('Local min', xy=(3*pi/2, -1), xytext=(2, -0.5), fontsize=14,
            horizontalalignment='right', verticalalignment='top', arrowprops=arrowprops);

# COMMAND ----------

# MAGIC %md
# MAGIC One can also go further in the ornaments by defining text frames (see the [frame properties](http://matplotlib.org/api/patches_api.html)).

# COMMAND ----------

fig, ax = plt.subplots()

ax.plot(x, y1, linewidth=2, color='red')

ax.grid()
ax.set_xlabel("x")
ax.set_ylabel("y")
ax.set_title("Sine curve")

bboxprops = dict(boxstyle="round", facecolor="white", edgecolor="0.5", alpha=0.9)
ax.text(3.7, 0., r'$y = \sin(x)$', horizontalalignment="center",
        verticalalignment="center", rotation=-65, fontsize=18, bbox=bboxprops)

bboxprops = dict(boxstyle="rarrow", facecolor=(0.8,0.9,0.9), edgecolor="b", linewidth=2)
ax.text(1.5, -0.5, "Time", horizontalalignment="center", verticalalignment="center",
        fontsize=16, color="green", bbox=bboxprops);

# COMMAND ----------

# MAGIC %md
# MAGIC ### Nonlinear axis
# MAGIC This example plots linear, log and mixed charts.
# MAGIC The option `symlog` for symmetric log scale (negative axis) can also be used.

# COMMAND ----------

fig, ax = plt.subplots(2, 2, figsize=(10, 10))

for axis, (xscale, yscale) in zip(ax.flat, [("linear", "linear"),
                                       ("log", "linear"),
                                       ("linear", "log"),
                                       ("log", "log")]):
    axis.plot(x, exp(-x), label="exp")
    axis.plot(x, x, label="linear")
    axis.grid(which="both")  # Draw both major and minor tick grids
    axis.set_xscale(xscale)
    axis.set_yscale(yscale)
    axis.legend(loc="upper left")
    axis.set_title(xscale + ' / ' + yscale)

# Pyplot API
# plt.figure(figsize=(10, 10))

# for it, (xscale, yscale) in enumerate([("linear", "linear"),
#                                       ("log", "linear"),
#                                       ("linear", "log"),
#                                       ("log", "log")]):
#     plt.subplot(2, 2, it+1)
#     plt.plot(x, exp(-x), label="exp")
#     plt.plot(x, x, label="linear")
#     plt.grid(which="both")  # Draw both major and minor tick grids
#     plt.xscale(xscale)
#     plt.yscale(yscale)
#     plt.legend(loc="upper left")
#     plt.title(xscale + ' / ' + yscale)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Plot the curves of $x \mapsto \frac{1}{10x}$ and $x \mapsto \frac{1}{x^2}$ for $x \in [1, 100]$.
# MAGIC Configure a logarithmic scale on the y axis.

# COMMAND ----------

# Answer
t = arange(1, 1e2, step=1e-1)

fig, ax = plt.subplots()
ax.plot(t, .1/t, label=r"$1/10x$")
ax.plot(t, 1/t**2, label=r"$1/x^2$")
ax.grid(which='both')
ax.legend()
ax.set_yscale('log')

# Pyplot API
# plt.plot(t, .1/t, label=r"$1/10x$")
# plt.plot(t, 1/t**2, label=r"$1/x^2$")
# plt.grid(which='both')
# plt.legend()
# plt.yscale('log')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Interactive mode <a id="part1sec4"></a>
# MAGIC Up to now, figures have been plotted within the notebook.
# MAGIC One can also expect to navigate interactively inside the figure.
# MAGIC To do so, just set matplotlib backend to `widget`:
# MAGIC
# MAGIC     %matplotlib widget
# MAGIC     
# MAGIC Then plot your figure.

# COMMAND ----------

# MAGIC %matplotlib widget
# MAGIC
# MAGIC fig, ax = plt.subplots()
# MAGIC ax.plot(x, y1, linewidth=2, color='red')
# MAGIC ax.grid()
# MAGIC ax.set_xlabel("x")
# MAGIC ax.set_ylabel("y")
# MAGIC ax.set_title("Sine curve")
# MAGIC
# MAGIC ax.text(4, .5, r'$y = \sin(x)$', fontsize=18)
# MAGIC ax.annotate('Local min', xy=(3*pi/2, -1), xytext=(2, -0.5),
# MAGIC             arrowprops=dict(facecolor='blue', width=2, headwidth=7, shrink=0.05),
# MAGIC             fontsize=14);

# COMMAND ----------

# Go back to inline plots
%matplotlib inline

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Plot and dig into the curve of $x \mapsto \sin(1/x)$ for $x\in[-1, 1]$ with a step set to $10^{-6}$.

# COMMAND ----------

# Answer
%matplotlib notebook

t = arange(-1, 1, step=1e-6)

fig, ax = plt.subplots()
ax.plot(t, sin(1/t))

# COMMAND ----------

# Go back to inline plots
%matplotlib inline

# COMMAND ----------

# MAGIC %md
# MAGIC ## Seaborn <a id="part1sec5"></a>
# MAGIC A way to produce nice plots with grid by default is to use the configuration provided by the `seaborn` package.
# MAGIC It also defines a color palette and a font.
# MAGIC
# MAGIC Seaborn is a wrapper for Matplotlib.
# MAGIC We will see in a forthcoming chapter that this package will be very convenient for plotting dataframes.

# COMMAND ----------

import seaborn as sns

sns.set()
fig, ax = plt.subplots()
ax.plot(x, y1);

# COMMAND ----------

sns.reset_defaults()  # Go back to original Matplotlib parameters

# COMMAND ----------

# MAGIC %md
# MAGIC # Other plots  <a id="part2"></a>
# MAGIC ## Image <a id="part2sec1"></a>
# MAGIC Matplotlib makes it possible to show images using the submodule `image` (generally nicknamed `mpimg`).
# MAGIC The following example reads an image and shows it.
# MAGIC
# MAGIC For more details, you can refer to the [image tutorial](http://matplotlib.org/users/image_tutorial.html) and the [image API](http://matplotlib.org/api/image_api.html).

# COMMAND ----------

import matplotlib.image as mpimg
%matplotlib inline

img = mpimg.imread('img/upmc.jpg')

fig, ax = plt.subplots(figsize=(10, 10))
ax.imshow(img);

# Pyplot API
# plt.figure(figsize=(10, 10))
# plt.imshow(img);

# COMMAND ----------

# MAGIC %md
# MAGIC Another interesting feature of plotting images is to show greyscale image with a particular [colormap](http://matplotlib.org/users/colormaps.html).
# MAGIC The following example plots each component of the previous RGB image, with a specific colormap.

# COMMAND ----------

fig = plt.figure(figsize=(10, 10))
ax = []

for i, color in enumerate(['Reds', 'Greens', 'Blues']):
    ax.append(fig.add_subplot(2, 2, i+1))
    axim = ax[-1].imshow(img[:, :, i], cmap=color)
    fig.colorbar(axim)
    ax[i].set_title(color)

# Pyplot API
# plt.figure(figsize=(10, 10))
# for it, c in enumerate(["Reds", "Greens", "Blues"]):
#     plt.subplot(2, 2, it+1)
#     plt.imshow(img[:, :, it], cmap=c)
#     plt.title(c)
#     plt.colorbar();

# COMMAND ----------

# MAGIC %md
# MAGIC ## Scatter <a id="part2sec2"></a>
# MAGIC See the [Scatter API](http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.scatter) for more details.

# COMMAND ----------

from numpy.random import randn
from numpy import exp

n = 100  # Number of points
x = randn(n)
y = randn(n)
size = randn(n)
color = randn(n)

size = exp(size) * 100

fig, ax = plt.subplots()
ax.scatter(x, y, c=color, s=size, alpha=0.5)  # alpha tunes transparency
ax.grid();

# Pyplot API
# plt.scatter(x, y, c=color, s=size, alpha=0.5)  # alpha tunes transparency
# plt.grid();

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Let us consider the 200 points defined below by their two coordinates *x* and *y*.
# MAGIC Each point is associated to a label (0 or 1), that indicates its membership.
# MAGIC Scatter these points with one color for each group (0 or 1) and a transparency coefficient set to $0.5$.

# COMMAND ----------

x = random.randn(200)
y = random.randn(200)
label = 2*x+y > 0

# COMMAND ----------

# Answer
fig, ax = plt.subplots()
ax.scatter(x, y, c=label, s=100, alpha=0.5);

# Pyplot API
# plt.scatter(x, y, c=label, s=100, alpha=0.5);

# COMMAND ----------

# MAGIC %md
# MAGIC ## Stem  <a id="part2sec3"></a>
# MAGIC See the [Stem API](https://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.stem) for more details.

# COMMAND ----------

x = linspace(0.1, 2*pi, 20)

fig, ax = plt.subplots()
ax.stem(x, cos(2*x))
ax.grid()

# Pyplot API
# plt.stem(x, cos(2*x))
# plt.grid()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Histogram <a id="part2sec4"></a>
# MAGIC See the [Hist API](http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.hist) for more details.

# COMMAND ----------

n = 5000  # Number of points
mu = 100  # Mean of distribution
sigma = 15  # Standard deviation of distribution
sample = mu + sigma * randn(n)

num_bins = 50  # Number of bins

fig, ax = plt.subplots(figsize=(10, 5))
ax.hist(sample, bins=num_bins, density=True, facecolor='red', alpha=0.5, edgecolor='black')
ax.set_xlabel('Smarts')
ax.set_ylabel('Probability')
ax.set_title(r'Histogram of intelligence quotients: $\mu={mu}$, $\sigma={sigma}$'.
          format(mu=mu, sigma=sigma));

# Pyplot API
# plt.figure(figsize=(10, 5))
# plt.hist(sample, num_bins, density=True, facecolor='red', alpha=0.5, edgecolor='black')
# plt.xlabel('Smarts')
# plt.ylabel('Probability')
# plt.title(r'Histogram of intelligence quotients: $\mu={mu}$, $\sigma={sigma}$'.
#           format(mu=mu, sigma=sigma));

# COMMAND ----------

# MAGIC %md
# MAGIC ## Bar chart <a id="part2sec5"></a>
# MAGIC See the [Bar API](http://matplotlib.org/api/pyplot_api.html#matplotlib.pyplot.bar) for more details.

# COMMAND ----------

# Some random data
names = ['cars', 'houses', 'pets']
means = random.rand(len(names)) * 10
std = random.rand(len(names))

# COMMAND ----------

from numpy import arange

index = arange(len(names))  # Bar positions

fig, ax = plt.subplots()
ax.bar(index, means, width=0.9, edgecolor="blue", alpha=0.2, yerr=std)
ax.set_xticks(index)
ax.set_xticklabels(names, fontsize=14)

# Set nice axes
ax.spines['right'].set_color('none')  # Erase right axis
ax.spines['top'].set_color('none')  # Erase upper axis

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3D plotting <a id="part2sec6"></a>
# MAGIC See the [mplot3d tutorial](https://matplotlib.org/tutorials/toolkits/mplot3d.html)
# MAGIC and the [mplot3d API](https://matplotlib.org/api/toolkits/mplot3d.html#toolkit-mplot3d-api) for more details.

# COMMAND ----------

from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
from numpy import meshgrid

# Polynomial
x = arange(-5, 5, 0.25)
y = arange(-5, 5, 0.25)
X, Y = meshgrid(x, y)
Z = X + Y**2

# Initialize 3D plot
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(1, 1, 1, projection='3d')

# Plot
surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm, linewidth=0)

# Colorbar
fig.colorbar(surf);

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pie chart <a id="part2sec7"></a>
# MAGIC See the [pie API](http://matplotlib.org/a []pi/pyplot_api.html#matplotlib.pyplot.pie)
# MAGIC and [color names](http://matplotlib.org/examples/color/named_colors.html) for more details.

# COMMAND ----------

# The slices will be ordered and plotted counter-clockwise.
labels = 'Frogs', 'Hogs', 'Dogs', 'Logs'
sizes = [15, 30, 45, 10]
colors = ['yellowgreen', 'gold', 'lightskyblue', 'lightcoral']
explode = 0, 0.1, 0, 0  # only "explode" the 2nd slice (i.e. 'Hogs')

fig, ax = plt.subplots()
ax.pie(sizes, explode=explode, labels=labels, colors=colors,
       autopct='%1.1f%%', shadow=True, startangle=90)

# Set aspect ratio to be equal so that pie is drawn as a circle.
ax.axis('equal');

# COMMAND ----------

# MAGIC %md
# MAGIC # Saving figures <a id="part3"></a>
# MAGIC

# COMMAND ----------

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(1, 1, 1, projection='3d')
ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm, linewidth=0)

fig.savefig("img/polynomial.png", dpi=150, bbox_inches="tight", transparent=True)

# COMMAND ----------

# MAGIC %md
# MAGIC Image saved:
# MAGIC
# MAGIC <img src="http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/img/polynomial.png" width=500>

# COMMAND ----------

# MAGIC %md
# MAGIC # A detour to TensorBoard <a id="part4"></a>
# MAGIC [TensorBoard](https://www.tensorflow.org/tensorboard) is a widely used tool for analyzing the behavior of iterative algorithms as well as the structure of neural networks models.
# MAGIC We give here a minimal example but more powerful features exist, in particular for use with [Keras](https://www.tensorflow.org/tensorboard/scalars_and_keras) and [PyTorch](https://pytorch.org/docs/stable/tensorboard.html).

# COMMAND ----------

# Load the TensorBoard notebook extension
%load_ext tensorboard

import tensorflow as tf

# COMMAND ----------

# Clear previous logs
!rm -rf ./log/

# COMMAND ----------

import datetime
current_time = datetime.datetime.now().strftime("%Y-%m-%d_%Hh%M.%S")

# Create file writers for the log directories
writer1 = tf.summary.create_file_writer(f"log/est1_{current_time}")  # Orange curve
writer2 = tf.summary.create_file_writer(f"log/est2_{current_time}")  # Blue curve

# COMMAND ----------

# Normally drawn data with mean 3. We aim at estimating the mean.
mu = 3
data = random.randn(1000) + mu

# COMMAND ----------

# The callback is a function called at each step of an iterative algorithm
# Its aim is to record the values of interest
# Here: the values of two estimators and their respective mean squared errors
def callback(est1, est2, step):
    with writer1.as_default():
        tf.summary.scalar('Value', est1, step=step)
        tf.summary.scalar('MSE', ((est1-mu)**2).mean(), step=step)
    with writer2.as_default():
        tf.summary.scalar('Value', est2, step=step)
        tf.summary.scalar('MSE', ((est2-mu)**2).mean(), step=step)

# COMMAND ----------

# For each sample size from 2 to full size: compute estimators
# and record the values of interest
for it in range(2, len(data)+1):
    est1 = data[:it].mean()  # Unbiased estimator
    est2 = it/(it-1)*est1  # Biased estimator
    callback(est1, est2, it)

# COMMAND ----------

# Open TensorBoard
%tensorboard --logdir log

# COMMAND ----------

# MAGIC %md
# MAGIC # Exercises <a id="part5"></a>
# MAGIC ## Exercise 1 <a id="part5sec1"></a>
# MAGIC Plot the probability density functions of the exponential distributions with parameters $\lambda \in \{0.5, 1, \dots, 2.5\}$.
# MAGIC Do not forget to add a legend with LaTeX support.

# COMMAND ----------

# Answer
import matplotlib.pyplot as plt
import seaborn as sns
from numpy import exp, linspace, arange
%matplotlib inline
sns.set()

x = linspace(0, 5, num=50)

fig, ax = plt.subplots()
for l in arange(0.5, 3, step=0.5):
    ax.plot(x, l*exp(-l*x), linewidth=2, label=r'$\lambda={}$'.format(l))
ax.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 2 <a id="part5sec2"></a>
# MAGIC Plot the Lemniscate of Bernoulli parametrized by:
# MAGIC $$
# MAGIC     x = \frac{\sqrt 2 \cos(t)}{\sin(t)^2+1},
# MAGIC $$
# MAGIC $$
# MAGIC     y = \frac{\sqrt 2 \cos(t) \sin(t)}{\sin(t)^2+1}.
# MAGIC $$
# MAGIC Annotate the points parametrized by $t = \frac{n\pi}{4}$ for $n \in \{0, 1, \dots 7\}$.

# COMMAND ----------

# Answer
from numpy import pi, sqrt, cos, sin
sns.set(style='white')

t = linspace(0, 2*pi, num=100)

fig, ax = plt.subplots()
ax.plot(sqrt(2)*cos(t)/(sin(t)**2+1), sqrt(2)*cos(t)*sin(t)/(sin(t)**2+1), linewidth=2)

arrowprops = dict(facecolor='red', width=2, headwidth=7, shrink=0.05, alpha=0.5)
for it, itt in enumerate([n*pi/4 for n in range(8)]):
    x, y = sqrt(2)*cos(itt)/(sin(itt)**2+1), sqrt(2)*cos(itt)*sin(itt)/(sin(itt)**2+1)
    if it == 0:
        label = '0'
    elif it == 1:
        label = r'$\frac{\pi}{4}$'
    elif it == 4:
        label = r'$\pi$'
    elif it == 6:
        label = r'$\frac{3\pi}{2}$'
    elif it == 8:
        label = r'$2\pi$'
    else:
        label = r'$\frac{'+str(it)+'\pi}{4}$'
    if it == 6:
        xytext = x, y+0.4
    else:
        xytext = x-0.1, y-0.2
    ax.annotate(label,
                xy=(x, y), xytext=xytext, fontsize=20,
                horizontalalignment='right', verticalalignment='top',
                arrowprops=arrowprops);

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 3 <a id="part5sec3"></a>
# MAGIC Subplot the mass function of a Poisson distribution with parameter $\lambda \in \{1, 2, 4, 10\}$.
# MAGIC Set the limits of the y axis to [0, 0.4] for each subplot and do not forget to add a legend with LaTeX support.

# COMMAND ----------

# Answer
from math import factorial
sns.set()

x = arange(21)
fig, ax = plt.subplots(2, 2, figsize=(8, 8), sharex=True, sharey=True)
for axis, l in zip(ax.flat, [1, 2, 4, 10]):
    y = [(l*1.)**xi / factorial(xi) * exp(-l) for xi in x]
    axis.stem(x, y, label=r'$\lambda={}$'.format(l), use_line_collection=True)
    axis.legend()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 4 <a id="part5sec4"></a>
# MAGIC Plot a histogram of the first line of the first layer (red component) of the [UPMC image](http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/img/upmc.jpg).

# COMMAND ----------

# Answer
import matplotlib.image as mpimg

img = mpimg.imread('img/upmc.jpg')
sample = img[0, :, 0]

num_bins = 50

fig, ax = plt.subplots()
ax.hist(sample, num_bins, facecolor='red', alpha=0.5, edgecolor='black')
ax.set_title('Histogram of UPMC image');

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 5 <a id="part5sec5"></a>
# MAGIC Create a 3D plot for the function $(x, y) \mapsto x^2 + y^3$.

# COMMAND ----------

# Answer
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D
from numpy import meshgrid

# Polynomial
x = arange(-5, 5, 0.25)
y = arange(-5, 5, 0.25)
X, Y = meshgrid(x, y)
Z = X**2 + Y**3

# Initialize 3D plot
fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(1, 1, 1, projection='3d')

# Plot
surf = ax.plot_surface(X, Y, Z, rstride=1, cstride=1, cmap=cm.coolwarm, linewidth=0)

# Colorbar
fig.colorbar(surf);

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 6 <a id="part5sec6"></a>
# MAGIC Create a figure similar to Kandinsky's painture, called *several circles*.
# MAGIC Do not forget to erase the axes and the ticks.
# MAGIC <img src="http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/img/cercles.jpg" width=300>

# COMMAND ----------

# Answer
from numpy.random import randn, exponential
from numpy import exp

n = 50  # Number of points
x = randn(n)
y = randn(n)
size = exponential(size=n)
size[size > 50] = 0.
color = randn(n)

size = exp(size) * 100

fig, ax = plt.subplots(figsize=(4, 4))

ax.patch.set_facecolor('black')
ax.spines['right'].set_color('none')  # Erase right axis
ax.spines['top'].set_color('none')  # Erase upper axis
ax.spines['left'].set_color('none')  # Erase right axis
ax.spines['bottom'].set_color('none')  # Erase upper axis
ax.set_xticks([])
ax.set_yticks([])

ax.scatter(x, y, c=color, s=size, alpha=0.5, cmap='gnuplot2')
ax.grid();

# COMMAND ----------

# MAGIC %md
# MAGIC # References <a id="part6"></a>
# MAGIC - [Matplotlib beginner's guide](http://matplotlib.org/users/beginner.html).
# MAGIC - [Pyplot API](http://matplotlib.org/api/pyplot_api.html).
# MAGIC - [Scipy lecture notes](http://www.scipy-lectures.org/index.html).