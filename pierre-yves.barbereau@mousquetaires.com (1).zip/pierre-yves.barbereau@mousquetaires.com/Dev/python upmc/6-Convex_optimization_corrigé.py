# Databricks notebook source
# MAGIC %md
# MAGIC # Introduction to scientific computing with Python
# MAGIC *Maxime Sangnier*
# MAGIC
# MAGIC September, 2020
# MAGIC
# MAGIC ## Part 6: A practical work about convex optimization

# COMMAND ----------

# MAGIC %md
# MAGIC # Table of contents
# MAGIC 1. [Exercises](#part1)
# MAGIC     - [Exercise 1](#part1sec1)
# MAGIC     - [Exercise 2](#part1sec2)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Exercises <a id="part1"></a>
# MAGIC ## Exercise 1 <a id="part1sec1"></a>
# MAGIC

# COMMAND ----------

import numpy as np
import matplotlib.pyplot as plt

def plot_contour(Q, c):
    """
    Plot the contour of a quadratic function 1/2 x^T Q x + c^T x.
    
    Input:
        - Q: a 2x2 numpy array.
        - c: a numpy array of size 2.
    """
    f = lambda x: x.T.dot(Q.dot(x))/2 + c.dot(x)
    sol = np.linalg.solve(Q, -c)
    sol_x, sol_y = sol[0], sol[1]

    X, Y = np.meshgrid(np.linspace(-10+sol_x, 10+sol_x, 100), np.linspace(-10+sol_y, 10+sol_y, 100))
    X, Y = X.ravel(), Y.ravel()
    Z = np.asarray([f(np.r_[x, y]) for x, y in zip(X, Y)])

    X.shape = (int(np.sqrt(X.size)), -1)
    Y.shape = (int(np.sqrt(Y.size)), -1)
    Z.shape = (int(np.sqrt(Z.size)), -1)

    levels = np.logspace(0, np.log10(Z.max()-Z.min()), 20) + Z.min()
    plt.contour(X, Y, Z, levels)

def plot_path(p):
    """
    Plot the path [x_0, x_1, … x_k] of an optimization algorithm.
    
    Input:
        - p: a list of numpy arrays of size 2 (the points x_t, t \in [0, k]).
    """
    plt.plot([x for x, y in p], [y for x, y in p], '*-')

# COMMAND ----------

# MAGIC %md
# MAGIC >Let us consider the optimization problem:
# MAGIC $$
# MAGIC     \operatorname{minimize}_{x \in \mathbb R ^d}
# MAGIC     \frac 1 2 x^\top Q x + c^\top x,
# MAGIC $$
# MAGIC where $Q$ is a symmetric positive definite matrix and $c$ a vector.
# MAGIC These parameters can be randomly generated (here in dimension 2):

# COMMAND ----------

Q = np.random.randn(2, 2)
Q = Q.dot(Q.T)
c = np.random.randn(2)
c *= 10 / np.linalg.norm(np.linalg.solve(Q, -c))

plot_contour(Q, c)

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 1.**
# MAGIC Define a function `gradient_descent(Q, c, eps=1e-3)` that:
# MAGIC - performs a gradient descent for the optimization problem of interest with fixed step size;
# MAGIC - terminates when the norm of the current gradient is less than `eps`;
# MAGIC - returns the list of iterates $(x_k)_k$.
# MAGIC
# MAGIC >Plot the path of the descent.

# COMMAND ----------

# Answer
def gradient_descent(Q, c, n_it=None, eps=1e-3, step=None, x0=None):
    if not x0:
        x0 = np.zeros(c.size)
    else:
        x0 = np.asarray(x0)
    if type(step) == int or type(step) == float:
        s = step
        step = None
    else:
        s = 1
    if not step:
        s *= 1 / np.linalg.eigvalsh(Q).max()
    f = lambda x: x.dot(Q.dot(x))/2 + c.dot(x)
    grad = lambda x: Q.dot(x) + c
    if n_it:
        if eps:
            cont = lambda it, v: it<n_it-1 and np.linalg.norm(v)>eps
        else:
            cont = lambda it, v: it<n_it-1
    else:
        cont = lambda it, v: np.linalg.norm(v)>eps
    if step == "newton":
        H = np.linalg.inv(Q)
    p = [x0]
    x = x0
    v = grad(x)
    it = 0
    while cont(it, v):
        if step == "backtracking":
            s = 1
            v_norm = v.dot(v)
            y = x - s * v
            while f(y) > f(x) - s*v_norm/2:
                s /= 2
                y = x - s * v
            x = y
        elif step == "exact":
            s = v.dot(v) / (v.dot(Q.dot(v)))
            x = x - s * v
        elif step == "newton":
            x = x - H.dot(v)
        else:
            x = x - s * v
        p.append(x)
        v = grad(x)
        it += 1
    return p

# COMMAND ----------

# Answer
plot_contour(Q, c)
plot_path(gradient_descent(Q, c))
plt.legend(['Fixed']);

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 2.**
# MAGIC Let $L$ be the coefficient of Lipschitz-continuity of the gradient of the objective function.Try different step sizes between $\frac{0.1}{L}$ and $\frac{2.5}{L}$.
# MAGIC What do you observe?

# COMMAND ----------

# Answer
plot_contour(Q, c)
gradient_descent(Q, c, step=1)
n_it = 100
steps = [0.1, 0.5, 1, 1.9] ## Divergence for step >= 2
for step in steps:
    plot_path(gradient_descent(Q, c, step=step, n_it=n_it))

plt.legend(['Step '+str(step) for step in steps]);

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 3.**
# MAGIC Implement a line search with Armijo's rule and compare the path obtained.

# COMMAND ----------

# Answer
plot_contour(Q, c)
plot_path( gradient_descent(Q, c) )
plot_path( gradient_descent(Q, c, step="backtracking") )
plt.legend(('Fixed', 'Backtracking'));

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 4.**
# MAGIC Show that the exact line search boils down to $\gamma_k = \frac{\|v_k\|_2^2}{v_k^\top Q v_k}$, where $v_k$ is the gradient of the objective function at $x_k$.
# MAGIC
# MAGIC >Implement a gradient descent with this step size and compare to both others.

# COMMAND ----------

# Answer
plot_contour(Q, c)
plot_path( gradient_descent(Q, c) )
plot_path( gradient_descent(Q, c, step="backtracking") )
plot_path( gradient_descent(Q, c, step="exact") )
plt.legend(('Fixed', 'Backtracking', 'Exact'));

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 5.**
# MAGIC Compare with a Newton method.

# COMMAND ----------

# Answer
plot_contour(Q, c)
plot_path( gradient_descent(Q, c) )
plot_path( gradient_descent(Q, c, step="backtracking") )
plot_path( gradient_descent(Q, c, step="exact") )
plot_path( gradient_descent(Q, c, step="newton") )
plt.legend(('Fixed', 'Backtracking', 'Exact', 'Newton'));

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 2 <a id="part1sec2"></a>
# MAGIC

# COMMAND ----------

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

# COMMAND ----------

# MAGIC %md
# MAGIC >Let us consider the problem of least absolute deviations:
# MAGIC $$
# MAGIC     \operatorname{minimize}_{\beta \in \mathbb R ^d}
# MAGIC     \left\| Y - X\beta \right\|_1,
# MAGIC $$
# MAGIC where $Y \in \mathbb R^n$ and $X \in \mathbb R^{n \times d}$.
# MAGIC
# MAGIC >The matrices $X$ and $Y$ can be randomly generated:

# COMMAND ----------

n, d = 200, 2  # Sample size, dimension

X = np.random.randn(n, d-1)
X = np.concatenate((X, np.ones((n, 1))), axis=1)  # Last column of 1 (intercept)

beta = np.random.randn(d)
# beta[1:-1] = 0  # Only the first and the last components are nonzero

Y = X.dot(beta) + np.random.randn(n)*5e-1

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 1.**
# MAGIC Rewrite the previous optimization problem as a linear program.

# COMMAND ----------

# MAGIC %md
# MAGIC **Answer**
# MAGIC
# MAGIC The least absolute deviations problem can be reformulated as:
# MAGIC \begin{align*}
# MAGIC     \operatorname{minimize}_{\beta \in \mathbb R ^d, t \in \mathbb R^n} &~ \mathbb 1 ^\top t \\
# MAGIC     \text{s.t.} &~ \left\{
# MAGIC         \begin{array}{l}
# MAGIC             Y - X\beta \le t \\
# MAGIC             -t \le Y - X\beta.
# MAGIC         \end{array}
# MAGIC     \right.
# MAGIC \end{align*}

# COMMAND ----------

# MAGIC %md
# MAGIC > Once the optimization problem is rewritten as a linear program, it can be solved with standard libraries such as `cvxopt`.

# COMMAND ----------

from cvxopt import matrix, solvers

# Variables: beta, t
c = matrix(np.r_[np.zeros(d), np.ones(n)])  # Linear objective
G = matrix(np.r_[np.c_[-X, -np.eye(n)],
                 np.c_[X, -np.eye(n)]])  # Inequality lhs
h = matrix(np.r_[-Y, Y])  # Inequality rhs

sol = solvers.lp(c, G, h)

# COMMAND ----------

beta_sol = np.asarray(sol['x'][:d]).ravel()
obj_sol = np.linalg.norm(Y - X.dot(beta_sol), ord=1)

print("True beta:", beta)
print("Estimation of beta:", beta_sol)
print("Minimum objective:", obj_sol)

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 2.**
# MAGIC Scatter the observations and draw the linear model.
# MAGIC Add the predictions obtained from the estimator `beta_sol`.

# COMMAND ----------

# Answer
x = np.c_[np.linspace(X[:, 0].min(), X[:, 0].max(), num=10), np.ones(10)]  # x points for plot

fig, ax = plt.subplots(figsize=(10, 6))

ax.scatter(X[:, 0], Y, color='green', alpha=0.5)
ax.plot(x[:, 0], x.dot(beta), linestyle=':', linewidth=3, label='True')
ax.plot(x[:, 0], x.dot(beta_sol), linestyle=':', linewidth=3, label='Estimation')
ax.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 3.**
# MAGIC Define a function `subgradient_descent(Y, X, n_it=100, step=1., mode='fixed')` that:
# MAGIC - performs a subgradient descent for the original optimization problem (we note $g_k$ a subgradient at iteration $k$) with either
# MAGIC     - a fixed step length: $\frac{\textrm{step}}{\|g_{k}\|}$;
# MAGIC     - a $\sqrt \cdot$-diminishing step size: $\frac{\textrm{step}}{\sqrt k}$;
# MAGIC     - a linearly diminishing step size: $\frac{\textrm{step}}{k}$;
# MAGIC - terminates after `n_it` iterations;
# MAGIC - returns the list of iterates $(\beta_k)_k$.
# MAGIC
# MAGIC >Run the algorithm for different fixed step lengths and plot, with respect to the iterations, the objective values $f(x_k)$ normalized by $\frac{f(x_k) - \textrm{obj_sol}}{\textrm{obj_sol}}$ (use a y-log scale).

# COMMAND ----------

# Answer
def subgradient_descent(Y, X, n_it=100, step=1., mode='fixed', x0=None):
    if not x0:
        x0 = np.zeros(X.shape[1])
    else:
        x0 = np.asarray(x0)

    subgrad = lambda x: -X.T.dot(np.sign(Y - X.dot(x)))
    p = [x0]
    x = x0
    v = subgrad(x)
    for it in range(n_it):
        if mode == 'fixed':
            s = step / np.linalg.norm(v)
        elif mode == 'sqrt':
            s = step / np.sqrt(it+1)
        elif mode == 'linear':
            s = step / (it+1)
        else:
            s = step / np.sqrt(it+1)
        x = x - s * v
        p.append(x)
        v = subgrad(x)
    return p

# COMMAND ----------

# Answer
obj = lambda l: [(np.linalg.norm(Y - X.dot(x), ord=1) - obj_sol) / obj_sol for x in l]

fig, ax = plt.subplots(figsize=(10, 6))

for step in [0.1, 0.01, 0.001]:
    sol = subgradient_descent(Y, X, step=step, n_it=500)
    ax.plot(obj(sol), label='step={}'.format(step))
ax.set_yscale('log')
plt.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 4.**
# MAGIC Choose a value for `step` and compare the three ways of defining the step size (fixed length, $\sqrt \cdot$, linear) for a large number of iterations by plotting the objective values.
# MAGIC What do you observe?

# COMMAND ----------

# Answer
fig, ax = plt.subplots(figsize=(15, 6))

for mode in ['fixed', 'sqrt', 'linear']:
    sol = subgradient_descent(Y, X, step=1e-2, mode=mode, n_it=10000)
    ax.plot(obj(sol), label='mode: {}'.format(mode))
ax.set_yscale('log')
plt.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC >**Question 5.**
# MAGIC In the same manner as for the previous question, draw the norm of the difference between `beta_sol` and the iterates $(\beta_k)_k$ of the subgradient methods.

# COMMAND ----------

# Answer
fig, ax = plt.subplots(figsize=(15, 6))

for mode in ['fixed', 'sqrt', 'linear']:
    sol = subgradient_descent(Y, X, step=1e-2, mode=mode, n_it=10000)
    ax.plot([np.linalg.norm(beta_sol-b) for b in sol], label='mode: {}'.format(mode))
ax.set_yscale('log')
plt.legend();