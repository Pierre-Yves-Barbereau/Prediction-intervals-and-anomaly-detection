# Databricks notebook source
# MAGIC %md
# MAGIC # Introduction to scientific computing with Python
# MAGIC *Maxime Sangnier*
# MAGIC
# MAGIC September, 2020
# MAGIC
# MAGIC ## Part 4: Statistics

# COMMAND ----------

# MAGIC %md
# MAGIC # Table of contents
# MAGIC 1. [Sampling and testing](#part1)
# MAGIC     - [Random sampling](#part1sec1)
# MAGIC     - [Advanced distributions](#part1sec2)
# MAGIC     - [Descriptive statistics](#part1sec3)
# MAGIC     - [Hypothesis testing](#part1sec4)
# MAGIC 1. [Data representation and manipulation](#part2)
# MAGIC     - [Reading and creating a dataframe](#part2sec1)
# MAGIC     - [Viewing data](#part2sec2)
# MAGIC     - [Indexing a table](#part2sec3)
# MAGIC     - [Adding and deleting items](#part2sec4)
# MAGIC     - [Managing missing data](#part2sec5)
# MAGIC     - [Descriptive statistics](#part2sec6)
# MAGIC     - [Pivot table](#part2sec7)
# MAGIC     - [Plotting](#part2sec8)
# MAGIC 1. [Linear models](#part3)
# MAGIC     - [Linear regression](#part3sec1)
# MAGIC     - [ANOVA](#part3sec2)
# MAGIC 1. [Exercises](#part4)
# MAGIC     - [Exercise 1](#part4sec1)
# MAGIC     - [Exercise 2](#part4sec2)
# MAGIC     - [Exercise 3](#part4sec3)
# MAGIC     - [Exercise 4](#part4sec4)
# MAGIC     - [Exercise 5](#part4sec5)
# MAGIC 1. [References](#part5)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Sampling and testing <a id="part1"></a>
# MAGIC ## Random sampling <a id="part1sec1"></a>
# MAGIC ### Simple random data
# MAGIC [Numpy](http://docs.scipy.org/doc/numpy/reference/routines.random.html#random-generator) offers several routines to generate easily uniform and normal random samples:

# COMMAND ----------

import numpy as np
import numpy.random as rdm
np.set_printoptions(precision=2)

rdm.rand(4, 4)  # Uniform sampling

# COMMAND ----------

rdm.randn(4, 4)  # Standard normal sampling

# COMMAND ----------

rdm.randint(0, 10, size=(2, 3))  # Discrete uniform sampling (10 exclusive)

# COMMAND ----------

# MAGIC %md
# MAGIC In the case where the sampled integers are supposed to index an array, one can replace:

# COMMAND ----------

a = np.arange(10)*10

ind = rdm.randint(0, 5, size=7)
a[ind]

# COMMAND ----------

# MAGIC %md
# MAGIC by:

# COMMAND ----------

rdm.choice(a, size=7)

# COMMAND ----------

# MAGIC %md
# MAGIC The previous routines sample integers with replacement.
# MAGIC To sample without replacement, one can use:

# COMMAND ----------

rdm.permutation(10)[:7]  # 7 first items of a random permutation of [0, …, 9]

# COMMAND ----------

# MAGIC %md
# MAGIC Note that one can also directly permute an array with a copy (`permutation`) or in-place (`shuffle`), instead of generating random indexes.

# COMMAND ----------

rdm.permutation(a)

# COMMAND ----------

rdm.shuffle(a)
a

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Draw a sample of size $100$ from a normal distribution with mean $10$ and standard deviation $2$.
# MAGIC Print the usual estimators of these two parameters to validate your operation.

# COMMAND ----------

# Answer
s = rdm.randn(100) * np.sqrt(2) + 10
print(s.mean(), s.std())

# COMMAND ----------

# MAGIC %md
# MAGIC ### Random generator
# MAGIC It is obvious that random generators used in scientific computing are in fact pseudo-random generators.
# MAGIC As a consequence, the practitioner is able to control them to a certain extent.
# MAGIC In a way, this is good news for reproducible science!
# MAGIC
# MAGIC Both examples below illustrate how to replay a random sampling.

# COMMAND ----------

for it in range(3):
    rdm.seed(it)  # Seed the generator to the current iteration number
    print(rdm.randint(100, size=3))

# COMMAND ----------

for it in range(3):
    rdm.seed(it)  # Seed the generator to the current iteration number
    print(rdm.randint(100, size=3))  # Same as before!

# COMMAND ----------

s = rdm.get_state()  # Get the internal state of the generator
print(np.array([rdm.randn() for it in range(3)]))
print(rdm.rand(3, 3))

# COMMAND ----------

rdm.set_state(s)  # Set the internal state of the generator to its previous value
for it in range(3):
    print(rdm.randn(1))  # Same as before!

# COMMAND ----------

# MAGIC %md
# MAGIC ### Distributions
# MAGIC Besides the previous routines, Numpy offers the possibility to draw samples from numerous [distributions](http://docs.scipy.org/doc/numpy/reference/routines.random.html#distributions).

# COMMAND ----------

x = rdm.poisson(lam=4, size=500)
print(x[:30])

# COMMAND ----------

import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

fig, ax = plt.subplots()
ax.stem(np.bincount(x), use_line_collection=True);

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Draw a sample of size $1000$ from an exponential distribution with scale $2$ and plot a density histogram of this sample.

# COMMAND ----------

# Answer
x = rdm.exponential(2, size=1000)

fig, ax = plt.subplots()
ax.hist(x, bins=50, density=True);

# COMMAND ----------

# MAGIC %md
# MAGIC ## Advanced distributions <a id="part1sec2"></a>
# MAGIC ### Special functions
# MAGIC Many raw statistical routines (cumulative, survival and inverse functions) are available in the [scipy.special](http://docs.scipy.org/doc/scipy/reference/special.html#raw-statistical-functions) mudule.

# COMMAND ----------

from scipy import special

plt.stem(special.pdtr(range(15), 4), use_line_collection=True);  # Poisson cumulative distribution function

# COMMAND ----------

# MAGIC %md
# MAGIC ### Random variables
# MAGIC [Scipy.stats](http://docs.scipy.org/doc/scipy/reference/stats.html) implements random variables with two different classes: [*continuous random variables*](http://docs.scipy.org/doc/scipy/reference/tutorial/stats/continuous.html#continuous-random-variables) and [*discrete random variables*](http://docs.scipy.org/doc/scipy/reference/tutorial/stats/discrete.html#discrete-random-variables).
# MAGIC As an example, we focus here on the gamma distribution and illustrate the main methods available.

# COMMAND ----------

from scipy.stats import gamma

# gamma is a r.v. object corresponding to the standard gamma distribution
print("Distribution support: [{}, {}]".format(gamma.a, gamma.b))
print("Number of shape parameters: {} (name: {})".format(gamma.numargs, gamma.shapes))

# COMMAND ----------

# MAGIC %md
# MAGIC The shape parameter `a` appears in the probability density function:
# MAGIC <!-- $$f(x; a, \lambda) = x^{a-1}\exp(-\lambda x) \frac{\lambda^a}{\Gamma(a)}.$$ -->
# MAGIC $$f(x; a) = \frac{x^{a-1}\exp(-x)}{\Gamma(a)}.$$
# MAGIC
# MAGIC Since the shape parameter `a` is required, one has to specify it for each method.

# COMMAND ----------

print("Mean:", gamma.mean(a=4))
print("Median:", gamma.median(a=4))
print("Variance:", gamma.var(a=4))

# COMMAND ----------

# MAGIC %md
# MAGIC Two other parameters can be passed to the methods: `loc` and `scale`.
# MAGIC They correspond to shifting and rescaling the standard random variable with 
# MAGIC $x \mapsto scale \cdot x + loc.$

# COMMAND ----------

print("Mean:", gamma.mean(a=4, loc=2, scale=0.1))

# COMMAND ----------

# MAGIC %md
# MAGIC Since passing those parameters time and again can become quite bothersome, one can freeze the parameters:

# COMMAND ----------

rv = gamma(a=4, loc=2, scale=2)
print("Mean:", rv.mean())

# COMMAND ----------

# MAGIC %md
# MAGIC Now, let us have a look at the available methods.

# COMMAND ----------

print(rv.rvs(size=10))  # Draw a random sample

# COMMAND ----------

for n in range(4):
    print("Moment {}:".format(n), rv.moment(n))

# COMMAND ----------

x = np.linspace(0, 30, num=50)

fig, ax = plt.subplots()
ax.plot(x, rv.pdf(x), label='pdf')  # Probability density function
ax.plot(x, rv.cdf(x)/10, label='cdf / 10')  # Cumulative density function
ax.legend(loc="best");

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(x, rv.logpdf(x), label='log pdf');  # Log of the pdf

# COMMAND ----------

x = np.linspace(0, 1, num=50)

fig, ax = plt.subplots()
ax.plot(x, rv.ppf(x), label='ppf')  # Percent point function (inverse of cdf, also called quantile function) 
ax.legend(loc="upper left");

# COMMAND ----------

m = rv.expect(lambda x: np.exp(-x))  # Expectation of a function
print("First exponential moment: {0:0.2e}".format(m))

# COMMAND ----------

# MAGIC %md
# MAGIC Note that an unfrozen random variable (for instance `gamma`, not `rv`) benefits from two other methods: `fit` and `fit_loc_scale` for estimating parameters respectively by likelihood maximization and the moment method.

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Draw a sample of size $1000$ from a Laplace distribution (with location $1$ and scale $2$) and plot a density histogram of this sample.
# MAGIC Add the curve of the probability density function.

# COMMAND ----------

# Answer
from scipy.stats import laplace

lap = laplace(loc=1, scale=2)  # Random variable
s = lap.rvs(size=1000)  # Random sample

x = np.linspace(-10, 10)

fig, ax = plt.subplots()
ax.plot(x, lap.pdf(x), label='pdf')
ax.hist(s, bins=50, density=True, label='hist')
ax.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC ## Descriptive statistics <a id="part1sec3"></a>
# MAGIC ### Order statistics, moments and correlation
# MAGIC Basic descriptive statistics such as min, max, mean, median, std, variance and percentiles can be computed with [array methods](http://docs.scipy.org/doc/numpy/reference/generated/numpy.ndarray.html) or routines from [Numpy](http://docs.scipy.org/doc/numpy/reference/routines.statistics.html).
# MAGIC Other empirical statistics such as mode and moments can be obtained with [Scipy statistical functions](http://docs.scipy.org/doc/scipy/reference/stats.html#statistical-functions).

# COMMAND ----------

# MAGIC %md
# MAGIC ### Histograms
# MAGIC A common task in statisics is to estimate the probability density function of a random variable, what is called density estimation.
# MAGIC In a first approach, this task can be achieved by computing a histogram.

# COMMAND ----------

x = rv.rvs(size=1000)  # Draw a random sample

# Compute the histogram
hist, bins = np.histogram(x, bins=20, density=True)

# Plot the histogram
fig, ax = plt.subplots()
ax.bar(bins[:-1], hist, width=bins[1]-bins[0])
ax.set_xticks(bins[::3], ["{0:0.2f}".format(t) for t in bins[::3]]);

x_pdf = np.linspace(0, 30, num=100)
ax.plot(x_pdf, rv.pdf(x_pdf), color="red", linewidth=2, label="pdf")
ax.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC Alternatively, one can use Matplotlib to produce fancy plots:

# COMMAND ----------

fig, ax = plt.subplots()
hist_plt, bins_plt, patches = ax.hist(x, bins=20, density=True)
ax.plot(x_pdf, rv.pdf(x_pdf), color="red", linewidth=2, label="pdf")
ax.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC ### Kernel density estimation
# MAGIC Kernel desity estimation is a tool more efficient than a histogram for density estimation.
# MAGIC In Python, kernel density estimation can be performed with the `gaussian_kde` function.

# COMMAND ----------

from scipy.stats import gaussian_kde

kde = gaussian_kde(x)

fig, ax = plt.subplots()
(hist_plt, bins_plt, patches) = ax.hist(x, bins=20, density=True)
ax.plot(x_pdf, rv.pdf(x_pdf), color="red", linewidth=2, label="pdf")
ax.plot(x_pdf, kde(x_pdf), color="magenta", linewidth=2, label="kde")
ax.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC Add on the previous figure the curves of a kernel density estimation with parameter `bw_method` (of `gaussian_kde`) varying according to `bw_values`.

# COMMAND ----------

bw_values = [0.1, 0.5, 1]

# COMMAND ----------

# Answer
for bw in bw_values:
    kde = gaussian_kde(x, bw_method=bw)
    ax.plot(x_pdf, kde(x_pdf), linewidth=2, label="kde {}".format(bw))

ax.legend()
fig

# COMMAND ----------

# MAGIC %md
# MAGIC ## Hypothesis testing <a id="part1sec4"></a>
# MAGIC ### Analyzing one sample
# MAGIC As for R, many tests can be performed in Python.
# MAGIC For instance, a single sample may be analyzed with:
# MAGIC - `ttest_1samp`: T-test for the mean of one group of scores;
# MAGIC - `kstest`: Kolmogorov-Smirnov test for goodness of fit;
# MAGIC - `ksone`: general Kolmogorov-Smirnov one-sided test;
# MAGIC - `chisquare`: one-way chi square test;
# MAGIC - `anderson`: Anderson-Darling test for data coming from a particular distribution.

# COMMAND ----------

from scipy import stats

for rv in [stats.expon, stats.norm]:
    tt, pval = stats.ttest_1samp(rv.rvs(size=100), 0)
    print("{} sample: ".format(rv.name), end="")
    print("p-value = {0:0.2f} (statistics = {1:0.2f})".format(pval, tt))

# COMMAND ----------

# MAGIC %md
# MAGIC On the one hand, the p-value for the exponential sample is small enough that we can reject the null hypothesis that the mean is $0$.
# MAGIC On the other hand, with high significance levels, we cannot reject the null hypothesis for the normal sample (this is comforting!).
# MAGIC
# MAGIC Let us now test for a given distribution:

# COMMAND ----------

for rv in [stats.expon, stats.norm]:
    tt, pval = stats.kstest(rv.rvs(size=100), 'expon')
    print("{} sample: ".format(rv.name), end="")
    print("p-value = {0:0.2f} (statistics = {1:0.2f})".format(pval, tt))

# COMMAND ----------

# MAGIC %md
# MAGIC Again, the result is as expected.
# MAGIC
# MAGIC ### Testing normality
# MAGIC As a special case, several tests exist for assessing the normality of a sample:
# MAGIC - `kurtosistest`: tests whether a dataset has normal kurtosis;
# MAGIC - `skewtest`: tests whether the skew is different from the normal distribution;
# MAGIC - `normaltest`: tests whether a sample differs from a normal distribution (D'Agostino and Pearson's test);
# MAGIC - `jarque_bera`: Jarque-Bera goodness of fit test on sample data;
# MAGIC - `shapiro`: Shapiro-Wilk test for normality.

# COMMAND ----------

for rv in [stats.expon, stats.norm]:
    print("{} sample:".format(rv.name))
    for name, test in [('skew', stats.skewtest), ('kurtosis', stats.kurtosistest)]:
        tt, pval = test(rv.rvs(size=100))
        print("   {} test: ".format(name), end="")
        print("   p-value = {0:0.2f} (statistics = {1:0.2f})".format(pval, tt))

# COMMAND ----------

# MAGIC %md
# MAGIC Note that these two tests are combined in the normality test:

# COMMAND ----------

for rv in [stats.expon, stats.norm]:
    tt, pval = stats.normaltest(rv.rvs(size=100))
    print("{} sample: ".format(rv.name), end="")
    print("p-value = {0:0.2f} (statistics = {1:0.2f})".format(pval, tt))

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Dowload [this data file](http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/Gaussian_sample.mat).
# MAGIC Load the random sample stored in the variable `x` and test its normality.

# COMMAND ----------

from scipy.io import loadmat

x = loadmat('data/Gaussian_sample.mat')['x'].ravel()

# COMMAND ----------

# Answer
print(stats.normaltest(x))  # the p-value is high enough to be convinced that it is a normal sample.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Comparing two samples
# MAGIC Again, many tests for two samples are available in the `scipy.stats` module:
# MAGIC - `ks_2samp`: Kolmogorov-Smirnov test for 2 samples;
# MAGIC - `ttest_ind`: T-test for the means of two independent samples of scores;
# MAGIC - `kstwobign`: Kolmogorov-Smirnov two-sided test for large N;
# MAGIC - `ttest_ind_from_stats`: T-test for means of two independent samples from descriptive statistics;
# MAGIC - `ttest_re`l: T-test on TWO RELATED samples of scores, a and b;
# MAGIC - `mannwhitneyu`: Mann-Whitney rank test on samples x and y;
# MAGIC - `wilcoxon`: Wilcoxon signed-rank test;
# MAGIC - `kruskal`: Kruskal-Wallis H-test for independent samples;
# MAGIC - `ansari`: Ansari-Bradley test for equal scale parameters;
# MAGIC - `bartlett`: Bartlett's test for equal variances;
# MAGIC - `levene`: Levene test for equal variances;
# MAGIC - `anderson_ksamp`: Anderson-Darling test for k-samples;
# MAGIC - `fligner`: Fligner-Killeen test for equality of variances;
# MAGIC - `median_test`: Mood's median test;
# MAGIC - `mood`: Mood's test for equal scale parameters.
# MAGIC
# MAGIC As an example, on can test that two independent samples have identical means or that two independent samples are drawn from the same continuous distribution:

# COMMAND ----------

rvs1 = stats.norm.rvs(size=100, loc=0., scale=1)
rvs2 = stats.norm.rvs(size=200, loc=0.1, scale=2)

tt, pval = stats.ttest_ind(rvs1,rvs2)
print("p-value = {0:0.2f} (statistics = {1:0.2f})".format(pval, tt))

# COMMAND ----------

# MAGIC %md
# MAGIC Here, the p-value is high enough that we cannot reject the null hypothesis that the two samples have identical means.
# MAGIC On the other hand, the following statistical test makes it possible to state that the two samples are drawn from different distribution (we reject the null hypothesis that they come from the same distribution):

# COMMAND ----------

tt, pval = stats.ks_2samp(rvs1, rvs2)
print("p-value = {0:0.2f} (statistics = {1:0.2f})".format(pval, tt))

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Apply both T-tests `ttest_ind` and `ttest_rel` on the samples `rvs1` and `rvs1_coupled`.
# MAGIC Can you explain the difference in the results?

# COMMAND ----------

rvs1_coupled = rvs1 + rdm.randn(rvs1.size) * 0.1 + 0.1
print(rvs1.mean(), rvs1_coupled.mean())

# COMMAND ----------

# Answer
print(stats.ttest_ind(rvs1, rvs1_coupled))
print(stats.ttest_rel(rvs1, rvs1_coupled))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Other tests
# MAGIC - `pearsonr`: Pearson correlation coefficient and the p-value for testing non-correlation;
# MAGIC - `spearmanr`: Spearman rank-order correlation coefficient and the p-value to test for non-correlation;
# MAGIC - `power_divergence`: Cressie-Read power divergence statistic and goodness of fit test;
# MAGIC - `friedmanchisquare`: Friedman test for repeated measurements;
# MAGIC - `chi2_contingency`: Chi-square test of independence of variables in a contingency table;
# MAGIC - `fisher_exact`: Fisher exact test on a 2x2 contingency table.

# COMMAND ----------

# MAGIC %md
# MAGIC # Data representation and manipulation <a id="part2"></a>
# MAGIC Following the example of R, Python comes with a package for handling data as a table : the [Pandas](http://pandas.pydata.org/) package provides a container for tables, called **dataframe**.
# MAGIC A dataframe is a two-dimensional table, in which each column contains measurements on one variable, and each row contains one individual.
# MAGIC
# MAGIC The main features of Pandas and its dataframe are:
# MAGIC - reading data from csv and Excel files;
# MAGIC - giving names to variables;
# MAGIC - storing in a clever manner a large amound of data;
# MAGIC - providing methods for descriptive statistics.
# MAGIC
# MAGIC ## Reading and creating a dataframe <a id="part2sec1"></a>
# MAGIC A dataframe may be either read from a file or created from raw data (the file is available [here](http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/defra_consumption.csv)):

# COMMAND ----------

!cat data/defra_consumption.csv

# COMMAND ----------

import numpy as np
import pandas as pd

consumption = pd.read_csv('data/defra_consumption.csv', sep=';', index_col=0)
consumption

# COMMAND ----------

timeseries = pd.DataFrame(data=np.random.randn(6,4),
                          index=pd.date_range('20130101', periods=6),
                          columns=list('ABCD'))
timeseries

# COMMAND ----------

df = pd.DataFrame({'A' : 1.,  # Single item
                    'B' : pd.Timestamp('20130102'),  # Single item
                    'C' : np.random.randn(4),  # Multiple item
                    'D' : pd.Categorical(["test", "train", "test", "train"])})
df

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Create a dataframe, the columns of which are entitled `normal`, `exponential` and `laplace`, and contain random samples of size $10$ of each distribution.

# COMMAND ----------

# Answer
n = 10
samples = pd.DataFrame({'normal': stats.norm.rvs(size=n),
                       'exponential': stats.expon.rvs(size=n),
                       'laplace': stats.laplace.rvs(size=n)})
samples

# COMMAND ----------

# MAGIC %md
# MAGIC ## Viewing data <a id="part2sec2"></a>
# MAGIC Since it is unrealistic to view a table in whole, Pandas provides different methods to give a sneak look at the aforesaid table.

# COMMAND ----------

timeseries.index  # Index of the table

# COMMAND ----------

consumption.index  # Index of the table

# COMMAND ----------

consumption.columns  # Columns of the table

# COMMAND ----------

consumption.head(n=3)

# COMMAND ----------

consumption.tail(n=3)

# COMMAND ----------

consumption.values  # Values are in a Numpy array

# COMMAND ----------

# MAGIC %md
# MAGIC The methods `info` and `describe` give respectively general and quantitative information concerning the dataframe.
# MAGIC In particular, `info` indicates the categorical variables (which are not treated by `describe`).

# COMMAND ----------

df.info()

# COMMAND ----------

df.describe()

# COMMAND ----------

# MAGIC %md
# MAGIC If you suspect a variable to be categorical, you can state it.

# COMMAND ----------

df['E'] = np.random.randint(0, high=2, size=df.shape[0])
df['E'] = df['E'].astype('category')
df

# COMMAND ----------

df.info()

# COMMAND ----------

timeseries.sort_index(ascending=False)

# COMMAND ----------

timeseries.sort_values(by='A')

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Print the first 10 lines of the dataframe `consumption`.

# COMMAND ----------

# Answer
consumption.head(10)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Indexing a table <a id="part2sec3"></a>
# MAGIC ### Natural indexing

# COMMAND ----------

# MAGIC %md
# MAGIC Explanations are provided with the `consumption` dataframe.

# COMMAND ----------

consumption.head()

# COMMAND ----------

# MAGIC %md
# MAGIC Natural indexing is performed with `[]`.
# MAGIC This indexes the **columns** of dataframes and the **rows** of series.

# COMMAND ----------

consumption['England']

# COMMAND ----------

s = consumption['England']  # A series
s['Cheese']

# COMMAND ----------

# MAGIC %md
# MAGIC You may want to extract several columns or several rows.

# COMMAND ----------

consumption[['England', 'Scotland']].head()

# COMMAND ----------

s[['Cheese', 'Other meat']]

# COMMAND ----------

# MAGIC %md
# MAGIC **Remark:** selecting with `[[]]` always return a dataframe.

# COMMAND ----------

consumption[['England']].head()

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Print together columns `B` and `D` of the dataframe `df`.

# COMMAND ----------

# Answer
df[['B', 'D']]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Label based indexing
# MAGIC
# MAGIC Label based indexing is an enhancement of natural indexing, accessible with `.loc[]`.
# MAGIC Indexing has to be thought *as a matrix but with labels instead of positions*.
# MAGIC Hence, the **rows** are indexed first (instead of the columns with `[]`).

# COMMAND ----------

consumption.loc['Cheese']  # Single row

# COMMAND ----------

consumption.loc[:, 'England'].head()  # Single column

# COMMAND ----------

consumption.loc[['Cheese', 'Fresh potatoes']]  # Multiple rows

# COMMAND ----------

# MAGIC %md
# MAGIC Slicing on rows and columns is possible but **endpoints are included**.

# COMMAND ----------

consumption.loc['Cheese':'Fish']  # Row slicing

# COMMAND ----------

consumption.loc['Cheese':'Cereals':4]  # Row slicing (from Cheese to Cereals with step 2)

# COMMAND ----------

consumption.loc['Cheese':'Cereals':4, :'Wales']  # Row and column slicing

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC What is the value in the dataframe `timeseries` at row `2013-01-04` and column `B`?

# COMMAND ----------

# Answer
timeseries.loc['2013-01-04', 'B']

# COMMAND ----------

# MAGIC %md
# MAGIC ### Integer position based indexing
# MAGIC
# MAGIC Interger location (or position) based indexing is done with `.iloc[]`.
# MAGIC It is similar to `.loc[]` but consideres only integer positions instead of labels.
# MAGIC
# MAGIC **Remark:** endpoints are not included (similarly to Numpy).

# COMMAND ----------

consumption.iloc[:2]

# COMMAND ----------

consumption.iloc[10::4, ::2]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Boolean indexing
# MAGIC Similarly to Numpy arrays, dataframes can be indexed with Boolean variables thanks to `.loc[]`.

# COMMAND ----------

consumption.loc[consumption['England'] > 500]  # Row selection

# COMMAND ----------

consumption.loc[consumption['England'] > 500, consumption.loc['Other meat'] < 800]  # Row and column selection

# COMMAND ----------

# MAGIC %md
# MAGIC Operating on the whole dataframe puts `NaN` where the condition is not satisfied.
# MAGIC Beyond that, it is useful for assignments.

# COMMAND ----------

timeseries[timeseries > 0]  # Set NaN where condition is not satisfied

# COMMAND ----------

tt = timeseries.copy()
tt[tt < 0] = 0
tt

# COMMAND ----------

# MAGIC %md
# MAGIC The `isin` method enables selecting with an OR condition.

# COMMAND ----------

df.loc[df['D'].isin(['test', 'train'])]

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Select rows of `df` with $1$ in column `E`.

# COMMAND ----------

# Answer
df[df['E'] == 1]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Strange behaviors of natural indexing I do not recommend
# MAGIC Here are some strange and confusing behaviors of Pandas objects.
# MAGIC
# MAGIC I advise you **not to use** those features, but to adopt `.loc[]` and `.iloc[]` instead.
# MAGIC
# MAGIC Series (**not dataframes**) can be indexed with integer numbers.

# COMMAND ----------

s[0]

# COMMAND ----------

# MAGIC %md
# MAGIC And sliced… with endpoints **excluded**.

# COMMAND ----------

s[0:2]  # 0: Cheese, 1: Carcass meat, 2: Other meat

# COMMAND ----------

# MAGIC %md
# MAGIC Slicing is also possible with labels… with endpoints **included**.

# COMMAND ----------

s['Cheese':'Other meat']

# COMMAND ----------

# MAGIC %md
# MAGIC You can also slice **rows** of a dataframe using the same notation (while one would expect to slice columns).
# MAGIC Even stranger, slicing works with integer positions (for example `consumption[2:5]`), still with endpoints included with labels and excluded with integer positions, but not single indexing (`consumption[2]` raises an error).

# COMMAND ----------

consumption['Cheese':'Cereals':2]

# COMMAND ----------

# MAGIC %md
# MAGIC Similarly to slicing, Boolean indexing operates on dataframe rows.

# COMMAND ----------

consumption[consumption['England'] > 500]  # Similar to consumption.loc[consumption['England'] > 500]

# COMMAND ----------

# MAGIC %md
# MAGIC ### Selection random samples
# MAGIC
# MAGIC The `sample` method makes it possible to randomly select rows (individuals) from a dataframe (without replacement).

# COMMAND ----------

consumption.sample(n=3)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Adding and deleting items <a id="part2sec4"></a>
# MAGIC Let us consider a copy of the first 5 rows of `consumption`.

# COMMAND ----------

cons = consumption.iloc[:5].copy()
cons

# COMMAND ----------

# MAGIC %md
# MAGIC We successively add a column and a row to `cons`.

# COMMAND ----------

cons['all'] = cons.sum(axis=1)
cons.loc['Chocolate'] = [70, 60, 60, 150, 340]
cons

# COMMAND ----------

# MAGIC %md
# MAGIC That we can now drop.

# COMMAND ----------

cons = cons.drop('Chocolate')
cons = cons.drop('all', axis=1)
cons

# COMMAND ----------

# MAGIC %md
# MAGIC Dataframes can be concatenated along columns and rows.

# COMMAND ----------

pd.concat((cons[['England']], cons[['Scotland']]), axis=1)

# COMMAND ----------

pd.concat((cons.iloc[:2], cons.iloc[-2:]))

# COMMAND ----------

# MAGIC %md
# MAGIC This last operation is similar to:

# COMMAND ----------

cons.iloc[:2].append(cons.iloc[-2:])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Managing missing data <a id="part2sec5"></a>
# MAGIC Missing data are generally replaced by a `NaN` in the table.
# MAGIC Pandas offers several possibilities to manage them.

# COMMAND ----------

cons_md = consumption[consumption>200]
cons_md.iloc[:, -1] = consumption.iloc[:, -1]
cons_md.head()  # A table with missing data

# COMMAND ----------

cons_md.dropna()  # Drop any row with missing data

# COMMAND ----------

cons_md.fillna(method='ffill').head()  # Fill missing data with previous real values
# This does not work with the first line

# COMMAND ----------

cons_md.fillna(method='ffill').fillna(method='bfill').head()

# COMMAND ----------

cons_md.isnull().any()  # Test for missing data

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC By changing the `axis` parameter of `dropna`, drop the columns with missing values of `cons_md`.

# COMMAND ----------

# Answer
cons_md.dropna(axis=1).head()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Descriptive statistics <a id="part2sec6"></a>
# MAGIC A dataframe comes with many methods for descriptive statistics:
# MAGIC - `count`: 	Number of non-null observations;
# MAGIC - `sum`: 	Sum of values;
# MAGIC - `mean`: 	Mean of values;
# MAGIC - `mad`: 	Mean absolute deviation;
# MAGIC - `median`: 	Arithmetic median of values;
# MAGIC - `min`: 	Minimum;
# MAGIC - `max`: 	Maximum;
# MAGIC - `mode`: 	Mode;
# MAGIC - `abs`: 	Absolute Value;
# MAGIC - `prod`: 	Product of values;
# MAGIC - `std`: 	Bessel-corrected sample standard deviation;
# MAGIC - `var`: 	Unbiased variance;
# MAGIC - `sem`: 	Standard error of the mean;
# MAGIC - `skew`: 	Sample skewness (3rd moment);
# MAGIC - `kurt`: 	Sample kurtosis (4th moment);
# MAGIC - `quantile`: 	Sample quantile (value at %);
# MAGIC - `cumsum`: 	Cumulative sum;
# MAGIC - `cumprod`: 	Cumulative product;
# MAGIC - `cummax`: 	Cumulative maximum;
# MAGIC - `cummin`: 	Cumulative minimum.

# COMMAND ----------

df.median()  # Median of numeric columns

# COMMAND ----------

df.median(axis=1)  # Median of rows (numeric objects only)

# COMMAND ----------

df['D'].value_counts()  # Histrogramming

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Compute the cumulative sum of the consumption data.

# COMMAND ----------

# Answer
consumption.cumsum().tail()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pivot table <a id="part2sec7"></a>
# MAGIC A pivot table aggregates the values of a column according to the similar values of other columns (which will become the row indexes and columns labels of the aggregated table).

# COMMAND ----------

df['E'] = ['success', 'failure', 'failure', 'success']
df

# COMMAND ----------

# Pivot table:
# values: label of the column whose values will be reorganized and displayed in the table
# index: indexes of the final table
# columns: columns of the final table
pd.pivot_table(df, values='C', index='D', columns='E')

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plotting <a id="part2sec8"></a>
# MAGIC ### With pandas
# MAGIC Pandas provides a [rich collection](http://pandas.pydata.org/pandas-docs/stable/visualization.html) of techniques to vizualize dataframes.
# MAGIC Here, we illustrate just a few of them.

# COMMAND ----------

consumption.plot(figsize=(10, 6));  # Columns vs index

# COMMAND ----------

consumption.plot(subplots=True, figsize=(10, 8));  # Columns vs index

# COMMAND ----------

consumption.plot.barh(stacked=True, figsize=(10, 6));

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Plot a pie chart (parameter `kind='pie'` of `plot`) of the average consumption of foodstuff.

# COMMAND ----------

# Answer
consumption.mean(axis=1).plot(kind='pie', figsize=(6, 6))

# COMMAND ----------

# MAGIC %md
# MAGIC ### With Seaborn
# MAGIC Besides its esthetics purpose, [Seaborn](https://seaborn.pydata.org/api.html) provides many routines for producing beautiful plots from dataframes, particularly for statistical data.

# COMMAND ----------

fig, ax = plt.subplots(figsize=(10, 6))
sns.lineplot(x='England', y='Scotland', data=consumption);

# COMMAND ----------

tips = sns.load_dataset('tips')
tips.head()

# COMMAND ----------

import warnings
warnings.filterwarnings("ignore")

fig, ax = plt.subplots(figsize=(10, 6))
sns.violinplot(x='day', y='total_bill', hue='smoker', split=True, data=tips);

# COMMAND ----------

fig, ax = plt.subplots(figsize=(10, 6))
sns.barplot(x='day', y='tip', hue='time', data=tips)

# COMMAND ----------

# MAGIC %md
# MAGIC # Linear models <a id="part3"></a>
# MAGIC
# MAGIC [StatsModels](http://statsmodels.sourceforge.net/stable/index.html) is a scientific module based on Pandas for performing statistical analyses in Python.
# MAGIC It provides tools for conducting data exploration, statistical tests and for the estimation of several statistical models.
# MAGIC As a statistical package, each estimator in StatsModels comes with an extensive list of resulting statistics.
# MAGIC
# MAGIC ## Linear regression <a id="part3sec1"></a>
# MAGIC We illustrate here a major feature of StatsModels, which is [linear regression](http://www.statsmodels.org/stable/regression.html#technical-documentation).
# MAGIC ### Simple example

# COMMAND ----------

import statsmodels.api as sm
from statsmodels.sandbox.regression.predstd import wls_prediction_std

# Generate data
nsample = 50
sig = 0.5
x = np.linspace(0, 20, nsample)
X = np.column_stack((x, np.sin(x), (x-5)**2, np.ones(nsample)))
beta = [0.5, 0.5, -0.02, 5.]

y_true = np.dot(X, beta)
y = y_true + sig * np.random.normal(size=nsample)

y[np.random.permutation(y.size)[:3]] += 4 * (-1)**np.random.randint(0, 2, size=3)  # 3 outliers

# COMMAND ----------

# Fit the model
model = sm.OLS(y, X)
res = model.fit()
res.summary()

# COMMAND ----------

# MAGIC %md
# MAGIC Main attributes of the fitted model are:

# COMMAND ----------

print('Parameters: ', res.params)
print('Standard errors: ', res.bse)
print('Predicted values: ', res.fittedvalues)

# COMMAND ----------

# MAGIC %md
# MAGIC A method called `predict` is also available for prediction with the estimator:

# COMMAND ----------

res.predict(X)  # Same as res.fittedvalues

# COMMAND ----------

# Plot the regression
prstd, iv_l, iv_u = wls_prediction_std(res)  # Curves for standard deviation

fig, ax = plt.subplots()
ax.plot(x, y, 'o', label="data")
ax.plot(x, y_true, 'b-', label="True")
ax.plot(x, res.fittedvalues, 'r--.', label="OLS")
ax.plot(x, iv_u, 'r--')
ax.plot(x, iv_l, 'r--')
ax.legend(loc='best');

# COMMAND ----------

residues = y - res.predict(X)  # Same as res.resid
print(residues)

# COMMAND ----------

# MAGIC %md
# MAGIC The sum of squared residuals (or residual sum of squares) is:

# COMMAND ----------

print(np.sum(res.resid**2), res.ssr)

# COMMAND ----------

# MAGIC %md
# MAGIC while an unbiased estimate of the variance is:

# COMMAND ----------

print(res.ssr / res.df_resid, res.scale)

# COMMAND ----------

# MAGIC %md
# MAGIC The hat (or projection matrix) is:

# COMMAND ----------

H = X.dot(np.linalg.solve(X.T.dot(X), X.T))

# COMMAND ----------

# MAGIC %md
# MAGIC Then, the studentized residuals are:

# COMMAND ----------

t = res.resid / np.sqrt(res.scale*(1-np.diag(H)))  # Standardized residuals
ts = t * np.sqrt( (res.df_resid-1) / (res.df_resid-t**2))  # Studentized residuals
print(ts)

# COMMAND ----------

# MAGIC %md
# MAGIC The studentized residuals can be directly obtained by:

# COMMAND ----------

print(res.outlier_test()[:, 0])

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(ts, '.')
ax.plot([0, X.shape[0]], [-2]*2, 'r')
ax.plot([0, X.shape[0]], [2]*2, 'r')

outliers = np.where(res.outlier_test()[:, -1]<0.1)
ax.plot(outliers, res.outlier_test()[outliers, 0], 'ro')

# COMMAND ----------

# MAGIC %md
# MAGIC Note that studentized residuals are only asymptotically normal.

# COMMAND ----------

from scipy.stats import normaltest, probplot

print(normaltest(ts))

# COMMAND ----------

from scipy.stats import t as student_dist

probplot(ts, dist=student_dist(df=res.df_resid-1), plot=plt);

# COMMAND ----------

probplot(ts, dist='norm', plot=plt);

# COMMAND ----------

# MAGIC %md
# MAGIC ### Another example

# COMMAND ----------

df = sm.datasets.get_rdataset('iris').data
df.columns = [name.replace('.', '_').lower() for name in df.columns]  # Make name pythonic

df.describe()

# COMMAND ----------

df.isnull().any()  # Check if there is any missing value

# COMMAND ----------

import statsmodels.formula.api as smf

model =  smf.ols('sepal_length ~ petal_length + petal_width', data=df)
res = model.fit()
res.summary()

# COMMAND ----------

# MAGIC %md
# MAGIC StatsModels accepts categorical variables:

# COMMAND ----------

model = smf.ols('sepal_length ~ petal_length + petal_width + C(species)', data=df)
res = model.fit()
res.summary()

# COMMAND ----------

# MAGIC %md
# MAGIC To regress a variable *y* on all others, there is no notation equivalent to *y ~ .* in R. Instead, you can use the following workaround.

# COMMAND ----------

def all_predictors(df, outcome):
    return outcome + " ~ " + " + ".join(df.columns.difference([outcome]))

print(all_predictors(df, "sepal_length"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## ANOVA <a id="part3sec2"></a>
# MAGIC The last linear model can be formalized as:
# MAGIC $$Y = \mu \mathbb 1 + X\beta + A \alpha + \epsilon, \qquad s.t.~ \alpha_1 = 0,$$
# MAGIC where
# MAGIC - $Y \in \mathbb R^n$ is the vector of observations (`sepal_length`);
# MAGIC - $\mu \in \mathbb R$ is the intercept;
# MAGIC - $X \in \mathbb R^{n \times 2}$ is the design matrix;
# MAGIC - $\beta \in \mathbb R^2$ is the vector of coefficients (`petal_length` and `petal_width`);
# MAGIC - $A \in \mathbb R^{n \times 3}$ is the indicator matrix corresponding to the categorical variable (`species`);
# MAGIC - $\alpha \in \mathbb R^3$ is the vector of effects of the categorical values `setosa`, `versicolor` and `virginica`;
# MAGIC - $\epsilon \sim \mathcal N(0, \sigma^2 I_n)$ is a random noise.
# MAGIC
# MAGIC An analysis of variance (in its generalized version) tests the significance of continuous and categorical variables (based on a Fisher test), that is the null hypotheses (see the ANOVA table below):
# MAGIC - $\alpha_1 = \alpha_2 = \alpha_3 = 0$ (significance of `species`);
# MAGIC - $\beta_1 = 0$ (significance of `petal_length`);
# MAGIC - $\beta_2 = 0$ (significance of `petal_width`).

# COMMAND ----------

sm.stats.anova_lm(res)  # ANOVA table

# COMMAND ----------

# MAGIC %md
# MAGIC We read the p-values in the last column.
# MAGIC For the species, we observe a p-value that is small enough to reject the null hypothesis that the species does not impact the model.
# MAGIC In the same manner, we can conclude that `petal_length` is an important factor (its coefficient is non-zero).
# MAGIC However, the p-value for `petal_width` is large enough to conclude that, given the covariates `species` and `petal_length`, the variable `petal_width` does not provide an additional information, that explains the outcome `sepal_length` (it has no effect on the response variable).

# COMMAND ----------

# MAGIC %md
# MAGIC Assume now that you **know** $\beta$ and consider the model:
# MAGIC $$\tilde Y = Y - X\beta = \mu + A \alpha + \epsilon, \qquad s.t.~ \alpha_1 = 0.$$
# MAGIC The impact of the categorical variable `species` can be illustrated on the following graph, showing that the means are different according to the modalities of species (`setosa`, `versicolor`, `virginica`).

# COMMAND ----------

# Observations \tilde Y
sepal_beta = (0.9059, -0.006)
observations = df['sepal_length'] - sepal_beta[0]*df['petal_length'] - sepal_beta[1]*df['petal_width']

plt.plot(observations[df['species']=='setosa'], label="setosa")
plt.plot(observations[df['species']=='versicolor'], label="versicolor")
plt.plot(observations[df['species']=='virginica'], label="virginica")
plt.legend(loc='best');

# COMMAND ----------

# MAGIC %md
# MAGIC Assume now that you would like to test the Gaussian assumption of the model, that is for each modality indexed by $j \in \{1, 2, 3\}$, observations are distributed according to $\mathcal N(\mu + \alpha_j, \sigma^2)$.
# MAGIC You should test if the groups:
# MAGIC 1. are normally distributed;
# MAGIC 1. with equal variance.

# COMMAND ----------

from scipy.stats import levene, bartlett, normaltest

for modality in ['setosa', 'versicolor', 'virginica']:
    print(normaltest(observations[df['species']==modality]))

# COMMAND ----------

# MAGIC %md
# MAGIC Samples can be considered normaly distributed.
# MAGIC What about the variances?

# COMMAND ----------

print(levene(observations[df['species']=='setosa'], observations[df['species']=='versicolor'],
             observations[df['species']=='virginica']))
print(bartlett(observations[df['species']=='setosa'], observations[df['species']=='versicolor'],
               observations[df['species']=='virginica']))

# COMMAND ----------

# MAGIC %md
# MAGIC Variances can be considered the same.

# COMMAND ----------

# MAGIC %md
# MAGIC # Exercises <a id="part4"></a>
# MAGIC ## Exercise 1 <a id="part4sec1"></a>
# MAGIC Draw a sample from a chi-squared distribution with 5 degrees of freedom.
# MAGIC Plot the histogram and the probability distribution function on the same figure.

# COMMAND ----------

# Answer
import numpy as np
import scipy.stats as st
import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

s = st.chi2.rvs(df=5, size=1000)  # Chi2 sample
x = np.linspace(0, 25, num=100)

plt.hist(s, bins=20, density=True)
plt.plot(x, st.chi2.pdf(x, df=5), label="pdf", linewidth=2, color='red')
plt.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 2 <a id="part4sec2"></a>
# MAGIC Generate a sample from a standard normal distribution and another from a gamma distribution with shape $a=\frac 14$ and scale $\theta=2$.
# MAGIC Test for the null hypothesis that both samples have equal variances.
# MAGIC

# COMMAND ----------

# Answer
# Frozen variables
rv1 = st.norm()
rv2 = st.gamma(a=0.25, scale=2)

# Samples
rvs1 = rv1.rvs(size=50)
rvs2 = rv2.rvs(size=50)

# Check variances
print("Theoretically:", rv1.var(), rv2.var())
print("Empirically:", rvs1.var(), rvs2.var())

# Levene's test is an alternative to Bartlett's test in the case where there are
# significant deviations from normality.
tt, pval = st.levene(rvs1,rvs2)
print("p-value = {0:0.2f} (statistics = {1:0.2f})".format(pval, tt))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 3 <a id="part4sec3"></a>
# MAGIC Illustrate the central limit theorem with a binomial distribution with parameters $n=10$ and $p=0.7$.
# MAGIC Perform a test against a standard normal distribution to support the result.
# MAGIC

# COMMAND ----------

# Answer
N = 1000  # Number of repetitions for each sample
rv = st.binom(n=10, p=0.7)  # Binomial distribution

fig, ax = plt.subplots(2, 2, figsize=(10, 10))
x = np.linspace(-3, 3, num=50)  # For the histogram

for it, n in enumerate([10, 100, 1000, 5000]):  # Sample size
    s = rv.rvs(size=(n, N))  # N random samples of size n
    s_ctl = np.sqrt(n) / rv.std() * (s.mean(axis=0) - rv.mean())  # Asymptotically normal

    # Histogram
    ax.flat[it].hist(s_ctl, bins=20, density=True)
    ax.flat[it].plot(x, st.norm.pdf(x), label="norm", linewidth=2, color='red')
    ax.flat[it].set_title('n = '+str(n))

# COMMAND ----------

# Answer
print(st.kstest(s_ctl, 'norm'))  # Test against standard normal distribution

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 4 <a id="part4sec4"></a>
# MAGIC This exercise proposes to analyse a dataset.
# MAGIC - Load the R dataset `airquality` with `StatsModels` utilities.
# MAGIC - Make columns names pythonic (remove "." from solar.m).
# MAGIC - Drop rows with missing data.
# MAGIC - Display a summary of the dataset.
# MAGIC - Perform a linear regression to explain the ozone variable with solar_r , wind, temp and month (categorical variable).
# MAGIC - Display a summary of the linear regression.
# MAGIC - Are the residue normaly distributed?
# MAGIC - Perform an ANOVA.
# MAGIC - Predict the air quality for [today](https://www.wolframalpha.com/input/?i=La+Guardia+Airport) (suppose that solar_r = 207.0, convert wind to miles per hour and temp to degrees Fahrenheit by hitting `Show nonmetric`).
# MAGIC Use `res.predict(dict(solar_r=207, …))`.
# MAGIC

# COMMAND ----------

# Answer
import statsmodels.api as sm
import statsmodels.formula.api as smf

df = sm.datasets.get_rdataset('airquality').data
# Make name pythonic
df.columns = [name.replace('.', '_').lower() for name in df.columns]
df.dropna(inplace=True)  # Drop any row with missing data

df.describe()

# COMMAND ----------

# Answer
df.isnull().any()  # Test for missing data

# COMMAND ----------

# Answer
model = smf.ols('ozone ~ solar_r + wind + temp + C(month)', data=df)
res = model.fit()
res.summary()

# COMMAND ----------

# Answer
residue = df['ozone'] - res.fittedvalues

fig, ax = plt.subplots()
ax.hist(residue, bins=20, density=True);

# COMMAND ----------

# Answer
print(st.normaltest(residue))

# COMMAND ----------

# MAGIC %md
# MAGIC **Answer**
# MAGIC
# MAGIC Residues are not normally distributed.

# COMMAND ----------

# Answer
sm.stats.anova_lm(res)  # ANOVA table

# COMMAND ----------

# Answer
pred = res.predict(dict(solar_r=207, wind=3, temp=70, month=9))
print("Predicted value of air quality for today:", pred[0])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 5 <a id="part4sec5"></a>
# MAGIC Implement a [Metropolis Hastings algorithm](https://en.wikipedia.org/wiki/Metropolis%E2%80%93Hastings_algorithm).
# MAGIC Use it to sample a beta distribution with parameters $\alpha=2$ and $\beta=5$.
# MAGIC Compare with what is obtained with Scipy routines.

# COMMAND ----------

# Answer
rv = st.beta(a=2, b=5)
n = 2000  # Sample size

s = [0.5]  # Initialisation
while len(s) < n:
    y = s[-1]  # Previous point
    x = y + np.random.randn()
    r = rv.pdf(x) / rv.pdf(y)
    if r >= 1:
        s.append(x)
    else:
        if np.random.rand() < r:
            s.append(x)
        else:
            s.append(y)

# Histrogram
x = np.linspace(0, 1, num=50)  # For the histogram

fig, ax = plt.subplots()
ax.hist(s, bins=20, density=True)
ax.plot(x, rv.pdf(x));

# COMMAND ----------

# MAGIC %md
# MAGIC # References <a id="part5"></a>
# MAGIC - [StatsModels documentation](http://statsmodels.sourceforge.net/stable/index.html).
# MAGIC - [Scipy lecture notes](http://www.scipy-lectures.org/index.html).
# MAGIC - To go further: [advanced visualization with Seaborn](https://stanford.edu/~mwaskom/software/seaborn/tutorial.html).