# Databricks notebook source
# MAGIC %md
# MAGIC # Introduction to scientific computing with Python
# MAGIC *Maxime Sangnier*
# MAGIC
# MAGIC September, 2020
# MAGIC
# MAGIC ## Part 5: Additional topics

# COMMAND ----------

# MAGIC %md
# MAGIC # Table of contents
# MAGIC 1. [Object-oriented programming](#part1)
# MAGIC     - [What is it?](#part1sec1)
# MAGIC     - [Instanciating a class](#part1sec2)
# MAGIC     - [Creating a class](#part1sec3)
# MAGIC 1. [Basics of multiprocessing](#part2)
# MAGIC 1. [Machine learning in Python](#part3)
# MAGIC     - [Introduction](#part3sec1)
# MAGIC     - [Relation to statistics](#part3sec2)
# MAGIC     - [Machine learning in Python](#part3sec3)
# MAGIC     - [Scikit-learn API](#part3sec4)
# MAGIC     - [Example](#part3sec5)
# MAGIC 1. [Exercises](#part4)
# MAGIC     - [Exercise 1](#part4sec1)
# MAGIC     - [Exercise 2](#part4sec2)
# MAGIC     - [Exercise 3](#part4sec3)
# MAGIC 1. [References](#part5)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Object-oriented programming <a id="part1"></a>
# MAGIC This section is under construction.
# MAGIC Please, refer to the [official documentation](https://docs.python.org/3/tutorial/classes.html).
# MAGIC
# MAGIC ## What is it? <a id="part1sec1"></a>
# MAGIC A class is probably the most complex and powerful concept you may find in Python (it obviously exists in many other programming languages).
# MAGIC It is a template used to create objects (also called *instances* of the class in question), which generally have many attributes and methods.
# MAGIC
# MAGIC Let us remark that Python is a very flexible programming language, with consequently comes with rules we have to obey to cook in occordance with standard practice:
# MAGIC - classe names are often capitalized, in order to differentiate them from functions;
# MAGIC - private attributes are suffixed with `_`.
# MAGIC They are normally only aimed at developpers, not at users;
# MAGIC - attributes should never be modified directly (or very carefully).
# MAGIC They are aimed at defining the object and informing the user.
# MAGIC In order to modify an object, you should use methods.
# MAGIC
# MAGIC
# MAGIC ## Instanciating a class <a id="part1sec2"></a>
# MAGIC We start with a first example, aimed at creating an object from the class `np.ndarray`.
# MAGIC
# MAGIC Topics to be addressed:
# MAGIC - parameters of constructor
# MAGIC - methods

# COMMAND ----------

'rr'.capitalize()

# COMMAND ----------

import numpy as np
help(np.ndarray)

# COMMAND ----------

# MAGIC %md
# MAGIC In order to create the object `arr` (or instanciate the class `np.ndarray`), the constructor of the class is called with a set of parameters.
# MAGIC This constructor returns the desired instance.

# COMMAND ----------

arr = np.ndarray(shape=(2, 2), dtype=int)
arr

# COMMAND ----------

# MAGIC %md
# MAGIC As seen in the documentation, the object `arr` has attributes:

# COMMAND ----------

print(arr.shape, arr.size)

# COMMAND ----------

# MAGIC %md
# MAGIC which charactarize the object, and methods (these are functions), often aimed at modifying the object or at returning an information given a particular knowledge:

# COMMAND ----------

arr.sort()
arr

# COMMAND ----------

arr.mean(axis=0)

# COMMAND ----------

# MAGIC %md
# MAGIC All attributes and methods can be discovered in the documentation or with `dir`:

# COMMAND ----------

dir(arr)[-10:]

# COMMAND ----------

# MAGIC %md
# MAGIC At the first look, attributes are features (floats, lists, strings…) stored in the object and methods are functions aimed at acting on the object.
# MAGIC However, there may be an overlap between the roles of attributes and methods, as exemplified by the transposition of arrays:

# COMMAND ----------

arr.T

# COMMAND ----------

arr.transpose()

# COMMAND ----------

arr

# COMMAND ----------

# MAGIC %md
# MAGIC Both commands return exactly the same result, without modifying the object nor requiring an information, since `transpose()` is used without arguments (`.T` is actually defined by `transpose()`).
# MAGIC This is so because the transposition of an array may be seen either as a feature of the object (user's point of view) or as an information requiring to browse the array (developper's point of view).

# COMMAND ----------

# MAGIC %md
# MAGIC ## Creating a class <a id="part1sec3"></a>
# MAGIC Let us start with a naive example.

# COMMAND ----------

class Student():
    """
    name: student name
    num: student number
    """
    def __init__(self, name, num=0):
        self.name = name
        self.num = num
        self.mark_ = None
        
    def __str__(self):
        return 'Student {} (number {})'.format(self.name, self.num)
    
    def set_mark(self, mark):
        self.mark_ = mark if type(mark) is str else None
        
    def get_mark(self):
        return 'not filled' if self.mark_ is None else self.mark_

# COMMAND ----------

help(Student)

# COMMAND ----------

roger = Student('Roger', 42)
print(roger)
print('Mark:', roger.get_mark())

# COMMAND ----------

roger.set_mark('A')
print('Mark:', roger.get_mark())

# COMMAND ----------

# MAGIC %md
# MAGIC # Basics of multiprocessing <a id="part2"></a>
# MAGIC This section is under construction.
# MAGIC Please, refer to the [official documentation](https://docs.python.org/3/library/multiprocessing.html#module-multiprocessing.pool).
# MAGIC
# MAGIC The main idea of multiprocessing is to split a large amount of computations among differents computers or threads inside a computer.
# MAGIC For now, we will focus on the latter case, called multithreading.
# MAGIC It has the advantage to share memory on its own and not to be worried with broadcasting the data among various machines.
# MAGIC In addition, it can quickly be set up on a powerful personnal server or on a virtual machine in the cloud.
# MAGIC
# MAGIC Parallel computing particularly shines when:
# MAGIC - there are few expensive tasks rather many cheap ones;
# MAGIC - tasks are single threaded rather than multithreaded.
# MAGIC
# MAGIC Below is a naive example of sequential versus parallel computation in a favorable situation.

# COMMAND ----------

n = 1000  # Matrix size

make_psd = lambda x: x.dot(x.T)
matrices = [make_psd(np.random.randn(n, n)) for _ in range(4)]

def naive_work(M):
    R = np.ndarray((n, n))
    for i in range(M.size):
        R.flat[i] = np.exp(-M.flat[i])
    return R

# COMMAND ----------

from time import time

t_in = time()

res = []
for M in matrices:
    res.append(naive_work(M))
    
t_out = time()

print(f'{t_out - t_in:.0f} seconds')

# COMMAND ----------

from multiprocessing import Pool

t_in = time()

with Pool() as p:
    res = p.map(naive_work, matrices)
    
t_out = time()

print(f'{t_out - t_in:.0f} seconds')

# COMMAND ----------

# MAGIC %md
# MAGIC When tasks are multithreaded, parallel computing is useless.

# COMMAND ----------

def np_work(M):
    return np.exp(-M)
        
t_in = time()

res = []
for M in matrices:
    res.append(np_work(M))
    
t_out = time()

print(f'{t_out - t_in:.1f} seconds')

# COMMAND ----------

t_in = time()

with Pool() as p:
    res = p.map(np_work, matrices)
    
t_out = time()

print(f'{t_out - t_in:.1f} seconds')

# COMMAND ----------

# MAGIC %md
# MAGIC # Machine learning in Python <a id="part3"></a>
# MAGIC ## Introduction <a id="part3sec1"></a>
# MAGIC Machine learning is a vibrant scientific field at the connection between computer science, statistics, optimization and functional analysis:
# MAGIC - computer science: machine learning is mainly interested in *algorithms* for solving *tangible problems* (hand-written text recognition, image classification, etc.);
# MAGIC - statistics: it is all about estimating a property of the distribution from which the observed data is drawn;
# MAGIC - optimization: estimation often relies on minimizing an empirical risk;
# MAGIC - functional analysis: convergence guarantees for the algorithms as well as models for the estimator rely on this mathematical field.
# MAGIC
# MAGIC The tasks tackled in machine learning are:
# MAGIC - (semi-)supervised learning: discovering a link between an input data (observed) and an outcome (supposed unknown);
# MAGIC - unsupervised learning: discovering hidden patterns in data;
# MAGIC - reinforcement learning: learning to achieve a goal based on interacting with the environment.
# MAGIC
# MAGIC The rest of this document will focus on supervised learning.
# MAGIC
# MAGIC ## Relation to statistics <a id="part3sec2"></a>
# MAGIC Machine learning has deep roots into statistics since its main goal is to estimate a property of a distribution based on an observed sample.
# MAGIC However, machine learning defines a new paradigm of inference, to propose an answer to the difficulty of modeling the distribution of the data.
# MAGIC
# MAGIC Unlike inferential statistics, in which practitioners define a statistical model (assumption on the distribution from which is drawn the observed sample), machine learners define a model for the estimator (no assumption on the underlying distribution).
# MAGIC
# MAGIC To illustrate our words, let $(X, Y)$ be a couple of random variables with unknown joint distribution.
# MAGIC The main tasks of supervised learning are:
# MAGIC - regression: estimating $x \mapsto \mathbb E[Y ~|~ X=x]$, given that $Y$ has values in $\mathbb R$;
# MAGIC - classification: estimating $x \mapsto \operatorname{sign}\left(\frac{\mathbb P (Y=1 ~|~ X=x)}{\mathbb P (Y=-1 ~|~ X=x)} -1\right)$, given that $Y$ has values in $\{-1, 1\}$.
# MAGIC
# MAGIC These tasks of estimating the regression or classification function are done within a hypothesis class of functions (model on the estimator), regardless of the distribution of $(X, Y)$.
# MAGIC
# MAGIC ## Machine learning in Python <a id="part3sec3"></a>
# MAGIC Several packages are available for doing machine learning in Python, depending on the kind of methods the practitioner opts for:
# MAGIC - [Scikit-learn](http://scikit-learn.org/stable/) and [Shogun](http://www.shogun-toolbox.org/) are for general machine learning;
# MAGIC - [PyTorch](https://pytorch.org/), [TensorFlow](https://www.tensorflow.org/), [Theano](http://deeplearning.net/software/theano/) and [Caffe](http://caffe.berkeleyvision.org/installation.html) are devised for neural networks and deep learning.
# MAGIC
# MAGIC Here, we focus on [Scikit-learn](http://scikit-learn.org/stable/), which offers a broad range of machine learning methods and has a simple and well documented API.
# MAGIC
# MAGIC ## Scikit-learn API <a id="part3sec4"></a>
# MAGIC The general procedure for using a model is:
# MAGIC - creation (for instance of a decision tree):
# MAGIC
# MAGIC
# MAGIC     clf = tree.DecisionTreeClassifier()
# MAGIC - learning (estimation with data corresponding to $X$ and labels to $Y$):
# MAGIC
# MAGIC
# MAGIC     clf.fit(data, labels)
# MAGIC - prediction (of unknown labels):
# MAGIC
# MAGIC
# MAGIC     clf.predict(data)
# MAGIC
# MAGIC ## Example <a id="part3sec5"></a>
# MAGIC We provide here a (counter)example of a machine learning method for classification.
# MAGIC This one assumes that each class is normally distributed and estimates the Gaussian parameters using maximum likelihood.

# COMMAND ----------

import numpy as np
from sklearn.naive_bayes import GaussianNB
import matplotlib.pyplot as plt
%matplotlib inline

# Generate data
n = 200  # Sample size
x = np.r_[np.random.randn(n//2, 2) + [0, 1],
         np.random.randn(n//2, 2) + [3, -0.5]]  # Data
y = np.r_[np.ones(n//2), -np.ones(n//2)]  # Labels

# Fit and evaluate the model (classifier)
clf = GaussianNB()  # Model creation
clf.fit(x, y)  # Fit the model
y_pred = clf.predict(x)  # Predict with the model
s = clf.score(x, y)  # Compute the score
print("Classification score on training data is {0:0.0f}/100.".format(s*100))

# Plot data and prediction
fig, ax = plt.subplots()
mks = 10  # Marker size
alpha = 0.1
#ax.plot(x[y_pred>0, 0], x[y_pred>0, 1], 'bo', markersize=mks+5, alpha=alpha)  # Pred
#ax.plot(x[y_pred<0, 0], x[y_pred<0, 1], 'ro', markersize=mks+5, alpha=alpha)  # Pred
ax.plot(x[y>0, 0], x[y>0, 1], 'b.', markersize=mks)  # Ground truth
ax.plot(x[y<0, 0], x[y<0, 1], 'r.', markersize=mks);  # Ground truth

# Plot the frontier
X, Y = np.meshgrid(np.linspace(-5, 5, num=500), np.linspace(-5, 5, num=500))
X, Y = X.ravel(), Y.ravel()

Z = clf.predict_proba(np.c_[X, Y])[:, 0]
ind = np.where(np.fabs(Z-0.5) < 1e-2)
ax.plot(X[ind], Y[ind], 'g.', label="Frontier")

ax.legend(loc="best");

# COMMAND ----------

# MAGIC %md
# MAGIC # Exercises <a id="part4"></a>
# MAGIC ## Exercise 1 <a id="part4sec1"></a>
# MAGIC
# MAGIC Inspired by `scipy.stats`, define a class `Normal`, that represents a random variable following a Gaussian distribution.
# MAGIC The object should have attributes:
# MAGIC - `loc`: location;
# MAGIC - `scale`: scale;
# MAGIC - `mean`: theoretical mean;
# MAGIC - `std`: theoretical standard deviation;
# MAGIC - `var`: theoretical variance;
# MAGIC
# MAGIC and methods:
# MAGIC - `pdf(x)`: returns the pdf value for `x`;
# MAGIC - `rvs(size=1)`: returns an iid random sample of the specified sise.

# COMMAND ----------

# Answer
import numpy as np

class Normal():
    def __init__(self, loc=0, scale=1.):
        self.loc = loc
        self.scale = scale
        
    def __str__(self):
        return 'Normal random variable (loc={}, scale={})'.format(self.loc, self.scale)
    
    def __repr__(self):
        return self.__str__()
    
    @property
    def mean(self):
        return self.loc
    
    @property
    def std(self):
        return self.scale
    
    @property
    def var(self):
        return self.scale**2
    
    def pdf(self, x):
        return np.exp(-(x-self.loc)**2 / (2 * self.scale**2)) / (np.sqrt(2 * np.pi) * self.scale)
    
    def rvs(self, size=1):
        sample = np.random.randn(size) if size > 1 else np.random.randn()
        return sample * self.scale + self.loc
        
rv = Normal(loc=1, scale=2)
rv.rvs()

# COMMAND ----------

# MAGIC %md
# MAGIC How to redefine the previous class using inheritance?

# COMMAND ----------

# Answer

# Try on your own.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 2 <a id="part4sec2"></a>
# MAGIC
# MAGIC Compare time to solve 4 linear systems sequentially and using multithreading.

# COMMAND ----------

# Answer

# Try on your own.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 3 <a id="part4sec3"></a>
# MAGIC
# MAGIC We focus here on a classification problem.
# MAGIC Propose a procedure to evaluate the accuracy of a classifer.
# MAGIC Apply this procedure to compare a k-nearest neighbors algorithm with a decision tree on the Iris dataset.

# COMMAND ----------

# Answer

# Try on your own.

# COMMAND ----------

# MAGIC %md
# MAGIC # References <a id="part5"></a>
# MAGIC - [Official documentation](https://docs.python.org/3/tutorial/index.html).
# MAGIC - [Scikit-learn website](http://scikit-learn.org/stable/).