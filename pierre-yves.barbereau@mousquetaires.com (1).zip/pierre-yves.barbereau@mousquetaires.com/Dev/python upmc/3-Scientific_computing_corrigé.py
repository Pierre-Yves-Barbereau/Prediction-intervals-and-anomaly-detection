# Databricks notebook source
# MAGIC %md
# MAGIC # Introduction to scientific computing with Python
# MAGIC *Maxime Sangnier*
# MAGIC
# MAGIC September, 2020
# MAGIC
# MAGIC ## Part 3: Linear algebra and scientific computing

# COMMAND ----------

# MAGIC %md
# MAGIC # Table of contents
# MAGIC 1. [Numpy: numerical arrays in Python](#part1)
# MAGIC     - [What is Numpy](#part1sec1)
# MAGIC     - [Numpy array](#part1sec2)
# MAGIC     - [Operations on arrays](#part1sec3)
# MAGIC 1. [Scipy: scientific computing in Python](#part2)
# MAGIC     - [What is Scipy](#part2sec1)
# MAGIC     - [Special functions](#part2sec2)
# MAGIC     - [Linear algebra](#part2sec3)
# MAGIC     - [Optimization](#part2sec4)
# MAGIC     - [Interpolation](#part2sec5)
# MAGIC     - [Numerical integration](#part2sec6)
# MAGIC     - [Others](#part2sec7)
# MAGIC 1. [Loading and saving data](#part3)
# MAGIC     - [Basics](#part3sec1)
# MAGIC     - [Text files](#part3sec2)
# MAGIC     - [Images](#part3sec3)
# MAGIC     - [Numpy format](#part3sec4)
# MAGIC     - [Matlab format](#part3sec5)
# MAGIC     - [JSON](#part3sec6)
# MAGIC     - [Pickle](#part3sec7)
# MAGIC 1. [Exercises](#part4)
# MAGIC     - [Exercise 1](#part4sec1)
# MAGIC     - [Exercise 2](#part4sec2)
# MAGIC     - [Exercise 3](#part4sec3)
# MAGIC     - [Exercise 4](#part4sec4)
# MAGIC     - [Exercise 5](#part4sec5)
# MAGIC     - [Exercise 6](#part4sec6)
# MAGIC 1. [References](#part5)
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Numpy: numerical arrays in Python <a id="part1"></a>
# MAGIC ## What is Numpy <a id="part1sec1"></a>
# MAGIC Numpy is a fundamental extension of Python for scientific computing.
# MAGIC This package provides:
# MAGIC - a container, called `ndarray`, for handling numerical arrays;
# MAGIC - [routines](http://docs.scipy.org/doc/numpy/reference/routines.html#routines) for fast operations on arrays (including mathematical and statistical operations);
# MAGIC - universal mathematical functions (cos, log, exp…).
# MAGIC
# MAGIC The main asset of Numpy is the `ndarray` object.
# MAGIC Roughly speaking, a Numpy array is a list (or a list of lists of… for n-dimensional arrays) that comes with many methods for scientific computing implemented in fast compiled routines.
# MAGIC Despite the fact that Numpy arrays and lists serve as containers for a collection of items, they diverge on several points:
# MAGIC - an array is a collection of homogeneous objects (same data types);
# MAGIC - an array has a fixed size (definition at creation) while a list can grow dynamically;
# MAGIC - methods for arrays are scientific oriented and efficiently implemented.
# MAGIC
# MAGIC The following sections provide a basic introduction to Numpy virtues.
# MAGIC
# MAGIC ## Numpy array <a id="part1sec2"></a>
# MAGIC ### Creation
# MAGIC The main contribution of the numpy package is its multidimensional array.
# MAGIC Since it shares some features with Python lists, an array can be legitimately created from a list.
# MAGIC Let us begin with the following 2-dimensional list:

# COMMAND ----------

l = [[18., 17., 16.],
     [14., 19., 18.]]

print(l)

# COMMAND ----------

# MAGIC %md
# MAGIC The corresponding array can be created thanks to the `array` function:

# COMMAND ----------

import numpy as np

a = np.array(l)
print(a)

# COMMAND ----------

# MAGIC %md
# MAGIC Let us have a look to the more import attributes of the array object:

# COMMAND ----------

print("Rank (number of dimensions, also called axes) of a: ", a.ndim)

# COMMAND ----------

print("Dimensions (or shape) of a:", a.shape)  # The result is a tuple

# COMMAND ----------

print("Total number of items in a:", a.size)

# COMMAND ----------

print("Types of items:", a.dtype)

# COMMAND ----------

# MAGIC %md
# MAGIC Note that the type of items is automatically inferred at creation.
# MAGIC In the following example, an array of integers is created.

# COMMAND ----------

print(np.array([1, 2, 3]).dtype)

# COMMAND ----------

# MAGIC %md
# MAGIC The type can be changed *a posteriori* with `asarray`.

# COMMAND ----------

np.asarray(a, dtype='int64')

# COMMAND ----------

# MAGIC %md
# MAGIC The type can also be forced at creation:

# COMMAND ----------

b = np.array([1, 2, 3], dtype="complex")

print(b)
print(b.dtype)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Arrays from Numpy routines
# MAGIC Appart from the `array` function, a Numpy array can be created in several other ways (see the documentation for further details on the parameters):

# COMMAND ----------

np.arange(15)

# COMMAND ----------

np.zeros((3, 4))

# COMMAND ----------

np.ones((2, 10))

# COMMAND ----------

np.eye(3)

# COMMAND ----------

np.diag([1., 2, 3])

# COMMAND ----------

np.linspace(0, 1, num=6)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Consult the help of `arange` and produce the object `array([ 2,  5,  8, 11, 14])`.

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ### Shape modification
# MAGIC The shape of an array can be modified with many routines.
# MAGIC The main one is `resize`.
# MAGIC
# MAGIC In Python, the norm for resizing a vector is *the rightmost index changes first*.
# MAGIC This means that a 2D array `m` is filled in the following order: m[0, 0], m[0, 1], m[0, 2], …, m[1, 0]…
# MAGIC **This is different from R and Matlab**.

# COMMAND ----------

m = np.arange(12)
m.resize(4, 3)  # In-place operation
print(m)

# COMMAND ----------

# MAGIC %md
# MAGIC This is equivalent to modifying the `shape` attribute of the array (yet I advise you not to use it):

# COMMAND ----------

m.shape = (3, 4)
print(m)

# COMMAND ----------

# MAGIC %md
# MAGIC To go back to a one-dimensional array, one can use the `ravel` method:

# COMMAND ----------

m.ravel()  # Not in-place

# COMMAND ----------

# MAGIC %md
# MAGIC Note that this is **not an in-place** method, meaning that it does not alter the original array.
# MAGIC About this, two other methods are similar to `resize` and `ravel`:
# MAGIC - `reshape` creates a new **view** of the object while `resize` runs **in-place**;
# MAGIC - `flatten` creates a **copy** of the object while `ravel` returns a new **view**.
# MAGIC The difference between copy and view is explained below.

# COMMAND ----------

print(m.reshape(2, 6))

# COMMAND ----------

print(m.flatten())

# COMMAND ----------

print(m)

# COMMAND ----------

# MAGIC %md
# MAGIC Note that with the `reshape` method and the `shape` attribute, one dimension can be automatically calculated by giving `-1`:

# COMMAND ----------

m.shape = (2, -1)
print(m)

# COMMAND ----------

m.reshape(-1, 2)

# COMMAND ----------

# MAGIC %md
# MAGIC **Remark :**
# MAGIC I advise you to use `reshape` and `ravel`, which are two convenient methods returning a new view of the object.

# COMMAND ----------

# MAGIC %md
# MAGIC Finally, a new dimension can be added to an array with the object `newaxis`:

# COMMAND ----------

c = np.ones(3)
print(c)

# COMMAND ----------

c = c[:, np.newaxis]
print(c)

# COMMAND ----------

# MAGIC %md
# MAGIC This technique is equivalent to reshaping with dimensions `(-1, 1)`:

# COMMAND ----------

np.ones(3).reshape(-1, 1)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Repetition and concatenation
# MAGIC Besides modifying their shapes, arrays can also be repeated and concatenated:

# COMMAND ----------

m = np.arange(4).reshape(2, -1)
print(m)

# COMMAND ----------

np.tile(m, (2, 3))  # 2 repetitions in line, 3 in column

# COMMAND ----------

p = np.linspace(-2, -0.5, num=4).reshape(2, -1)
print(p)

# COMMAND ----------

np.concatenate((m, p))

# COMMAND ----------

np.concatenate((m, p), axis=1)

# COMMAND ----------

# MAGIC %md
# MAGIC For 2D-arrays, the last two operations can also be done by stacking arrays vertically or horizontally:

# COMMAND ----------

np.vstack((m, p))

# COMMAND ----------

np.hstack((m, p))

# COMMAND ----------

# MAGIC %md
# MAGIC Finally, stacking objects of different kinds may also be a way to create arrays.
# MAGIC This is the purpose of the routines `r_` (for *row*) and `c_` (for *column*).
# MAGIC The first one is used for concatenating horizontally 1D-arrays while the second one serves for 2D-arrays.
# MAGIC Beware of the notation. It is quite unusual:

# COMMAND ----------

np.r_[0:6:2, -1:1:6j, [0]*3, 5, 6, np.array([1, 3, 5])]

# COMMAND ----------

# MAGIC %md
# MAGIC Here, we used the slice notation of `0:6:2`, which produces the same as `np.arange(0, 6, step=2)`, that is `[0, 2, 4]` (no 6!).
# MAGIC However, when the step is an imaginary number, the slice notation is equivalent to a linspace.
# MAGIC In other words, `-1:1:6j` produces the same as `np.linspace(-1, 1, num=6)`.

# COMMAND ----------

np.c_[m, [[0], [0]], p]  # Concatenation of 2D-arrays

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC With `reshape` and `concatenate`, produce the array:
# MAGIC     
# MAGIC     [[ 0 -2  0  2]
# MAGIC      [-4 -6  4  6]].

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ### Indexing and slicing
# MAGIC A one-dimensional array can be indexed, sliced and iterated over the same way as a list:

# COMMAND ----------

a = np.arange(4)
print(a)
a[1:3]

# COMMAND ----------

a[[0, 2]]

# COMMAND ----------

for it in np.linspace(0, 1, num=6):
    print(it**2, end=" ")

# COMMAND ----------

# MAGIC %md
# MAGIC For a multi-dimensional array (here 2D), a single index is interpreted as accessing the first axis of the array:

# COMMAND ----------

m = np.arange(12).reshape(4, 3)
print(m)

# COMMAND ----------

# MAGIC %md
# MAGIC Note that the first axis is understood from **top to bottom**.

# COMMAND ----------

print(m[0])

# COMMAND ----------

for row in m:
    print(row)

# COMMAND ----------

# MAGIC %md
# MAGIC To iterate on each element of a multi-dimensional array, one can use the `flat` attribute, which is an iterator over all items:

# COMMAND ----------

c = 0
for it in m.flat:
    c += 1 - it%2
print("Number of even items:", c)

# COMMAND ----------

# MAGIC %md
# MAGIC Yet, one can access items of a multi-dimensional array with multi-dimensional indexes:

# COMMAND ----------

m[0, 1]

# COMMAND ----------

# MAGIC %md
# MAGIC Note that this is equivalent to:

# COMMAND ----------

m[0][1]

# COMMAND ----------

# MAGIC %md
# MAGIC Some parameters of the slice can be automatically inferred:

# COMMAND ----------

m[:2, 1:]  # Until Row 2 (excluded), from Column 1 (included)

# COMMAND ----------

m[2:, :]  # ':' means 'all'

# COMMAND ----------

# MAGIC %md
# MAGIC A feature of Numpy is to provide two methods of *fancy indexing* for arrays.
# MAGIC The first one is with lists/arrays:

# COMMAND ----------

print(m)
print("Extracted array:", m[[1, 1, 2], [0, 1, 2]])

# COMMAND ----------

# MAGIC %md
# MAGIC The second method is using masks:

# COMMAND ----------

print(np.logical_and(3 < m, m < 9))

# COMMAND ----------

print(m[np.logical_and(3 < m, m < 9)])

# COMMAND ----------

# MAGIC %md
# MAGIC These two methods are particularly useful for assignments:

# COMMAND ----------

m[m%2 == 1] -= 1
print(m)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Set all the negative items of the following array to 0.

# COMMAND ----------

u = ((-1)**np.arange(12) * (np.arange(-6, 6))).reshape(3, -1)
print(u)

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ### Copies and views
# MAGIC As already stated in the first part of this tutorial, Python objects are rarely copied but often only bound.
# MAGIC This is still true with Numpy arrays (they are mutable objects) and even a bit more complicated.
# MAGIC There are three situations:
# MAGIC #### No copy
# MAGIC With the assignment operator and arrays as parameters of a function, there is no copy:

# COMMAND ----------

p = m
p is m

# COMMAND ----------

def f(x):
    return id(x)

print(id(m), f(m))

# COMMAND ----------

# MAGIC %md
# MAGIC #### View
# MAGIC With Numpy, two arrays can share the same data.
# MAGIC The `view` method enables to create a new array that looks at the same data:

# COMMAND ----------

p = m.view()
p is m  # Different objects

# COMMAND ----------

p.base is m.base  # Same data

# COMMAND ----------

# MAGIC %md
# MAGIC Some attributes of a view can be modified without altering the data.
# MAGIC For instance the shape:

# COMMAND ----------

p.shape = (1, -1)
print(p)

# COMMAND ----------

print(m)

# COMMAND ----------

# MAGIC %md
# MAGIC As an example, slicing and array returns a view of it:

# COMMAND ----------

s = m[1, 1:]
print(s)

# COMMAND ----------

s.base is m.base

# COMMAND ----------

s[:] = -1
print(s)

# COMMAND ----------

print(m)

# COMMAND ----------

# MAGIC %md
# MAGIC #### Copy
# MAGIC The `copy` method makes a complete copy of an array (object and data):

# COMMAND ----------

p = m.copy()
print(p is m, p.base is m.base)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Operations on arrays <a id="part1sec3"></a>
# MAGIC ### Basic operations
# MAGIC In Numpy, operations on arrays are elementwise.
# MAGIC The result is returned in a new array.

# COMMAND ----------

a = np.arange(4)
print("a =", a)

b = a * 10  # Product with a scalar
print("b =", b)

# COMMAND ----------

b-a  # Sum and differences

# COMMAND ----------

a**2  # Power

# COMMAND ----------

a * b  # Product with another array

# COMMAND ----------

b < 10.5  # Comparison

# COMMAND ----------

# MAGIC %md
# MAGIC Som operations, such as *+=* and **=* are inplace (no copy):

# COMMAND ----------

a += 2
print(a)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Broadcasting
# MAGIC A major feature of array is operation broadcasting, that is the ability to operate on arrays with different shapes.
# MAGIC Broadcasting is a way of vectorizing array operations with fast backward implementations.
# MAGIC
# MAGIC The main rule of broadcasting is that the shapes of two arrays are compatible when:
# MAGIC - they are the same;
# MAGIC - a shape is different but is equal to 1 (in this case, the array is identically repeated along this direction);
# MAGIC - a dimension is missing (in this case, numpy creates a new dimension at the beginning and the array is identically repeated along this new first direction).
# MAGIC
# MAGIC A common example of this last case is operation between an array and a reduced version of it along the axis 0 (see below).

# COMMAND ----------

x = np.arange(12).reshape(4, -1)
print(x)

# COMMAND ----------

# MAGIC %md
# MAGIC The mean along the first axis is:

# COMMAND ----------

m = x.mean(axis=0)
print(m)

# COMMAND ----------

# MAGIC %md
# MAGIC Then, centering the array can be easily performed in the following way:

# COMMAND ----------

c = x - m
print(c)

# COMMAND ----------

print(c.mean(axis=0))

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC What is the aim of the operation `u - ur.reshape(-1, 1)`?

# COMMAND ----------

u = np.arange(16).reshape(4, -1)
ur = u.mean(axis=1)

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ### Mathematical methods
# MAGIC As stated in the introduction, a major feature of Numpy is to provide mathematical methods with fast implementations.
# MAGIC For instance:

# COMMAND ----------

print(a)
a.sum(), a.prod()

# COMMAND ----------

a.cumsum()

# COMMAND ----------

a.mean(), a.std()

# COMMAND ----------

a.min(), a.max()

# COMMAND ----------

a.argmin(), a.argmax()

# COMMAND ----------

c = np.array([4, 3, 6, 5, 9])
c.sort()  # In-place sorting
print(c)

# COMMAND ----------

# MAGIC %md
# MAGIC Note that for multidimensional arrays, the axis of operation can be specified:

# COMMAND ----------

m = np.arange(12).reshape(4, -1)
print(m)
print(m.sum(axis=1))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Universal functions
# MAGIC As a mathematical package, Numpy provides elementary functions (called [*universal functions*](http://docs.scipy.org/doc/numpy/reference/ufuncs.html#math-operations)) such as the following ones.
# MAGIC These functions apply element-wise and return an array.

# COMMAND ----------

import matplotlib.pyplot as plt
import seaborn as sns
sns.set()

t = np.linspace(0, 2*np.pi, num=50)

fig, ax = plt.subplots()
ax.plot(t, np.sin(t), label="sin")
ax.plot(t, np.cos(t), label="cos")
ax.plot(t, np.exp(-t), label="exp")
ax.legend();

# COMMAND ----------

fig, ax = plt.subplots()
ax.plot(t, np.fmax(np.sin(t), np.cos(t)));

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Compute and plot on the last graphic the curve of $\left| \max(\sin(t), \cos(t)) - 0.25 \right|$.

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ### Linear algebra
# MAGIC A major application of Numpy is [linear algebra](http://docs.scipy.org/doc/numpy/reference/routines.linalg.html).
# MAGIC For this purpose, Numpy provides a `matrix` object, yet it is hardly ever used in practice.
# MAGIC Scientists generally prefer to handle traditional arrays with routines from linear algebra.
# MAGIC Some examples are provided below.

# COMMAND ----------

a = np.ones(5)
print(a)

b = np.arange(5)
print(b)

# COMMAND ----------

print(a.dot(b))  # Dot product

# COMMAND ----------

A = np.outer(a, b)  # Outer product
print(A)

# COMMAND ----------

B = np.diag([0.2, 0.7, -1, 2, 5])
print(B)

# COMMAND ----------

print(A.dot(B))  # Matrix product (different from A*B!)

# COMMAND ----------

print(A.T)  # Transposed matrix

# COMMAND ----------

C = np.random.randn(*A.shape)
C = C.dot(C.T)  # Symmetric positive semidefinite matrix

np.set_printoptions(precision=2)
print(C)

# COMMAND ----------

print(np.linalg.eigvalsh(C))  # Eigenvalues

# COMMAND ----------

print(np.linalg.eigvalsh(C).sum(), C.trace())  # Trace of C

# COMMAND ----------

invC = np.linalg.inv(C)  # Inverse of C
pC = invC.dot(C)
pC[pC < 1e-10] = 0  # Erase numerical errors before printing

print(pC)

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Based on the array defined below, compute the matrix $(2^{-|i-j|})_{1 \le i, j \le 4}$.

# COMMAND ----------

ind = np.outer(np.arange(4), np.ones(4))
print(ind)

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ### Others

# COMMAND ----------

print(np.any(C < -1, axis=0))  # Test if a column has at least one value less than -1

# COMMAND ----------

print(np.all(C > -5, axis=1))  # Test if a row has all values greater than -5

# COMMAND ----------

indx, indy = np.where(C < -1)  # Indices where C is less than -1
# This is equivalent to np.nonzero(C < -1).
print(indx, indy)

# COMMAND ----------

print(C[indx, indy])

# COMMAND ----------

np.floor(C)  # Floor of C

# COMMAND ----------

# MAGIC %md
# MAGIC # Scipy: scientific computing in Python <a id="part2"></a>
# MAGIC ## What is Scipy <a id="part2sec1"></a>
# MAGIC Scipy is a collection of mudules for various mathematical purposes.
# MAGIC Leveraging the Numpy package, Scipy offers a broad and powerful environment for solving scientific problems.
# MAGIC Roughly speaking, Scipy is to Python what toolboxes are to Matlab.
# MAGIC
# MAGIC In the forthcoming sections, a few modules of Scipy are skimmed.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Special functions <a id="part2sec2"></a>
# MAGIC An important feature of the [scipy.special](http://docs.scipy.org/doc/scipy/reference/special.html#module-scipy.special) module is the definition of numerous mathematical functions, called *special functions*.
# MAGIC Available functions include Airy, elliptic, Bessel, gamma, beta, hypergeometric, parabolic cylinder, Mathieu, spheroidal wave, Struve, and Kelvin.

# COMMAND ----------

# MAGIC %md
# MAGIC **Question**
# MAGIC
# MAGIC Plot the error function on the line $[-3, 3]$.

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ## Linear algebra <a id="part2sec3"></a>
# MAGIC The [scipy.linalg](http://docs.scipy.org/doc/scipy/reference/linalg.html#module-scipy.linalg) module is crafted for linear algebra.
# MAGIC It subsumes all the functions in numpy.linalg and adds other more advanced ones.
# MAGIC
# MAGIC Here is a non-exhaustive list of scipy.linalg's assets.
# MAGIC
# MAGIC ### Inverse of a matrix

# COMMAND ----------

from scipy import linalg
print(C)

# COMMAND ----------

pC_sci = linalg.inv(C).dot(C)
pC_sci[pC_sci < 1e-10] = 0  # Erase numerical errors before printing

print(pC)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Solving a linear system
# MAGIC Here we try to solve the linear system $Cx = b$ for $x$.

# COMMAND ----------

b = np.random.randn(C.shape[0])
x = linalg.solve(C, b)
print(x)

# COMMAND ----------

print(C.dot(x), b)

# COMMAND ----------

# MAGIC %md
# MAGIC **Remark:**
# MAGIC It is numerically more efficient to compute $C^{-1}b$ with `solve` than `inv`.

# COMMAND ----------

from timeit import timeit

setup = """
from scipy.linalg import solve, inv
from numpy.random import randn

n = 200
C = randn(n, n)
C = C.dot(C.T)
b = randn(n)
"""

print('solve: {0:0.2f}s'.format(timeit('x = solve(C, b);', setup=setup, number=100)))
print('inv: {0:0.2f}s'.format(timeit('x = inv(C).dot(b);', setup=setup, number=100)))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Eigendecomposition
# MAGIC The eigendecomposition is illustrated here, yet many others are available: singular value, LU, Cholesky, QR and Schur decompositions.

# COMMAND ----------

print(linalg.eigvalsh(C))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Special matrices
# MAGIC An important feature of `scipy.linalg` over `numpy.linalg` is to provide several functions for creating special matrices such as block diagonal, circulant, Hadamard, Toeplitz…

# COMMAND ----------

print(linalg.block_diag(A, B))

# COMMAND ----------

print(linalg.circulant(np.arange(4)))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optimization <a id="part2sec4"></a>
# MAGIC The [scipy.optimize](http://docs.scipy.org/doc/scipy/reference/optimize.html#module-scipy.optimize) module offers several common but efficient routines for constrained and unconstrained optimization, as well as curve fitting and root finding.
# MAGIC ### Local optimization
# MAGIC The main interfaces for optimization offered by scipy.optimize are `minimize` (Nelder-Mead, BFGS, Newton, etc.) for local multivariate optimization, `minimize_scalar` for univariate optimization and `linprog` for linear programming (Simplex algorithm). In addition, other routines are available for global optimization and least-squares.

# COMMAND ----------

from scipy import optimize
# import warnings
# warnings.filterwarnings('ignore')

def f(x):
    return x**2 + 10*np.sin(x)

# COMMAND ----------

x = np.arange(-10, 10, 0.1)

fig, ax = plt.subplots()
ax.plot(x, f(x), linewidth=2)

for x0 in np.linspace(-10, 10, 5):
    sol = optimize.minimize(f, x0, method='BFGS')
    ax.annotate("", xy=(sol.x[0], f(sol.x[0])), xytext=(x0, f(x0)), size=20,
                arrowprops=dict(arrowstyle="-|>", connectionstyle="arc3,rad=-0.2", edgecolor="k", facecolor='w'))
    ax.plot(x0, f(x0), 'go', markersize=8)
    ax.plot(sol.x, f(sol.x), '*r', markersize=12)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Curve fitting
# MAGIC Given some points $\{x_i, y_i\}_{i=1}^n$ and a model $f(\cdot, \theta)$ parametrized by $\theta$, `scipy.optimize.curve_fit` finds a good parameter $\theta^\star$ that makes it possible for the model $f(\cdot, \theta^\star)$ to explain $y_i$ based on $x_i$.
# MAGIC The solution $\theta^\star$ is obtained by solving non-linear least-squares.

# COMMAND ----------

def f_model(x, theta1, theta2, theta3, theta4):
    return theta1*x**2 + theta2*np.sin(x+np.pi/6)

x = np.linspace(-10, 10, num=10)
y = f(x)

popt, pcov = optimize.curve_fit(f_model, x, y)

x_plot = np.arange(-10, 10, 0.1)

fig, ax = plt.subplots()
ax.plot(x_plot, f(x_plot), linewidth=2, label="true")
ax.plot(x_plot, f_model(x_plot, *popt), linestyle='dashed', color="red", linewidth=2, label="fitted")
ax.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC ### Root finding
# MAGIC Several routines are available for finding roots and fixed points of a function (see [scipy.optimize](http://docs.scipy.org/doc/scipy/reference/optimize.html#module-scipy.optimize)).
# MAGIC For instance, one can use `fsolve`:

# COMMAND ----------

x = np.arange(-10, 10, 0.1)

fig, ax = plt.subplots()
ax.plot(x, f(x), linewidth=2)

for x0 in np.linspace(-4, 4, 4):
    root = optimize.fsolve(f, x0)
    ax.annotate("", xy=(root[0], f(root[0])), xytext=(x0, f(x0)), size=20,
                arrowprops=dict(arrowstyle="-|>", connectionstyle="arc3,rad=-0.2", edgecolor="k", facecolor="w"))
    ax.plot(x0, f(x0), 'go', markersize=8)
    ax.plot(root, f(root), '*r', markersize=12)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Interpolation <a id="part2sec5"></a>
# MAGIC [scipy.interpolate](http://docs.scipy.org/doc/scipy/reference/interpolate.html#module-scipy.interpolate) provides functions for uni and multivariate data interpolation.
# MAGIC Here, we only focus on unidimensional interpolation.

# COMMAND ----------

from scipy.interpolate import interp1d


x = np.linspace(-10, 10, num=10)
x_plot = np.arange(-10, 10, 0.1)

fig, ax = plt.subplots()
ax.plot(x_plot, f(x_plot), linewidth=2, label="true")
ax.plot(x, f(x), 'o', markersize=6, color="blue")

for kind in ['linear', 'cubic']:
    f_inter = interp1d(x, f(x), kind=kind)
    ax.plot(x_plot, f_inter(x_plot), label=kind, linewidth=2, linestyle="dashed")
ax.legend();

# COMMAND ----------

# MAGIC %md
# MAGIC ## Numerical integration <a id="part2sec6"></a>
# MAGIC In the [scipy.integrate](http://docs.scipy.org/doc/scipy/reference/integrate.html#module-scipy.integrate) module, one can find several methods (trapezoidal, Simpson, Romberg, etc) for integrating uni, bi and trivariate functions.
# MAGIC Below is an example of univariate integration.

# COMMAND ----------

from scipy.special import erf
from scipy.integrate import quad

f = lambda x: np.exp(-x**2)*2/np.sqrt(np.pi)
I, I_err = quad(f, 0, 1)
print(I, erf(1))

# COMMAND ----------

# MAGIC %md
# MAGIC ## Others <a id="part2sec7"></a>
# MAGIC Other possibilities of Scipy include:
# MAGIC - Fourier transforms ([scipy.fftpack](http://docs.scipy.org/doc/scipy/reference/fftpack.html#module-scipy.fftpack));
# MAGIC - sparse matrices ([scipy.sparse](docs.scipy.org/doc/scipy/reference/sparse.html));
# MAGIC - signal processing ([scipy.signal](http://docs.scipy.org/doc/scipy/reference/signal.html#module-scipy.signal));
# MAGIC - spatial structures ([scipy.spatial](http://docs.scipy.org/doc/scipy/reference/spatial.html#module-scipy.spatial));
# MAGIC - multidimensional image processing ([scipy.ndimage](http://docs.scipy.org/doc/scipy/reference/ndimage.html#module-scipy.ndimage)).
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC # Loading and saving data <a id="part3"></a>
# MAGIC The core of Python as well as Numpy and Scipy provide several routines for loading and saving data.
# MAGIC We will review some of them.
# MAGIC
# MAGIC ## Basics <a id="part3sec1"></a>
# MAGIC With Python only, files are handled thanks to a file object, initialized with `open` and that should be closed after operations completed.
# MAGIC Roughly speaking, operations may be `write`, `read`, `readline` and `readlines`.
# MAGIC Note that only strings can be saved thanks to those routines.
# MAGIC
# MAGIC One can open a file with different modes:
# MAGIC - `r`: read only;
# MAGIC - `w`: write only;
# MAGIC - `a`: append;
# MAGIC - `r+`: read and write;
# MAGIC - `[rwa]b`: (read, write, append) binary.

# COMMAND ----------

f = open('aux/an_example.txt', 'w')

f.write("""This file is an example.
It illustrates how to write in a file.
As well as how to read a file.""")

f.close()

# COMMAND ----------

!cat aux/an_example.txt

# COMMAND ----------

# MAGIC %md
# MAGIC It is good practice for handling exceptions and being sure that the file is closed properly to replace the previous script by:

# COMMAND ----------

with open('aux/an_example.txt', 'w') as f:
    f.write("""This file is an example.
It illustrates how to write in a file.
As well as how to read a file.""")

print("File closed:", f.closed)

# COMMAND ----------

with open('aux/an_example.txt', 'r') as f:
    s = f.read()
    print(s)

# COMMAND ----------

# MAGIC %md
# MAGIC The functions `readline` and `readlines` respectively read a single line and put all lines in a list.

# COMMAND ----------

with open('aux/an_example.txt', 'r') as f:
    print("First line:", f.readline())
    print("Second line:", f.readline())

# COMMAND ----------

with open('aux/an_example.txt', 'r') as f:
    s = f.readlines()
    print(s)

# COMMAND ----------

# MAGIC %md
# MAGIC One may also iterate over the lines of a file.

# COMMAND ----------

with open('aux/an_example.txt', 'r') as f:
    for it, line in enumerate(f):
        print("Line", it, ":", line)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Text files <a id="part3sec2"></a>
# MAGIC Numpy provides two routines for handling arrays saved in text files: `loadtxt` and `savetxt`.

# COMMAND ----------

!cat data/consumption.csv

# COMMAND ----------

data = np.loadtxt("data/consumption.csv", delimiter=";", skiprows=1)
print(data)

# COMMAND ----------

# Standardization
data -= data.mean(axis=0)
data /= data.std(axis=0)

# Save the data
np.savetxt("data/consumption_std.csv", data)

# COMMAND ----------

data_txt = np.loadtxt("data/consumption_std.csv")
print(data_txt)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Images <a id="part3sec3"></a>
# MAGIC Images can be read and saved thanks to the functions *imread* and *imsave* from matplotlib.pyplot.

# COMMAND ----------

import matplotlib.pyplot as plt

img = plt.imread("img/upmc.jpg")

fig, ax = plt.subplots()
ax.imshow(img);
ax.grid(False)

# COMMAND ----------

plt.imsave("img/upmc3.jpg", img[:, :, 0], cmap=plt.cm.gray)  # Save only one channel

# COMMAND ----------

# MAGIC %md
# MAGIC Saved image:
# MAGIC
# MAGIC <img src="img/upmc3.jpg" width=200>

# COMMAND ----------

# MAGIC %md
# MAGIC ## Numpy format <a id="part3sec4"></a>
# MAGIC Numpy has its own binary format.
# MAGIC Note that it does not promote interoperability.

# COMMAND ----------

np.save('data/consumption.npy', data)

# COMMAND ----------

data_npy = np.load('data/consumption.npy')
print(data_npy)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Matlab format <a id="part3sec5"></a>
# MAGIC Scipy offers the possibility to save and read Matlab files with the functions *loadmat*, *whosmat* and *savemat*.

# COMMAND ----------

import scipy.io as sio

sio.savemat('data/consumption.mat', {'data': data})

# COMMAND ----------

sio.whosmat('data/consumption.mat')

# COMMAND ----------

data_mat = sio.loadmat('data/consumption.mat')['data']
print(data_mat)

# COMMAND ----------

# MAGIC %md
# MAGIC ## JSON <a id="part3sec6"></a>
# MAGIC JSON (which stands for *JavaScript Object Notation*) is a format
# MAGIC with which one can save complex data types such as dictionaries and nested lists by serialization.
# MAGIC It is a secure data format that benefits from inter-operability (data exchange).
# MAGIC
# MAGIC However, Numpy arrays cannot be serialized with JSON.

# COMMAND ----------

import json

with open('data/consumption.json', 'w') as f:
    json.dump(data.tolist(), f)

# COMMAND ----------

with open('data/consumption.json', 'r') as f:
    data_json = np.array(json.load(f))
print(data_json)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pickle <a id="part3sec7"></a>
# MAGIC Akin to JSON, Pickle (and its C version cPickle for Python 2) is a module aimed at serializing (or pickling) and de-serializing (or unpickling) a Python object structure.
# MAGIC However, Pickle is far more powerful than JSON: it can serialize arbitrarily complex Python objects.
# MAGIC Thus, in practice, any Python object can be saved (and then re-loaded) with Pickle.
# MAGIC
# MAGIC However (this is the other side of the coin), **the Pickle module is not secure against erroneous or maliciously constructed data: deserializing pickle data can execute arbitrary harmful code.
# MAGIC Never unpickle data received from an untrusted or unauthenticated source**.

# COMMAND ----------

import pickle as pkl  # import cPickle in Python 2, it is faster than pickle

with open('data/consumption.pkl', 'wb') as f:
    pkl.dump(data, f)

# COMMAND ----------

with open('data/consumption.pkl', 'rb') as f:
    data_pkl = pkl.load(f)
print(data_pkl)

# COMMAND ----------

# MAGIC %md
# MAGIC # Exercises <a id="part4"></a>
# MAGIC ## Exercise 1 <a id="part4sec1"></a>
# MAGIC Produce the following array:
# MAGIC
# MAGIC     [[ 0  4  8 12 16]
# MAGIC      [ 1  5  9 13 17]
# MAGIC      [ 2  6 10 14 18]
# MAGIC      [ 3  7 11 15 19]]
# MAGIC
# MAGIC Standardize this array, namely do such that the mean of each column is $0$ and the standard deviation is $1$.

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 2 <a id="part4sec2"></a>
# MAGIC Plot the [probability density functions](https://en.wikipedia.org/wiki/Chi-squared_distribution) of $\chi^2$ with parameters $k \in \{1, 2, \dots, 5\}$.
# MAGIC

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 3 <a id="part4sec3"></a>
# MAGIC Let $A$ be a matrix and $b$ be a vector defined by:
# MAGIC
# MAGIC     V = np.random.randn(5, 5)
# MAGIC     A = V + V.T
# MAGIC     b = np.random.rand(5)
# MAGIC
# MAGIC Solve the linear system $Ax = b$ with two different methods.
# MAGIC

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 4 <a id="part4sec4"></a>
# MAGIC Build a symmetric positive semidefinite matrix $H$ of size 5 x 5, a vector $b$ of size 5 and a scalar value $c$.
# MAGIC Compute a minimizer of $x \mapsto \frac 12 x^\top H x + b^\top x + c$.
# MAGIC Compute the minimum of this function.
# MAGIC

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 5 <a id="part4sec5"></a>
# MAGIC Build a symmetric positive semidefinite matrix $X$ of size 5 x 5.
# MAGIC Implement [power iteration](https://en.wikipedia.org/wiki/Power_iteration).
# MAGIC Compute the [Rayleigh quotient](https://en.wikipedia.org/wiki/Rayleigh_quotient) of the resulting vector regarding the matrix $X$.
# MAGIC Rediscover the result with a single Numpy routine.
# MAGIC

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC ## Exercise 6 <a id="part4sec6"></a>
# MAGIC Dowload [this data file](http://www.lpsm.paris/pageperso/sangnier/files/pythonM2/Gaussian_sample.mat).
# MAGIC The sample in this file is assumed to be Gaussian iid.
# MAGIC Compute the negative log-likelihood function associated to this sample.
# MAGIC Minimize it with a Scipy routine to estimate $\mu$ and $\sigma$.

# COMMAND ----------

# Answer

# COMMAND ----------

# MAGIC %md
# MAGIC # References <a id="part5"></a>
# MAGIC - [Official documentation](https://docs.python.org/3/tutorial/index.html).
# MAGIC - [Numpy and Scipy documentation](http://docs.scipy.org/doc/).
# MAGIC - [Scipy lecture notes](http://www.scipy-lectures.org/index.html).