# Databricks notebook source
pip install quantile-forest

# COMMAND ----------

# MAGIC %run /Tools/library/CFM

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/IC_functions

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/preprocessing

# COMMAND ----------

lib_instance = Cfm()

# COMMAND ----------

#dbutils.widgets.removeAll()

# COMMAND ----------

# ["EncPDV", "DecPDV", "EncUP", "DecUP", "DecPet", "DecTaxAlc", "DecTaxPet", "EncRist", "EncRprox"]

# COMMAND ----------

#Variables widget
groupe = lib_instance.define_widget("groupe") 
quantile_top = float(lib_instance.define_widget('quantile_top'))
quantile_bottom = float(lib_instance.define_widget('quantile_bottom'))

#val_size = float(lib_instance.define_widget("val_size")) #365
cal_size = float(lib_instance.define_widget("cal_size")) # 365

#PAth notebooks
path_notebook_preproc_preprocessing = lib_instance.define_widget("path_notebook_preproc_preprocessing") #'/Notebooks/Shared/Industrialisation/PrepocFolder/Preprocessing'


# COMMAND ----------

#import libraries
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from quantile_forest import RandomForestQuantileRegressor
from lightgbm import LGBMRegressor
import math
import copy
from datetime import timedelta
from jours_feries_france import JoursFeries
import warnings
from sklearn import preprocessing
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer
from itertools import zip_longest
warnings.filterwarnings("ignore")

# COMMAND ----------

alphas = [quantile_bottom,quantile_top] #quantiles

# COMMAND ----------

#/Notebooks/Shared/Industrialisation/PrepocFolder/Preprocessing

# COMMAND ----------

dataloader = Dataloader(path_notebook_preproc_preprocessing = path_notebook_preproc_preprocessing) #load dataloader
df_train, df_predict = dataloader.load_train_predict(groupe = groupe) #load data

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/preprocessing

# COMMAND ----------

 preproc = Preprocessing(groupe = groupe)
 df_train,df_predict = preproc.preproc(df_train,df_predict) #preprocessing ( add label column depending on the groupe)
 labels_str = preproc.labels_str

# COMMAND ----------

# MAGIC %md
# MAGIC ### Predict

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/IC_functions

# COMMAND ----------

#gridsearch_parameters for gradient boosting

param_grid_gb = {'n_estimators': [1000,1500],
                'learning_rate' : [0.001,0.005],
                  'max_depth' : [3,5]
                }

#gridsearch_parameters for lgbm
param_grid_lgbm = {'n_estimators': [1000,1500],
                  'learning_rate' : [0.01,0.05]
                  }

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/IC_functions

# COMMAND ----------

ci = Conformal_Inference_qrf(alphas = [0.01,0.99], cal_size = 50, mode = "test") #initialisation
ci.fit(df_train) # fit and gridsearch
pred_down, pred_up, pred_median = ci.asymetric_conformal_IC(df_predict, plot = True) #prediction

# COMMAND ----------

ci.other_quantiles(alphas=[0.1,0.99],plot = True)

# COMMAND ----------

a = np.delete(ci.dico_temp[0]["pred_median_predict"],0)

# COMMAND ----------

a

# COMMAND ----------

ci.dico[0]["model"].fit(df_train)

# COMMAND ----------

ci.dico[0]["model"].predict(df_predict)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Test

# COMMAND ----------

groupes = ["DecPDV","EncPDV",  "DecUP", "EncUP",  "DecPet", "DecTaxAlc", "DecTaxPet", "EncRist", "EncRprox"]

# COMMAND ----------

dataloader = Dataloader(path_notebook_preproc_preprocessing = path_notebook_preproc_preprocessing)
df_train_set,df_predict_set = dataloader.load_train_predict_set(groupes = groupes)

# COMMAND ----------

for groupe,df_train in zip(groupes,df_train_set):
  preproc = Preprocessing(groupe = groupe)
  df = preproc.preproc(df_train)
  print(df.columns)

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/preprocessing

# COMMAND ----------



# COMMAND ----------

preproc = Preprocessing(groupe = groupe)
df = preproc.preproc(df_train)
print(df)

# COMMAND ----------

print(df_train)

# COMMAND ----------

for groupe,df in zip(groupes, df_train_set):
  print(groupe)
  preproc=Preprocessing(groupe = groupe)
  df_train = preproc.preproc(df)
  print(df_train.columns)

# COMMAND ----------

# DBTITLE 1,normal 
for groupe,df_train,df_predict in zip_longest(groupes,df_train_set,df_predict_set):
  #dataloader = Dataloader(path_notebook_preproc_preprocessing = path_notebook_preproc_preprocessing)
  #df_train, df_predict = dataloader.load_train_predict(groupe = groupe)
  print(groupe)

  preproc = Preprocessing(groupe = groupe)
  df_train,df_predict = preproc.preproc(df_train,df_predict)

  ci = Conformal_Inference_qrf(alphas = [0.05,0.95], cal_size = 50, mode = "test") #initialisation
  ci.fit(df_train) # fit and gridsearch
  pred_down, pred_up, pred_median = ci.asymetric_conformal_IC(df_predict, plot = True) #prediction

# COMMAND ----------

param_grid_lgbm = {'n_estimators': [1000,2000],
                                    'learning_rate' : [0.1,0.05,0.5]
                        }

param_grid_gb = {'n_estimators': [1000,2000],
                                      'learning_rate' : [0.01,0.05,0.5],
                                      'max_depth' : [3,5,10]
                          }     

# COMMAND ----------

#test by models 

mqloss_scorer_up = make_scorer(mqloss, alpha=0.90)
mqloss_scorer_down = make_scorer(mqloss, alpha=0.05)
mqloss_scorer_median = make_scorer(mqloss, alpha=0.5)

for df_train in df_train_set :
  X = df_train.drop(["Valeur"],axis = 1)
  y = df_train["Valeur"]
  X_train,X_test,y_train,y_test = train_test_split(X,y,test_size = 0.3, shuffle = False)
  index_train = X_train["DT_VALR"]
  index_test = X_test["DT_VALR"]
  X_train = X_train.drop(["DT_VALR"],axis = 1) 
  X_test = X_test.drop(["DT_VALR"],axis = 1) 

  efficience_gb = []
  efficience_lgbm = []
  error_gb = []
  error_lgbm = []

  GB_down = GridSearchCV(
                          estimator=GradientBoostingRegressor(loss="quantile", alpha=alphas[0]),
                          param_grid=param_grid_gb,
                          scoring=mqloss_scorer_down,
                          cv=3,
                          n_jobs=-1,
                          verbose=1
    )
  pred_gb_down = np.array(GB_down.fit(X_train, y_train).best_estimator_.predict(X_test))
  print("GB_down.best_params = ", GB_down.best_params_)

  print("GridSearchCV Gradient_boosting up")
  GB_up = GridSearchCV(
                        estimator=GradientBoostingRegressor(loss="quantile", alpha=alphas[1]),
                        param_grid=param_grid_gb,
                        scoring=mqloss_scorer_up,
                        cv=3,
                        n_jobs=-1,
                        verbose=1
  )
  pred_gb_up = np.array(GB_up.fit(X_train, y_train).best_estimator_.predict(X_test))
  print("GB_up.best_params = ", GB_up.best_params_)

  error_gb.append((np.sum(np.array(y_test)<pred_gb_down) + np.sum(np.array(y_test)>pred_gb_up))/len(np.array(y_test)))


  
  #LGBM gridsearch
  print("GridSearchCV LGBM down")
  LGBM_down = GridSearchCV(
                        estimator=LGBMRegressor(alpha=alphas[0],  objective='quantile'),
                        param_grid=param_grid_lgbm,
                        scoring=mqloss_scorer_down,
                        cv=3,
                        n_jobs=-1,
                        verbose=1
  )
  pred_lgbm_down = np.array(LGBM_down.fit(X_train, y_train).best_estimator_.predict(X_test))
  print("LGBM_down.best_params = ", LGBM_down.best_params_)

  print("GridSearchCV LGBM up")
  LGBM_up = GridSearchCV(
                        estimator=LGBMRegressor(alpha=alphas[1],  objective='quantile'),
                        param_grid=param_grid_lgbm,
                        scoring=mqloss_scorer_up,
                        cv=3,
                        n_jobs=-1,
                        verbose=1
  )
  pred_lgbm_up = np.array(LGBM_up.fit(X_train, y_train).best_estimator_.predict(X_test))
  print("LGBM_up.best_params = ", LGBM_up.best_params_)
  
  error_lgbm.append((np.sum(np.array(y_test)<pred_lgbm_down) + np.sum(np.array(y_test)>pred_lgbm_up))/len(np.array(y_test)))
  efficience_gb.append(integral_score(pred_gb_up,pred_gb_down))
  efficience_lgbm.append(integral_score(pred_lgbm_up,pred_lgbm_down))

  fig = go.Figure()
  fig.add_trace(go.Scatter(x=index_test, y=y_test,
                mode='lines',
                name=f'y_true',
                line=dict(
                    color='rgb(0,0, 256)',
                    width=1),
                showlegend = True))
  
  fig.add_trace(go.Scatter(x=index_test, y=pred_gb_up,
                  mode='lines',
                  name=f'q_{alphas[1]}',
                  line=dict(
                      color='rgb(0, 256, 0)',
                      width=0),
                  showlegend = False))
  
  fig.add_trace(go.Scatter(x=index_test, y=pred_gb_down,
                  mode='lines',
                  name=f'{int(np.round(100*(alphas[1]-alphas[0])))}% Confidence Interval',
                  line=dict(
                      color='rgb(0, 256, 0)',
                      width=0),
                  fill='tonexty',
                  fillcolor='rgba(0,176,246,0.2)',
                  line_color='rgba(255,255,255,0)'))
  fig.update_traces(mode='lines')
  fig.update_layout(title = f"Test : {1-error_gb[-1]}% gradient boosting {groupe}")                      
  fig.show()

  fig = go.Figure()
  fig.add_trace(go.Scatter(x=index_test, y=y_test,
                mode='lines',
                name=f'y_true',
                line=dict(
                    color='rgb(0,0, 256)',
                    width=1),
                showlegend = True))
          
  fig.add_trace(go.Scatter(x=index_test, y=pred_lgbm_up,
                  mode='lines',
                  name=f'q_{alphas[1]}',
                  line=dict(
                      color='rgb(0, 256, 0)',
                      width=0),
                  showlegend = False))

  fig.add_trace(go.Scatter(x=index_test, y=pred_lgbm_down,
                  mode='lines',
                  name=f'{int(np.round(100*(alphas[1]-alphas[0])))}% Confidence Interval',
                  line=dict(
                      color='rgb(0, 256, 0)',
                      width=0),
                  fill='tonexty',
                  fillcolor='rgba(0,176,246,0.2)',
                  line_color='rgba(255,255,255,0)'))
  fig.update_traces(mode='lines')
  fig.update_layout(title = f"Test : {1-error_lgbm[-1]}% LGBM {groupe}")                      
  fig.show()

# COMMAND ----------

np.sum(np.array(y_test)<pred_gb_down) + np.sum(np.array(y_test)>pred_gb_up)/len(np.array(y_test))