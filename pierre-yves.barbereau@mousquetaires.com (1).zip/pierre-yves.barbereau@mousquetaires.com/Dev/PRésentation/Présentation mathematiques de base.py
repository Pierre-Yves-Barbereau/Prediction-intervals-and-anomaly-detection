# Databricks notebook source
import numpy as np
import plotly.express as px
import pandas as pd
x_exp = np.random.exponential(10,size = 100)
y_exp = 10-np.random.exponential(3,size = 100)
x_exp_mean = np.mean(x_exp)
y_exp_mean = np.mean(y_exp)
x_exp_mean = x_exp.mean()
y_exp_mean = y_exp_mean.mean()
df = pd.DataFrame({"x": x_exp, "y": y_exp})
df["color"] = "Set"
df = df.append({"x": x_exp_mean, "y": y_exp_mean,"color" : 'mean'}, ignore_index=True)
#fig = px.scatter(x_exp, y_exp)
fig = px.scatter(df,x = "x", y =  "y", color = 'color',symbol="color",title="Moyenne d'un échantillon exponentiel")
fig.show()

# COMMAND ----------

x_exp_median = np.median(x_exp)
y_exp_median = np.median(y_exp)
df = df.append({"x" : x_exp_median,"y":y_exp_median,"color" : "median"}, ignore_index=True)
fig = px.scatter(df,x = "x", y =  "y", color = 'color',symbol="color",title="Moyenne et médiane d'un échantillon exponentiel")
fig.show()

# COMMAND ----------



# COMMAND ----------

import plotly.figure_factory as ff
import numpy as np
n = 100

# Add histogram data
x1 = np.random.normal(0,1,size = n)
x2 = np.random.normal(0,2,size = n)
if 0:
  x1 = np.random.exponential(1,size = n)
  x2 = np.random.exponential(2,size = n)

# Group data together
hist_data = [x1, x2]
group_labels = ['var = 1', 'var = 4']

# Create distplot with custom bin_size
fig = ff.create_distplot(hist_data, group_labels, bin_size=.2)
fig.update_layout(title_text='Deux échantillons de variance 1 et 4')
if 1 :

    fig.add_vline(x=np.quantile(x1,0.05), 
                  line_width=3,
                  line_color="blue",
                  annotation_text="0.05 Q",
                  annotation_font_size=10,
                  annotation_font_color="blue")
    fig.add_vline(x=np.quantile(x1,0.95), 
                  line_width=3,
                  line_color="blue",
                  annotation_text="0.95 Q",
                  annotation_font_size=10,
                  annotation_font_color="blue")

    fig.add_vline(x=np.quantile(x2,0.05), 
                  line_width=3,
                  line_color="orange",
                  annotation_text="0.05 Q",
                  annotation_font_size=10,
                  annotation_font_color="orange")
    fig.add_vline(x=np.quantile(x2,0.95), 
                  line_width=3,
                  line_color="orange",
                  annotation_text="0.95 Q",
                  annotation_font_size=10,
                  annotation_font_color="orange")        

    fig.add_vline(x=np.quantile(x1,0.5), 
                  line_width=3,
                  line_color="blue",
                  annotation_text="Médiane",
                  annotation_font_size=10,
                  annotation_font_color="blue") 
              
fig.show()

# COMMAND ----------

df3 = pd.DataFrame({"x": x_exp, "y": y_exp})
df3["color"] = "exp(3)"
df4 = pd.DataFrame({"x": y_exp})
df4["color"] = "10-exp(3)"
df5 = pd.concat([df3,df4],axis = 0)
fig = px.box(df5,x = "color", y =  "x", color = 'color', points="all",title="Boxplots de deux échantillons exponentiels")
fig.show()

# COMMAND ----------



# COMMAND ----------

