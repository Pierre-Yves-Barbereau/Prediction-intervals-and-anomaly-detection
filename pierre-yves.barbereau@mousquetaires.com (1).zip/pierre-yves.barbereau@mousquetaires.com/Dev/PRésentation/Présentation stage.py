# Databricks notebook source


# COMMAND ----------

# MAGIC %run /Tools/library/CFM

# COMMAND ----------

lib = Cfm()

# COMMAND ----------

DecPDV = lib.get_only_groupe_from_jointure("DecPDV")

# COMMAND ----------

display(DecPDV)

# COMMAND ----------

!pip install RISE

# COMMAND ----------

f"/mnt/datalake_cfm_dd91381fs01/brutes/exploratoire/Stage_Intervalle_Confiance/prediction/Prod/**"

# COMMAND ----------

import numpy as np
import matplotlib.pyplot as plt

N = 100000

data = np.random.randn(N)

# COMMAND ----------

hx, hy, _ = plt.hist(data, bins=50, normed=True,color="lightblue")

plt.ylim(0.0,max(hx)+0.05)
plt.title('Generate random numbers \n from a standard normal distribution with python')
plt.grid()

plt.savefig("cumulative_density_distribution_01.png", bbox_inches='tight')

#plt.show()
plt.close()


# COMMAND ----------

