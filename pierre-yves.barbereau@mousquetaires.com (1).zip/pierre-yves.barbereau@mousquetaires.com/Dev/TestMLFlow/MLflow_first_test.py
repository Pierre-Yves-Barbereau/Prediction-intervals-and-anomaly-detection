# Databricks notebook source
import mlflow
import databricks.automl_runtime

# Use MLFlow to track experiments
mlflow.set_experiment("/Users/pierre-yves.barbereau@mousquetaires.com/TestMLFlow/MLflow_first_test")


# COMMAND ----------

#%sh mv /local_disk0/spark-35d3f511-ca4a-4753-a33d-1340664ef4b0/userFiles-985caefe-6f29-4009-8aee-3680df248e43/titanic_dataset.csv /dbfs/mnt/datalake_cfm_dd91381fs01/brutes/exploratoire/titanic_dataset

# COMMAND ----------

format ="csv"
header= "true"
inferSchema = "true"
delimiter=","
path = '/mnt/datalake_cfm_dd91381fs01/brutes/exploratoire/titanic_dataset/titanic_dataset.csv'

df_loaded = spark.read.format(format).option("header", header).option("inferSchema", inferSchema).option("delimiter", delimiter).load(path)
display(df_loaded)

# COMMAND ----------

df_loaded.show()

# COMMAND ----------

df_loaded.columns

# COMMAND ----------

df_dropped = df_loaded.drop("PassengerId","Name","SibSp","Cabin","Ticket").na.drop()
display(df_dropped)

# COMMAND ----------

if 0:
  from pyspark.ml.feature import StringIndexer
  categorical_cols = [field for (field, dataType) in df_dropped.dtypes if dataType == "string"]
  index_output_cols = [x + "_Labelised" for x in categorical_cols]
  string_indexer = StringIndexer(inputCols=categorical_cols, outputCols=index_output_cols, handleInvalid="skip")
  df_labelised = string_indexer.fit(df_labelised).transform(df_labelised)
  df_labelised = df_labelised.select(['Pclass','Age','Fare','Sex_Labelised','Embarked_labelised','Survived'])
  display(df_labelised)


# COMMAND ----------

train_df, test_df = df_dropped.randomSplit([.8, .2], seed=42)


# COMMAND ----------

from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import StringIndexer

categorical_cols = [field for (field, dataType) in df_dropped.dtypes if dataType == "string"]
index_output_cols = [x + "_Labelised" for x in categorical_cols]
string_indexer = StringIndexer(inputCols=categorical_cols, outputCols=index_output_cols, handleInvalid="skip")
numeric_cols = [field for (field, dataType) in train_df.dtypes if ((dataType == ("double" or "int")) & (field != "Survived"))]
assembler_inputs = index_output_cols + numeric_cols
vec_assembler = VectorAssembler(inputCols=assembler_inputs, outputCol="features")


# COMMAND ----------

from pyspark.ml.regression import RandomForestRegressor
from pyspark.ml.evaluation import RegressionEvaluator
from pyspark.ml.tuning import CrossValidator
from pyspark.ml.tuning import ParamGridBuilder
from pyspark.ml import Pipeline


model = RandomForestRegressor(labelCol="Survived", maxBins=40)

evaluator = RegressionEvaluator(labelCol="Survived", predictionCol="prediction")

cv = CrossValidator(estimator=model, evaluator=evaluator, estimatorParamMaps=param_grid, 
                    numFolds=3, seed=42)

param_grid = (ParamGridBuilder()
              .addGrid(rf.maxDepth, [2, 5])
              .addGrid(rf.numTrees, [5, 10])
              .build())

cv = CrossValidator(estimator=model, evaluator=evaluator, estimatorParamMaps=param_grid, 
                    numFolds=3, seed=42)

stages_with_cv = [string_indexer, vec_assembler, cv]
pipeline = Pipeline(stages=stages_with_cv)
pipeline_model = pipeline.fit(train_df)

# COMMAND ----------

print(rf.explainParams())

# COMMAND ----------

pred_df = pipeline_model.transform(test_df)
rmse = evaluator.evaluate(pred_df)
r2 = evaluator.setMetricName("r2").evaluate(pred_df)
print(f"RMSE is {rmse}")
print(f"R2 is {r2}")

# COMMAND ----------

pred_df

# COMMAND ----------

