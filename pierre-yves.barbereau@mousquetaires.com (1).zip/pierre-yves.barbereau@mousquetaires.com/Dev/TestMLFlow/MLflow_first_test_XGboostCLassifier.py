# Databricks notebook source
import mlflow
import databricks.automl_runtime

# Use MLFlow to track experiments
mlflow.set_experiment("/Users/pierre-yves.barbereau@mousquetaires.com/TestMLFlow/MLflow_first_test_XGboost")


# COMMAND ----------

#%sh mv /local_disk0/spark-35d3f511-ca4a-4753-a33d-1340664ef4b0/userFiles-985caefe-6f29-4009-8aee-3680df248e43/titanic_dataset.csv /dbfs/mnt/datalake_cfm_dd91381fs01/brutes/exploratoire/titanic_dataset

# COMMAND ----------

format ="csv"
header= "true"
inferSchema = "true"
delimiter=","
path = '/mnt/datalake_cfm_dd91381fs01/brutes/exploratoire/titanic_dataset/titanic_dataset.csv'

df_loaded = spark.read.format(format).option("header", header).option("inferSchema", inferSchema).option("delimiter", delimiter).load(path)
display(df_loaded)

# COMMAND ----------

#Features selection and drop nan
df_dropped = df_loaded.drop("PassengerId","Name","SibSp","Cabin","Ticket","Parch").na.drop() 
display(df_dropped)

# COMMAND ----------

# train test split
train_df, test_df = df_dropped.randomSplit([.8, .2], seed=42)


# COMMAND ----------



# COMMAND ----------

from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import StringIndexer

# labelling of categorical columns
categorical_cols = [field for (field, dataType) in df_dropped.dtypes if dataType == "string"]
index_output_cols = [x + "_Labelised" for x in categorical_cols]
string_indexer = StringIndexer(inputCols=categorical_cols, outputCols=index_output_cols, handleInvalid="skip")
numeric_cols = [field for (field, dataType) in train_df.dtypes if ((dataType == ("double" or "int")) & (field != "Survived"))]
# Vector assembler
assembler_inputs = index_output_cols + numeric_cols
vec_assembler = VectorAssembler(inputCols=assembler_inputs, outputCol="features")




# COMMAND ----------

from sparkdl.xgboost import XgboostClassifier
from pyspark.ml.evaluation import MulticlassClassificationEvaluator
from pyspark.ml.tuning import CrossValidator
from pyspark.ml.tuning import ParamGridBuilder
from pyspark.ml import Pipeline


model = XgboostClassifier(labelCol="Survived",random_state = 42,missing = 0)

evaluator = MulticlassClassificationEvaluator(labelCol="Survived", predictionCol="prediction")

param_grid = (ParamGridBuilder()
              .addGrid(model.n_estimators, [100, 500])
              .addGrid(model.learning_rate, [0.5, 0.01])
              .addGrid(model.max_depth, [4,5,6])
              .build())

cv = CrossValidator(estimator=model, evaluator=evaluator, estimatorParamMaps=param_grid, 
                    numFolds=3, seed=42)

stages_with_cv = [string_indexer, vec_assembler, cv]
pipeline = Pipeline(stages=stages_with_cv)
pipeline_model = pipeline.fit(train_df)



# COMMAND ----------

display(train_df)

# COMMAND ----------

print(model.explainParams())

# COMMAND ----------

from pyspark.sql.functions import round, col
pred_df = pipeline_model.transform(test_df)
#pred_df = pred_df.withColumn("prediction", round("prediction"))
rmse = evaluator.evaluate(pred_df)
predictionAndTarget = pred_df.select("prediction","Survived")
acc = evaluator.evaluate(predictionAndTarget, {evaluator.metricName: "accuracy"})
print(f"accuracy is : {acc}")

# COMMAND ----------

display(pred_df)

# COMMAND ----------

