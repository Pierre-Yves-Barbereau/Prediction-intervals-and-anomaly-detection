# Databricks notebook source
# MAGIC %run /Tools/library/CFM

# COMMAND ----------

lib_instance = Cfm()

# COMMAND ----------

from IPython.display import HTML

# COMMAND ----------

import random
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.autograd import Variable
import warnings

warnings.filterwarnings('ignore')
%matplotlib inline

import logging
handler=logging.basicConfig(level=logging.INFO)
lgr = logging.getLogger(__name__)

#Utilisation des GPUs
#use_cuda = torch.cuda.is_available()
use_cuda = False

torch.manual_seed(0)

FloatTensor = torch.cuda.FloatTensor if use_cuda else torch.FloatTensor
LongTensor = torch.cuda.LongTensor if use_cuda else torch.LongTensor
Tensor = FloatTensor

from sklearn import preprocessing
import sklearn.metrics
import sklearn.metrics.pairwise
import matplotlib.pyplot as plt
def recurrence_plot(s, eps=None, steps=None):
    if eps==None: eps=0.1
    if steps==None: steps=10
    d = sklearn.metrics.pairwise.pairwise_distances(s)
    d = np.floor(d / eps)
    d[d > steps] = steps
    return d

# COMMAND ----------

# MAGIC %%html
# MAGIC <script>
# MAGIC code_show=true; 
# MAGIC function code_toggle() {
# MAGIC  if (code_show){
# MAGIC  $('div.input').hide();
# MAGIC  } else {
# MAGIC  $('div.input').show();
# MAGIC  }
# MAGIC  code_show = !code_show
# MAGIC } 
# MAGIC $( document ).ready(code_toggle);
# MAGIC </script>
# MAGIC Le code Python est caché pour une lecture plus facile. Pour l'afficher cliquez  <a href="javascript:code_toggle()">ici</a>

# COMMAND ----------

# MAGIC %md
# MAGIC L'objectif de ce notebook est de détecter les anomalies dans des séries temporelles transformées en images à l'aide d'un auto-encodeur convolutif. Si vous ne connaissez pas le principe de l'auto-encodeur ou son utilisation sur les séries temporelles, je vous invite à aller voir le notebook : AD With Simple AE

# COMMAND ----------

# MAGIC %md
# MAGIC ## Sommaire
# MAGIC 1. [Transformons notre problème en un problème d'image](#Image)
# MAGIC 2. [L'auto-encodeur convolutif](#CAE)
# MAGIC 3. [Application d'un autoencodeur convolutif sur des représentations graphiques de séries complexes](#recurrence_plot)
# MAGIC 4. [Conclusion](#Conclusion)

# COMMAND ----------

# MAGIC %md
# MAGIC # Transformons notre problème en un problème d'image <a name="Image"></a>

# COMMAND ----------

# MAGIC %md
# MAGIC Essayons de transformer cette série temporelle afin de pouvoir créer une "texture" représentant les patterns.

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/preprocessing

# COMMAND ----------

dataloader = Dataloader(path_notebook_preproc_preprocessing = "/Notebooks/Shared/Industrialisation/PrepocFolder/Preprocessing")
df_train = dataloader.load_train(groupe = "DecPDV")

# COMMAND ----------

df_train

# COMMAND ----------

!pip install pandas_datareader
import pandas_datareader.data as web
from datetime import datetime

start = datetime(1960, 1, 1)
end = datetime(2020, 4, 30)

#df = web.DataReader(['sp500'], 'fred', start, end).fillna(method = "ffill")
df = df_train["DT_VALR","Valeur"]
plt.plot(df)

# COMMAND ----------

print(df.shape)

# COMMAND ----------

print(df[1:5].values)

# COMMAND ----------

# MAGIC %md
# MAGIC Nous commençons par normaliser la donnée 

# COMMAND ----------

x = df.values 
min_max_scaler = preprocessing.MinMaxScaler()
#x_scaled = min_max_scaler.fit_transform(x)
df_normalize = pd.DataFrame(x).fillna(method='ffill')

# COMMAND ----------

# MAGIC %md
# MAGIC Pour générer les données d'entraînement, on va appliquer sur la série une fenêtre glissante d'une taille limitée mais permettant quand même de capter les caractéristiques de la série.
# MAGIC
# MAGIC **En pratique la taille de la fenêtre glissante est égale à la taille minimale d'un pattern.**
# MAGIC
# MAGIC Prenons une taille de fenêtre de 2000 et un pas de 25

# COMMAND ----------

n = 2000 
k = 25
list_df = np.array([df_normalize[i:i+n].values.tolist() for i in range(0,df_normalize.shape[0]-n,k)] ,  dtype=np.float64)

# COMMAND ----------

# MAGIC %md
# MAGIC En prenant l'écart absolu de chaque paires de valeurs de la série temporelle, nous obtenons une répresenation 2D de celle-ci. (Cette technique est appelé "Recurrence plot") 
# MAGIC
# MAGIC Ps : Plus la valeur est grande , plus la couleur est claire. L'"image" obtenu est biensur une symétrie puisque la différence entre un point x1 et x2 est équivalente à la différence entre le point x2 et x1.

# COMMAND ----------

# MAGIC %md
# MAGIC Voici une série temporelle et l'image la représentante

# COMMAND ----------

fig = plt.figure(figsize=(8,8))
ax = fig.add_subplot(2, 1, 1)
ax.axis('off')
ax.imshow(recurrence_plot(df_normalize))
ax = fig.add_subplot(2, 1, 2)
ax.axis('off')
ax.plot(df_normalize)

# COMMAND ----------

# MAGIC %md
# MAGIC Cette façon de visualiser les séries temporelles est intéressante car nous savons déjà que les réseaux de neurones convolutifs sur les images sont extrémement fort pour détecter les "textures" et c'est exactement ce en quoi nous transformons nos time-series.

# COMMAND ----------

# MAGIC %md
# MAGIC # L'autoencodeur convolutif <a name="CAE"></a>

# COMMAND ----------

# MAGIC %md
# MAGIC L'autoencodeur convolutif est un autoencodeur avec des couches convolutives. Les réseaux de neurones convolutifs visent à limiter le nombre d'entrées tout en conservant la forte corrélation « spatialement locale » des images.
# MAGIC Une architecture de réseau de neurones convolutifs est formée par un empilement de couches de traitement :
# MAGIC * la couche de convolution (CONV) qui traite les données d'un champ récepteur 
# MAGIC * la couche de pooling (POOL), qui permet de compresser l'information en réduisant la taille de l'image intermédiaire (souvent par sous-échantillonnage) 
# MAGIC
# MAGIC Pour un autoencodeur nous aurons également des couches de déconvolution pour remonter progressivement vers la résolution de départ. 

# COMMAND ----------

# MAGIC %md
# MAGIC # Application d'un autoencodeur convolutif sur des représentations graphiques de séries complexes <a name="recurrence_plot"></a>

# COMMAND ----------



df_train = df[1:1500].values
plt.plot(df_train,label="Apprentissage")

df_test= df[1500:1844].values
plt.plot(df_test,label="Test")

plt.legend()
plt.suptitle("Découpage de la série temporelle")
plt.show()

# COMMAND ----------

# MAGIC %md
# MAGIC On normalise 

# COMMAND ----------

x = df_train
min_max_scaler = preprocessing.MinMaxScaler()
#x_scaled = min_max_scaler.fit_transform(x)
df_normalize = pd.DataFrame(x)

# COMMAND ----------

# MAGIC %md
# MAGIC On découpe en fenêtre de temps de taille 900 et de pas 5. 

# COMMAND ----------

n = 900
k = 5
list_df = np.array([df_normalize[i:i+n].values.tolist() for i in range(0,df_normalize.shape[0]-n,k)] ,  dtype=np.float64)

# COMMAND ----------

# MAGIC %md
# MAGIC Transformons nos fenêtres en image 

# COMMAND ----------

import sklearn.metrics

filenames = []

j=0
for i in list_df: 
    j+=1
    fig = plt.figure(figsize=(8,8))
    ax = fig.add_subplot(1, 1, 1)
    ax.axis('off')
    ax.imshow(recurrence_plot(i))
    #fig.savefig('Data/img/img_'+str(j)+'.png')   # save the figure to file
    #filenames.append('Data/img/img_'+str(j)+'.png')
    plt.close(fig)


# COMMAND ----------

# MAGIC %md
# MAGIC Notre série temporelle transformée

# COMMAND ----------

#Image(filename="Data/img.gif")

# COMMAND ----------

# MAGIC %md
# MAGIC Sélectionnons les images pour l'entrainement

# COMMAND ----------

from skimage.io import imread 
from skimage.transform import resize
from tqdm import tqdm

train_img = []
for img_name in tqdm(range(100,700)):
    # defining the image path
    image_path = 'Data/img/img_'+ str(img_name) + '.png'
    # reading the image
    img = imread(image_path, as_gray=True)
    img = resize(img, (216, 224))
    # converting the type of pixel to float 32
    img = img.astype('float32')
    # normalizing the pixel values
    img /= 255.0
    # appending the image into the list
    train_img.append(img)

# converting the list to numpy array
train_x = np.array(train_img)

train_x.shape

# COMMAND ----------

# MAGIC %md
# MAGIC Sélectionnons les images pour le test

# COMMAND ----------

test_img = []
for img_name in tqdm(range(list_df.shape[0]-1000,list_df.shape[0])):
    # defining the image path
    image_path = 'Data/img/img_'+ str(img_name) + '.png'
    # reading the image
    img = imread(image_path, as_gray=True)
    img = resize(img, (216, 224))
    # converting the type of pixel to float 32
    img = img.astype('float32')
    # normalizing the pixel values
    img /= 255.0
    # appending the image into the list
    test_img.append(img)

# converting the list to numpy array
test_x = np.array(test_img)

test_x.shape

# COMMAND ----------

# MAGIC %md
# MAGIC Exemple d'images : 

# COMMAND ----------

fig, axes = plt.subplots(nrows=2, ncols=2)

ax = axes.ravel()

ax[0].imshow(train_img[15], cmap='gray')
ax[0].set_title("Train image")

ax[1].imshow(train_img[150], cmap='gray')
ax[1].set_title("Train image")

ax[2].imshow(test_img[100], cmap='gray')
ax[2].set_title("Test image")

ax[3].imshow(test_img[200], cmap='gray')
ax[3].set_title("Test image")


plt.tight_layout()
plt.show()

# COMMAND ----------

train_x = train_x.reshape(train_x.shape[0], 1, 216, 224)
train_x = torch.from_numpy(train_x)

test_x = test_x.reshape(test_x.shape[0], 1, 216, 224)
test_x = torch.from_numpy(test_x)

# COMMAND ----------

# MAGIC %md
# MAGIC Définissons l'auto-encodeur convolutif en Pytorch

# COMMAND ----------

import torch.nn as nn
import torch.nn.functional as F

# define the NN architecture
class ConvAutoencoder(nn.Module):
    def __init__(self):
        super(ConvAutoencoder, self).__init__()
        ## encoder layers ##
        # conv layer (depth from 1 --> 16), 3x3 kernels
        #self.conv1 = nn.Conv2d(4, 16, 3, padding=1)  
        self.conv1 = nn.Conv2d(1, 16, 3, padding=1) #gray 
        # conv layer (depth from 16 --> 4), 3x3 kernels
        self.conv2 = nn.Conv2d(16, 4, 3, padding=1)
        # pooling layer to reduce x-y dims by two; kernel and stride of 2
        self.pool = nn.MaxPool2d(2, 2)
        
        ## decoder layers ##
        ## a kernel of 2 and a stride of 2 will increase the spatial dims by 2
        self.t_conv1 = nn.ConvTranspose2d(4, 16, 2, stride=2)
        #self.t_conv2 = nn.ConvTranspose2d(16, 4, 2, stride=2)
        self.t_conv2 = nn.ConvTranspose2d(16, 1, 2, stride=2)#gray


    def forward(self, x):
        ## encode ##
        # add hidden layers with relu activation function
        # and maxpooling after
        x = F.relu(self.conv1(x))
        x = self.pool(x)
        # add second hidden layer
        x = F.relu(self.conv2(x))
        x = self.pool(x)  # compressed representation
        
        ## decode ##
        # add transpose conv layers, with relu activation function
        x = F.relu(self.t_conv1(x))
        # output layer (with sigmoid for scaling from 0 to 1)
        x = F.sigmoid(self.t_conv2(x))
                
        return x

# initialize the NN
model = ConvAutoencoder()
print(model)

# COMMAND ----------

optimizer = torch.optim.Adam(model.parameters(), lr=0.005)
# defining the loss function
criterion = nn.MSELoss()
# checking if GPU is available
if torch.cuda.is_available():
    model = model.cuda()
    criterion = criterion.cuda()
    

# COMMAND ----------

# MAGIC %md
# MAGIC La mesure qui nous permet de calculer la performance de l'auto-codeur est l'erreur quadratique moyenne 

# COMMAND ----------

Image(filename="Data/mse.png")

# COMMAND ----------

import torch.utils.data

num_workers = 0
# how many samples per batch to load
batch_size = 2
# prepare data loaders
train_loader = torch.utils.data.DataLoader(train_x, batch_size=batch_size, num_workers=num_workers)
test_loader = torch.utils.data.DataLoader(test_x, batch_size=batch_size, num_workers=num_workers)

# COMMAND ----------

# MAGIC %md
# MAGIC Lançons l'entrainement sur 101 Epochs

# COMMAND ----------

n_epochs = 101

for epoch in range(1, n_epochs+1):
    # monitor training loss
    train_loss = 0.0
    
    ###################
    # train the model #
    ###################
    for data in train_loader:
        # _ stands in for labels, here
        # no need to flatten images
        images = data.cuda()
        # clear the gradients of all optimized variables
        optimizer.zero_grad()
        # forward pass: compute predicted outputs by passing inputs to the model
        outputs = model(images)
        # calculate the loss
        loss = criterion(outputs, images)
        # backward pass: compute gradient of the loss with respect to model parameters
        loss.backward()
        # perform a single optimization step (parameter update)
        optimizer.step()
        # update running training loss
        train_loss += loss.item()*images.size(0)
            
    # print avg training statistics 
    train_loss = train_loss/len(train_loader)
    if(epoch % 10 == 1):
        print('Epoch: {} \tTraining Loss: {:.6f}'.format(
            epoch, 
            train_loss
            ))

# COMMAND ----------

# MAGIC %md
# MAGIC Passons à la partie test 

# COMMAND ----------

dataiter = iter(test_loader)
images= dataiter.next()
output = model(images.cuda())
# prep images for display
images = images.numpy()

# output is resized into a batch of iages
output = output.view(batch_size, 1, 216, 224)
# use detach when it's an output that requires_grad
output = output.detach().cpu().numpy()


fig, axes = plt.subplots(nrows=2, ncols=2, sharex=True, sharey=True, figsize=(50,8))
fig.suptitle("Image Réelle (Haut) / Image reconstruite (Bas)", fontsize=30)
# input images on top row, reconstructions on bottom
for images, row in zip([images, output], axes):
    for img, ax in zip(images, row):
        ax.imshow(np.squeeze(img[0]), cmap='gray')
        ax.get_xaxis().set_visible(False)
        ax.get_yaxis().set_visible(False)
        

# COMMAND ----------

# MAGIC %md
# MAGIC Visualisons l'erreur de reconstruction sur le test par rapport à la période correspondante

# COMMAND ----------

losses = []
images_test = []
for data in test_loader:
        # _ stands in for labels, here
        # no need to flatten images
        images = data.cuda()
        # forward pass: compute predicted outputs by passing inputs to the model
        outputs = model(images)
        # calculate the loss
        losses.append(criterion(outputs, images).item())
        images_test.append(images.view(batch_size, 1, 216,224).detach().cpu().numpy())

# COMMAND ----------

fig = plt.figure(figsize=(8,8))
ax = fig.add_subplot(2, 1, 1)
ax.axis('off')
ax.plot(losses)
ax.set_title('Loss')
ax = fig.add_subplot(2, 1, 2)
ax.axis('off')
ax.plot(df_test[2000:-900])
ax.set_title('Série Temporelle')

# COMMAND ----------

# MAGIC %md
# MAGIC # Conclusion <a name="Conclusion"></a>

# COMMAND ----------

# MAGIC %md
# MAGIC L'auto-encodeur est un modèle puissant qui peut apprendre la texture des images.
# MAGIC
# MAGIC Cependant, un point reste à étudier pour produire une approche robuste et entièrement automatisée à partir d'un auto-encodeur.
# MAGIC
# MAGIC     - un choix automatique et intelligent du seuil d'anomalie.

# COMMAND ----------



# COMMAND ----------

