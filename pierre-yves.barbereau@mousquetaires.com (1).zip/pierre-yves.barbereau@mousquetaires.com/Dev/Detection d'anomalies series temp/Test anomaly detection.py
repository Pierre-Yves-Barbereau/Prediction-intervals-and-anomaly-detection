# Databricks notebook source
import numpy as np
import matplotlib.pyplot as plt
sample = np.random.normal(loc=0.0, scale=1.0, size=10000)
processus = np.cumsum(sample)
plt.plot(processus)

# COMMAND ----------

import random
anomaly_index = sorted(random.sample([i for i in range(10000)],20))

# COMMAND ----------

a_processus = processus
for i in anomaly_index :
  a_processus[i] = processus[i] + np.random.normal(loc=5, scale=5, size=1)

# COMMAND ----------

plt.plot(processus)

# COMMAND ----------

