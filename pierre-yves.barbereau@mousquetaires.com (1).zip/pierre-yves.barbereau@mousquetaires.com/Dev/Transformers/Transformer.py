# Databricks notebook source
import pandas as pd
#Nom Bases
NAME_ADB_BASE_CFM_IC = "IntervalleConfiance"

#Nom table

#Nom des vues à créer
NAME_ADB_VIEW_FLUX_HISTORIQUE = "cfm_flux_historique"
NAME_ADB_VIEW_FLUX_FIN_TRAN = "cfm_fin_tran"

df = spark.sql(f"SELECT * FROM {NAME_ADB_BASE_CFM_IC}.{NAME_ADB_VIEW_FLUX_HISTORIQUE} WHERE descriptionFlux = 'DecPDV' ").toPandas()
lendf = df.shape[0]
pd.to_datetime(df["DT_VALR"])
df.sort_values(by = "DT_VALR")
df.head()

# COMMAND ----------


import torch
target = df["Valeur"]
df2 = pd.DataFrame([])
df2["DT_VALR"] = pd.to_datetime(df["DT_VALR"])
df2["Valeur"] = df["Valeur"]
df2["Jour_de_la_semaine"] = pd.to_datetime(df['DT_VALR']).dt.weekday
df2["Jour"] = pd.to_datetime(df['DT_VALR']).dt.day
df2["Mois"] = pd.to_datetime(df['DT_VALR']).dt.month
df2

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(df2, target,train_size = 0.8,shuffle = False)
xX_test = X_test["DT_VALR"]

X_train = X_train.drop(["DT_VALR"],axis = 1)
X_train = torch.tensor(X_train.drop(["Valeur"],axis = 1).values).float()
X_test = X_test.drop(["DT_VALR"],axis = 1)
X_test = torch.tensor(X_test.drop(["Valeur"],axis = 1).values).float()
y_train = torch.tensor(y_train.values).float()
y_test = torch.tensor(y_test.values).float()

# COMMAND ----------



# COMMAND ----------

import math
import random
import torch.nn as nn

import numpy as np
import time
# set the device we will be using to train the model
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


class DenseQR(nn.Module):
    def __init__(self):
        super(DenseQR,self).__init__()
        self.alpha = 0.95
        self.alpha_high = 0.95
        self.alpha_low = 0.95
        self.input_features=3
        self.output_features=1
        self.mid_features = 256

        self.lrelu = nn.LeakyReLU(0.01)
        self.first = nn.Linear(in_features = self.input_features,out_features = self.mid_features)
        self.mid1 = nn.Linear(in_features = self.mid_features,out_features = self.mid_features)
        self.mid2 = nn.Linear(in_features = self.mid_features,out_features = self.mid_features)
        self.mid3 = nn.Linear(in_features = self.mid_features,out_features = self.mid_features)
        self.mid4 = nn.Linear(in_features = self.mid_features,out_features = self.mid_features)
        self.mid5 = nn.Linear(in_features = self.mid_features,out_features = self.mid_features)
        self.out = nn.Linear(in_features = self.mid_features,out_features = self.output_features)
       
        

    def forward(self, x):

        x = self.first(x)
        x = self.lrelu(x)
        x = self.mid1(x)
        x = self.lrelu(x)
        x = self.mid2(x)
        x = self.lrelu(x)
        x = self.mid3(x)
        x = self.lrelu(x)
        x = self.mid4(x)
        x = self.lrelu(x)
        x = self.mid5(x)
        x = self.lrelu(x)
        x = self.out(x)
        x = self.lrelu(x)

        return x
    


    
    def fit(self, train_input_batch,train_output_batch,test_input_batch,test_output_batch, EPOCHS,opt,gamma = 0.8,sheduler_period = 5):
        startTime = time.time()
        scheduler = torch.optim.lr_scheduler.ExponentialLR(opt, gamma=gamma)
        train_loss_list = []
        test_loss_list = []
#        MAE_test_loss_list = []
        
        #Training loop
        for e in range(0, EPOCHS):
            # loop over the training set
            n = 0
            nmax=train_input_batch.shape[0]/batch_size
            if e%sheduler_period==0:
                scheduler.step()
            
            #bath size split
            for (x,y) in zip(train_input_batch.split(batch_size),train_output_batch.split(batch_size)):

                #training
                
                n=n+1
                
                pred = self.forward(x)
#                print("pred.shape = ",pred.shape)
#                print("y.shape = ",y.shape)
                
                #ùetrics
               
#                MAE_train = torch.abs((y.cuda()-pred)).mean()
#                #
#                ssim_train = -self.ssim(pred,y.cuda())
#                
#                mge_train = self.MGE_loss(pred,y.cuda())
#                
#                lap = self.Laplacian(pred,y)
#                
#                loss = 0.1*mge_train + 0.1*ssim_train + 0.1*lap + MAE_train + 0.1
                loss =((self.alpha-1.0)*(y-pred)*((y-pred)<0)+self.alpha*(y-pred)*((y-pred)>=0)).mean()
                opt.zero_grad()
                loss.backward()
                opt.step()
                train_loss_list.append(loss.item())
                
                
                
                # zero out the gradients, perform the backpropagation step,
                # and update the weights
                
                
#                
#                randint=random.randrange(0,len(test_output_batch.split(batch_size)))    #rend test sample permutation
#                with torch.no_grad():
#                    pred_test=self.forward(test_input_batch.split(batch_size)[randint].cuda())
#                MSE_test=((test_output_batch.split(batch_size)[randint].cuda()-pred_test)**2).mean()
#                train_loss_list.append(MSE_train.item())
#                ssim_test=-ssim(self.forward(test_input_batch.split(batch_size)[randint].cuda()),test_output_batch.split(batch_size)[randint].cuda())
#
#                mge_test=MGE_loss(self.forward(test_input_batch.split(batch_size)[randint].cuda()),test_output_batch.split(batch_size)[randint].cuda(),batch_size=batch_size)
#                #test_loss_list.append(test_loss.item())
#                test_loss=0.1*mge_test+0.1*ssim_test+MSE_test+0.1
#                test_loss_list.append(MSE_test.item())
                
                
                
#                if loss.item()<test_loss.item():
#                    overfitting_counter+=1
#                else:
#                    overfitting_counter=0
#                if overfitting_counter>30:
#                    print("overfitting_breaked")
#                    break
                
                
             
                
                ##test loss##
                randint=random.randrange(0,len(test_output_batch.split(batch_size)))  # select random indice of batch
                with torch.no_grad():
                    pred_test = self.forward(test_input_batch.split(batch_size)[randint])
                test_target = test_output_batch.split(batch_size)[randint]
#                MAE_test = torch.abs((test_target-pred_test)).mean()
#                ssim_test = -self.ssim(pred_test,test_target)
#                mge_test = self.MGE_loss(pred_test,test_target)
#                lap_test = self.Laplacian(pred_test,test_target)
                test_loss=((self.alpha-1.0)*(y-pred)*((y-pred)<0)+self.alpha*(y-pred)*((y-pred)>=0)).mean()
#                test_loss = 0.1*mge_test + 0.1 * ssim_test + 0.1*lap_test + MAE_test + 0.1
                test_loss_list.append(test_loss.item())
#                MAE_test_loss_list.append(MAE_test.item())
                
                endTime = time.time()
                Time=endTime-startTime
                print("\nTraining : time elapsed = ",Time,"/",(Time/(e*nmax+n))*EPOCHS*nmax,"\nEpoch = ",e,"/",EPOCHS, " nbatch = ",n,"/",nmax)
                print("Loss train =",loss.item()/1000000)
#                print("MGE train= ",mge_train.item())
#                print("MSE train= ",MAE_train.item())
#                print("loss test  =",test_loss.item())
#                print("MGE test= ",mge_test.item())
#                print("MSE test= ",MAE_test.item())
               
               
        return train_loss_list,test_loss_list
    
    def predict(self,input_batch):
        
        pred_list = []
        visu_list=[]
        n = 0
        nmax = input_batch.shape[0]
        for im_input in input_batch:
            n = n+1
            print(" predict n = ",n,"/",nmax)
            pred = self.forward(im_input).detach().numpy()
            pred_list.append(pred[0])
            #saving image
            #im_out.save(f"%s/%s-predicted.jpeg" %(dir_name,name))
        return pred_list


# COMMAND ----------

from torch.optim import Adam


model = DenseQR()
#orthogonal_(model.weight.data)
if torch.cuda.is_available():
    model.cuda()


                        ############Training##########


EPOCHS = 500
batch_size = 365
lr = 1e-3
gamma=0.9
sheduler_period = 15


opt = Adam(model.parameters(), lr=lr)                       
print("[INFO] training the network...")
StartTime = time.time()
train_loss_list,test_loss_list=model.fit(X_train,
                                         y_train,
                                         X_test,
                                         y_test,
                                         EPOCHS = EPOCHS,
                                         opt = opt
                                         )

EndTime = time.time()
training_time=EndTime-StartTime
print("Training time = ",training_time)


# COMMAND ----------

predict = model.predict(X_test)

# COMMAND ----------

predict

# COMMAND ----------

import plotly.graph_objects as go
fig = go.Figure()
fig.add_trace(go.Scatter(x=xX_test, y=y_test,
                    mode='lines',
                    name='True'))
fig.add_trace(go.Scatter(x=xX_test, y=predict,
                    mode='lines',
                    name='predict'))
fig.show()

# COMMAND ----------

t = torch.tensor([[1,2],[3,4],[5,6]])
t

# COMMAND ----------

t = t.permute(1,0)


# COMMAND ----------

u = torch.Tensor([list(t[0]),list(t[1])]).permute(1,0)
u

# COMMAND ----------



# COMMAND ----------

