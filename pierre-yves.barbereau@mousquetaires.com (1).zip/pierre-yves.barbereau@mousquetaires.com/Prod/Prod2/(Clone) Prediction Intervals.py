# Databricks notebook source
pip install quantile-forest

# COMMAND ----------

# MAGIC %run /Tools/library/CFM

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/Prod2/ICF

# COMMAND ----------

# MAGIC %run /Users/pierre-yves.barbereau@mousquetaires.com/Prod/preprocessing

# COMMAND ----------

lib_instance = Cfm()

# COMMAND ----------

#dbutils.widgets.removeAll()

# COMMAND ----------

# ["EncPDV", "DecPDV", "EncUP", "DecUP", "DecPet", "DecTaxAlc", "DecTaxPet", "EncRist", "EncRprox"]

# COMMAND ----------

#Variables widget
groupe = lib_instance.define_widget("groupe") 
quantile_top = float(lib_instance.define_widget('quantile_top'))
quantile_bottom = float(lib_instance.define_widget('quantile_bottom'))

#val_size = float(lib_instance.define_widget("val_size")) #365
cal_size = float(lib_instance.define_widget("cal_size")) # 365
gridsearch = int(lib_instance.define_widget("grid search"))

#PAth notebooks
path_notebook_preproc_preprocessing = lib_instance.define_widget("path_notebook_preproc_preprocessing") #'/Notebooks/Shared/Industrialisation/PrepocFolder/Preprocessing'

# COMMAND ----------

#import libraries
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from lightgbm import LGBMRegressor
from quantile_forest import RandomForestQuantileRegressor
from sklearn.preprocessing import MinMaxScaler
import math
import copy
from datetime import timedelta
from jours_feries_france import JoursFeries
import warnings
from sklearn import preprocessing
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import make_scorer
from itertools import zip_longest
from sklearn.model_selection import TimeSeriesSplit
from sklearn.decomposition import PCA
warnings.filterwarnings("ignore")

# COMMAND ----------

dico_hyperparametres = np.load(f'/dbfs/FileStore/IC_hyperparametres.npy',allow_pickle = True).item()

# COMMAND ----------

alphas = [quantile_bottom,quantile_top] #quantiles

# COMMAND ----------

#/Notebooks/Shared/Industrialisation/PrepocFolder/Preprocessing

# COMMAND ----------

# MAGIC %md
# MAGIC ###Loading Data and preprocessing

# COMMAND ----------

dataloader = Dataloader(path_notebook_preproc_preprocessing = path_notebook_preproc_preprocessing) #load dataloader
df_train_loaded, df_predict_loaded = dataloader.load_train_predict(groupe = groupe) #load data

# COMMAND ----------

df_train, df_predict = df_train_loaded, df_predict_loaded

# COMMAND ----------

groupe = "DecPDV"

# COMMAND ----------

# MAGIC %md
# MAGIC ### Predict

# COMMAND ----------

preproc2 = Preprocessing2(groupe = groupe) #mode PCA 3 a régler en fonction du nombre de dimensions à garder par groupe
df_train_Decpdv = preproc2.preproc(df_train) 

# COMMAND ----------

np.mean(df_train["Valeur"])

# COMMAND ----------

#best model
ci = Conformal_Inference(alphas = alphas,groupe = groupe,cal_size = cal_size, mode = "test") # Initialisation
ci.fit(df_train) # Fit and gridsearch
df_output = ci.predict(df_predict,plot = True) # Prediction

# COMMAND ----------

groupes = ["EncPDV", "DecPDV", "EncUP", "DecUP", "DecPet", "DecTaxAlc", "DecTaxPet", "EncRist", "EncRprox"]

# COMMAND ----------

df_train_loaded_set, df_predict_loaded_set = dataloader.load_train_predict_set(groupes = groupes)

# COMMAND ----------

df_train_loaded_set

# COMMAND ----------

labels = []
hist_data = []
df_train["label"] = preproc2.labels_str
for label in set(preproc2.labels_str):
    if np.sum(df_train_Decpdv['Valeur'][df_train_Decpdv["label"]== label]) != 0:
      hist_data.append(list(df_train_Decpdv['Valeur'][df_train_Decpdv["label"]== label]))
      labels = np.append(labels,label)

# Create distplot with custom bin_size
fig = ff.create_distplot(hist_data, labels, bin_size=1000)
fig.show()

# COMMAND ----------

preproc2.labels_str

# COMMAND ----------

df_train_Decpdv['Valeur'][df_train_Decpdv["label"]== label]

# COMMAND ----------

hist_data

# COMMAND ----------

import plotly.figure_factory as ff
import numpy as np
hist_data = []
labels = []
for groupe, df_train in zip(groupes,df_train_loaded_set):
  preproc2 = Preprocessing2(groupe = groupe) #mode PCA 3 a régler en fonction du nombre de dimensions à garder par groupe
  df_train = preproc2.preproc(df_train,PCA = False) 
  for label in set(df_train["label"]):
    hist_data.append(df_train['Valeur'][df_train["label"]== label])
    labels.append(label)

    # Create distplot with custom bin_size
    fig = ff.create_distplot(hist_data, labels, bin_size=1000)
    fig.show()
