# Databricks notebook source
class Prediction_intervals():
    def __init__(self,alphas, cal_size,groupe,models = ["LGBM","GB","QRF"], test_size = None,val_size = None,mode = "normal",dico_hyperparametres = None,gridsearch = False, param_grid_gb=None, param_grid_lgbm=None ):
        """
        alphas = [quantile_bottom,quantile_up]
        mode = ("normal" ou "test")
        """
        self.models = models
        self.gridsearch = gridsearch
        self.param_grid_gb = param_grid_gb
        self.param_grid_lgbm = param_grid_lgbm
        self.alphas = alphas
        self.confidence = self.alphas[1] - self.alphas[0]
        self.cal_size = cal_size
        self.test_size = test_size
        self.fitted = False
        self.mode = mode
        self.val_size = val_size
        self.adaptative = False
        self.groupe = groupe
        #Initialisation des modèles
        if dico_hyperparametres == None :
            self.dico_hyperparametres = {}
            self.dico_hyperparametres[groupe] = {}
            self.model = IC_model(alphas = self.alphas,groupe= self.groupe,models = self.models,gridsearch = True)
        else : 
            self.dico_hyperparametres = dico_hyperparametres
            self.model = IC_model(alphas = self.alphas,groupe= self.groupe,models = self.models, dico_hyperparametres = self.dico_hyperparametres,param_grid_gb = param_grid_gb,param_grid_lgbm = param_grid_lgbm,gridsearch = self.gridsearch)


    def split_conformal_ic(self,df_train,df_predict = None,plot = True):
        """
        Compute Asymetric Conformal Inference for predict set,
        X_predict = None,plot = False
        return self.pred_down_predict_asymetric_conformal,self.pred_up_predict_asymetric_conformal
        """

        self.target_train = df_train["Valeur"]
        self.df_train = df_train

        # On crée les sets de calibration et de validation
        if self.mode == "normal":
            self.train_cal_split()

        # En mode test on crée les sets de calibration de validation et de test
        if self.mode == "test":
            self.train_cal_test_split()

        #On fit chacun des modèles
        self.model.fit(self.X_train,self.y_train)
        #if self.gridsearch == True:
          #np.save(f'/dbfs/FileStore/IC_hyperparametres.npy',self.model.dico_hyperparametres) 

        #On effectue les prediction sur les sets de calibration et de validation
        self.predict_cal()

        self.X_predict = df_predict
        if self.mode == "test":
            self.X_predict = self.X_test
        #Prediction du set de test
        self.pred_down_predict,self.pred_up_predict,self.pred_median_predict = self.predict_test(self.X_predict)
        self.pred_down = np.empty(0)
        self.pred_up = np.empty(0)
        self.pred_median = np.empty(0)

        for i in range(len(self.X_predict)):
            try:
                self.pred_down = np.append(self.pred_down,self.pred_down_predict[i] - np.quantile(self.f_conformity_score_down(self.pred_down_cal[self.X_cal["label"] == list(self.X_predict["label"])[i]], self.y_cal[self.X_cal["label"] == list(self.X_predict["label"])[i]]),1 - self.alphas[0]))
            except Exception as e:
                print(e)
                self.pred_down = np.append(self.pred_down,self.pred_down_predict[i])
            try:
                self.pred_up = np.append(self.pred_up,self.pred_up_predict[i] + np.quantile(self.f_conformity_score_up(self.pred_up_cal[self.X_cal["label"] == list(self.X_predict["label"])[i]],self.y_cal[self.X_cal["label"] == list(self.X_predict["label"])[i]]),self.alphas[1]))
            except Exception as e:
                print(e)
                self.pred_up = np.append(self.pred_up,self.pred_up_predict[i])
            try:
                self.pred_median = np.append(self.pred_median,self.pred_median_predict[i] + np.quantile(self.f_conformity_score_up(self.pred_median_cal[self.X_cal["label"] == list(self.X_predict["label"])[i]],self.y_cal[self.X_cal["label"] == list(self.X_predict["label"])[i]]),0.5))
            except Exception as e:
                print(e)
                self.pred_median = np.append(self.pred_median,self.pred_median_predict[i])

        if plot:
            self.plot()
        self.X_predict[f"{np.round(self.alphas[0],decimals = 3)}_quantile"] = self.pred_down
        self.X_predict[f"{np.round(self.alphas[1],decimals = 3)}_quantile"] = self.pred_up
        self.X_predict[f"0.5_quantile"] = self.pred_median
        return(self.X_predict)


    def adaptative_ci(self,X_predict = None,plot = False,gamma = 0.1,adaptative_window_length = 50):
        self.gamma = gamma
        self.adaptative_window_length = adaptative_window_length
        self.target_train = df_train["Valeur"]
        self.df_train = df_train

        # On crée les sets de calibration et de validation
        if self.mode == "normal" or self.adaptative:
            self.train_cal_val_split()

        # En mode test on crée les sets de calibration de validation et de test
        if self.mode == "test" and not self.adaptative:
            self.train_cal_val_test_split()

        #On fit chacun des modèles
        self.model.fit(self.X_train,self.y_train)
        #if self.gridsearch == True:
          #np.save(f'/dbfs/FileStore/IC_hyperparametres.npy',self.model.dico_hyperparametres) 

        #On effectue les prediction sur les sets de calibration et de validation
        self.predict_cal_val()
        print("len(self.X_cal) = ",len(self.X_cal))
        print("len(self.y_cal) = ",len(self.y_cal))
        print("conformal fitted")
        self.fitted = True
        self.X_predict = X_predict
        if self.mode == "test":
            self.X_predict = self.X_test
        self.pred_down_predict,self.pred_up_predict,self.pred_median_predict = self.predict_test(self.X_predict)
        #initialize adaptative alphas
        alpha_star_down_updated = self.alphas[0]
        alpha_star_up_updated = self.alphas[1]
        alpha_star_median_updated = 0.5
        pred_down_adaptative = copy.deepcopy(self.pred_down_cal[-len(self.X_predict):])
        pred_up_adaptative = copy.deepcopy(self.pred_up_cal[-len(self.X_predict):])
        pred_median_adaptative = copy.deepcopy(self.pred_median_cal[-len(self.X_predict):])
        y_cal_increased = copy.deepcopy(self.y_cal[-len(self.X_predict):])
        y_val = self.y_val.copy()
        #pred_up_val = self.pred_up_val.copy()
        #pred_down_val = self.pred_down_val.copy()
        pred_median_cal = copy.deepcopy(self.pred_median_cal)
        pred_median_val = copy.deepcopy(self.pred_median_val)

        self.alpha_star_down_updated_list = []
        self.alpha_star_up_updated_list = []
        self.alpha_star_median_updated_list = []
  
        #init alpha star
        try:
            alpha_star_down_updated = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_down(self.pred_down_cal,self.pred_down_val,self.y_cal,self.y_val,alpha = b) < self.alphas[0])])
            alpha_star_up_updated = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_up(self.pred_up_cal,self.pred_up_cal,self.y_cal,self.y_val,alpha = b) < 1 - self.alphas[1])])
            alpha_star_median_updated = np.max([b for b in np.arange(0,1,0.0001) if (self.f_miscoverage_rate_median(self.pred_median_cal,self.pred_median_val,self.y_cal,self.y_val,alpha = b) < 0.5)])
        except ValueError:
            print("no quantile found to cover the shift")
            print("setting default value")
            alpha_star_down_updated = 0.05
            alpha_star_up_updated = 0.95
            alpha_star_median_updated = 0.5

        for it in range(len(self.X_val)):
            #compute alpha star updated
            alpha_star_up_updated = alpha_star_up_updated + self.gamma*(1 - self.alphas[1] - np.sum([self.err_t_up(y_cal_increased,pred_up_adaptative,w)*math.exp(-w) for w in range(self.adaptative_window_length)])/np.sum([math.exp(k) for k in range(self.adaptative_window_length)]))
            alpha_star_down_updated = alpha_star_down_updated + self.gamma*(self.alphas[0] - np.sum([self.err_t_down(y_cal_increased,pred_down_adaptative,w)*math.exp(-w) for w in range(self.adaptative_window_length)])/np.sum([math.exp(k) for k in range(self.adaptative_window_length)]))
            alpha_star_median_updated = alpha_star_median_updated + self.gamma*(0.5 - np.sum([self.err_t_median(y_cal_increased,pred_median_adaptative,w)*math.exp(-w) for w in range(self.adaptative_window_length)])/np.sum([math.exp(k) for k in range(self.adaptative_window_length)]))
            self.alpha_star_down_updated_list.append(alpha_star_down_updated)
            self.alpha_star_up_updated_list.append(alpha_star_up_updated)
            self.alpha_star_median_updated_list.append(alpha_star_median_updated)

            if 0<alpha_star_up_updated <1:
                pred_up_adaptative = np.append(pred_up_adaptative,self.pred_up_val[it] + np.quantile(self.f_conformity_score_up(self.y_cal,self.pred_up_cal),1-alpha_star_up_updated))
            elif alpha_star_up_updated <= 0:
                pred_up_adaptative = np.append(pred_up_adaptative,self.pred_up_val[it] + np.min(self.f_conformity_score_up(self.y_cal,self.pred_up_cal)))
                alpha_star_up_updated = 0.001
                print(f" i = {it} alpha_star_up_updated < 0")
            elif alpha_star_up_updated >=1:
                pred_up_adaptative = np.append(pred_up_adaptative,self.pred_up_val[it] + np.max(self.f_conformity_score_up(self.y_cal,self.pred_up_cal)))
                alpha_star_up_updated = 0.999
                print(f" i = {it} alpha_star_up_updated >1")
                
          #lower bound 
            if 0<alpha_star_down_updated <1:
                pred_down_adaptative = np.append(pred_down_adaptative,self.pred_down_val[it] - np.quantile(self.f_conformity_score_down(self.y_cal,self.pred_up_cal),1-alpha_star_down_updated))
            elif alpha_star_down_updated <= 0:
                pred_down_adaptative = np.append(pred_down_adaptative,self.pred_down_val[it] - np.max(self.f_conformity_score_down(self.y_cal,self.pred_up_cal)))
                alpha_star_down_updated = 0.001
                print(f" i = {it} alpha_star_down_updated < 0")
            elif alpha_star_down_updated >=1:
                pred_down_adaptative = np.append(pred_down_adaptative,self.pred_down_val[it] - np.min(self.f_conformity_score_down(self.y_cal,self.pred_up_cal)))
                alpha_star_down_updated = 0.999
                print(f" i = {it} alpha_star_down_updated >1")
                
          #Median 
            if 0<alpha_star_median_updated <1:
                pred_median_adaptative = np.append(pred_median_adaptative,self.pred_median_val[it] - np.quantile(self.f_conformity_score_median(self.y_cal,self.pred_up_cal),1-alpha_star_median_updated))
            elif alpha_star_median_updated <= 0:
                pred_median_adaptative = np.append(pred_median_adaptative,self.pred_median_val[it] - np.max(self.f_conformity_score_median(self.y_cal,self.pred_up_cal)))
                alpha_star_median_updated = 0.1
                print(f" i = {it} alpha_star_down_updated < 0")
            elif alpha_star_median_updated >=1:
                pred_median_adaptative = np.append(pred_median_adaptative,self.pred_median_val[it] - np.min(self.f_conformity_score_median(self.y_cal,self.pred_up_cal)))
                alpha_star_median_updated = 0.9
                print(f" i = {it} alpha_star_down_updated >1")

            y_cal_increased = np.append(y_cal_increased,self.y_val[it])
            y_cal_increased = np.delete(y_cal_increased,0)
            pred_up_adaptative = np.delete(pred_up_adaptative,0)
            pred_down_adaptative = np.delete(pred_down_adaptative,0)
            pred_median_adaptative = np.delete(pred_median_adaptative,0)
            print(it , "alpha_star_down_updated : ",alpha_star_down_updated)
            print(it , "alpha_star_up_updated : ",alpha_star_up_updated)
            print(it , "alpha_star_median_updated : ",alpha_star_median_updated)

        if self.mode =="normal":
            pred_down_adaptative = self.pred_down_predict - np.quantile(self.f_conformity_score_down(self.y_cal,self.pred_up_cal), 1-alpha_star_down_updated)
            pred_up_adaptative = self.pred_up_predict + np.quantile(self.f_conformity_score_up(self.y_cal,self.pred_up_cal),1-alpha_star_up_updated)
            pred_median_adaptative = self.pred_median_predict - np.quantile(self.f_conformity_score_median(self.y_cal,self.pred_up_cal),1-alpha_star_median_updated)
        
        self.pred_up = pred_up_adaptative
        self.pred_down = pred_down_adaptative
        self.pred_median = pred_median_adaptative
        if plot:
            self.plot()
        return(self.pred_down,self.pred_up,self.pred_median)
    
    def FACI(self,alphas,sigma, eta,gammas : list,alphas_i : list,X_predict = None,plot = True):
        self.alphas = alphas
        """Perform a fully adaptative ACI"""
        self.alphas_i = alphas_i
        self.target_train = df_train["Valeur"]
        self.df_train = df_train

        # On crée les sets de calibration et de validation
        if self.mode == "normal":
            self.train_cal_val_split()

        # En mode test on crée les sets de calibration de validation et de test
        if self.mode == "test":
            self.train_cal_val_test_split()

        #On fit chacun des modèles
        self.model.fit(self.X_train,self.y_train)

        #On effectue les prediction sur les sets de calibration et de validation
        self.predict_cal_val()
        print("len(self.X_cal) = ",len(self.X_cal))
        print("len(self.y_cal) = ",len(self.y_cal))
        print("conformal fitted")
        if self.mode == "test":
            self.X_predict = self.X_test
        self.pred_down_predict,self.pred_up_predict,self.pred_median_predict = self.predict_test(self.X_predict)
        
        ## FACI UP
        p_values = [np.max([b for b in np.arange(0,1,0.001) if (self.pred_up_val[t] + np.quantile(self.f_conformity_score_up(self.pred_up_cal,self.y_cal),1-b))>=list(self.y_val)[t] ]) for t in range(len(self.pred_up_val))]
        k = len(p_values)
        omegas = np.ones(len(gammas))
        pred_up = []
        for t in range(k):
            p = omegas / np.sum(omegas)
            alpha_barre = np.dot(p,alphas_i)
            pred_up.append(alpha_barre)
            omegas_barre = []
            for i in range(len(alphas_i)):
                omegas_barre.append(omegas[i]*np.exp(-eta*(self.alphas[1]*(p_values[t]-alphas_i[i]) - min(0,p_values[t]-alphas_i[i]))))
            omegas = (np.multiply((1-sigma),omegas_barre) + np.mean(omegas_barre)*sigma)
            err_t_i = [(self.pred_up_cal[t] + np.quantile(self.f_conformity_score_up(self.pred_up_cal,self.y_cal),1-alpha_i))>list(self.y_cal)[t] for alpha_i in alphas_i]
            for i in range(len(alphas_i)):
                alphas_i[i] = max(0,min(1,alphas_i[i] + gammas[i]*(self.alphas[1] - err_t_i[i])))
        self.pred_up = self.pred_up_predict + np.quantile(self.f_conformity_score_up(self.pred_up_cal,self.y_cal),alpha_barre)
        
        ## FACI Down
        alphas_i = self.alphas_i
        p_values = [np.max([b for b in np.arange(0,1,0.001) if (self.pred_down_val[t] - np.quantile(self.f_conformity_score_down(self.pred_down_cal,self.y_cal),1-b))<=list(self.y_val)[t] ]) for t in range(len(self.pred_up_val))]
        k = len(p_values)
        omegas = np.ones(len(gammas))
        pred_down = []
        for t in range(k):
            p = omegas / np.sum(omegas)
            alpha_barre = np.dot(p,alphas_i)
            pred_down.append(alpha_barre)
            omegas_barre = []
            for i in range(len(alphas_i)):
                omegas_barre.append(omegas[i]*np.exp(-eta*(self.alphas[0]*(p_values[t]-alphas_i[i]) - min(0,p_values[t]-alphas_i[i]))))
            omegas = (np.multiply((1-sigma),omegas_barre) + np.mean(omegas_barre)*sigma)
            err_t_i = [(self.pred_up_cal[t] - np.quantile(self.f_conformity_score_down(self.pred_down_cal,self.y_cal),1-alpha_i))>list(self.y_cal)[t] for alpha_i in alphas_i]
            for i in range(len(alphas_i)):
                alphas_i[i] = max(0,min(1,alphas_i[i] + gammas[i]*(self.alphas[0] - err_t_i[i])))
        
        self.pred_down = self.pred_down_predict - np.quantile(self.f_conformity_score_down(self.pred_down_cal,self.y_cal),1-alpha_barre)
        if plot:
            self.plot()
        return(self.pred_up,self.pred_down)
    
    
    def AgACI(self, gammas : list, window = 20): #Aggregative ACI
        """perform an aggregation of multiples ACI"""
        self.alphas = alphas
        """Perform a fully adaptative ACI"""
        self.alphas_i = alphas_i
        self.target_train = df_train["Valeur"]
        self.df_train = df_train

        # On crée les sets de calibration et de validation
        if self.mode == "normal":
            self.train_cal_val_split()

        # En mode test on crée les sets de calibration de validation et de test
        if self.mode == "test":
            self.train_cal_val_test_split()

        #On fit chacun des modèles
        self.model.fit(self.X_train,self.y_train)

        #On effectue les prediction sur les sets de calibration et de validation
        self.predict_cal_val()
        print("len(self.X_cal) = ",len(self.X_cal))
        print("len(self.y_cal) = ",len(self.y_cal))
        print("conformal fitted")
        if self.mode == "test":
            self.X_predict = self.X_test
        self.pred_down_predict,self.pred_up_predict,self.pred_median_predict = self.predict_test(self.X_predict)
        
        for t in y_test_2:
            low_t = []
            high_t = []
            omega_t_low = []
            omega_t_high = []
            low = pred_down_test_2 - np.quantile(f_conformity_score_low(pred_down_test_1,y_test_1),1-alpha_star_low_updated)
            high = pred_up_test_2 + np.quantile(f_conformity_score_high(pred_up_test_1,y_test_1),alpha_star_high_updated)
            for gamma in gammas:
                alpha_star_low_upd = alpha_star_low_updated + gamma*(alphas[0] - np.mean([err_t_low(y_test_1,pred_down_test_1,i) for i in range(window)]))
                if 0<alpha_star_low_upd <1:
                    low = pred_down_test_2 - np.quantile(f_conformity_score_low(pred_down_test_1,y_test_1),1-alpha_star_low_upd)
                else :
                    print("alpha_star_low_updated out of 0-1")
                    alpha_star_high_upd = alpha_star_high_updated + gamma*(1-alphas[1] - np.mean([err_t_high(y_test_1,pred_up_test_1,i) for i in range(window)]))
                if 0<alpha_star_high_upd <1:
                    high = pred_up_test_2 + np.quantile(f_conformity_score_high(pred_up_test_1,y_test_1),alpha_star_high_upd)
                else :
                    print("alpha_star_high_updated out of 0-1")
                low_t.append(low)
                high_t.append(high)
                C_low = np.mean(low_t,axis = 0)
                C_high = np.mean(high_t,axis = 0)
            return C_low,C_high
        
        
    def enbpi(self,model,df_train,alphas,df_predict=None,n_bootstrap = 100,bach_size = 1):
        """
        Perform a bootstrap method to construct an interval for prediction model
        model = regression model
        """
        # En mode test on crée les sets de calibration de validation et de test
        if self.mode == "test":
            self.df_train,self.df_predict = train_test_split(df_train,test_size = 0.2)
        self.n_bootstrap = n_bootstrap
        self.batch_size = batch_size
        self.confidence = alphas[1]-alphas[0]
        self.model = model
        self.X_train=self.df_train.drop(["Valeur","DT_VALR"],axis = 1)
        self.y_train = self.df_train["Valeur"]
        self.T = len(self.df_train)
        self.len_train = len(self.df_train)
        self.S_b = []
        self.f_b = []
        
        #On effectue les prédictions bootstrap
        for b in range(self.n_bootstrap):
            print("1/3 Train 1/2 : ",int(100*b/self.n_bootstrap),"%")
            self.S_b.append(np.random.choice(list(self.X_train.index),self.T,replace = True))
            self.f_b.append(self.model.fit(self.X_train.loc[self.S_b[-1]],np.take(self.y_train, self.S_b[-1])))
        self.eps =[]
        self.f_phi_i = []
        
        for i in range(self.len_train):
            print("2/3 train 2/2 : ",int(100*i/self.len_train),"%")
            self.f_phi_temp = []
            for bi,b in enumerate(self.S_b):
                if i not in b:
                      self.f_phi_temp.append(self.f_b[bi].predict(self.X_train.iloc[i:i+1]))
            self.f_phi_i.append(np.mean(self.f_phi_temp))
            self.eps_phi_i = np.abs(self.y_train[i]-self.f_phi_i[i])
            if math.isnan(self.eps_phi_i) == False:
                self.eps.append(self.eps_phi_i)
        self.X_test = df_predict.drop(["DT_VALR"],axis = 1)
        self.len_test = len(self.X_test)
        self.C_t_low = []
        self.C_t_high = []
        self.f_phi_t = [] 
        for t in range(len(self.X_test)):
            print(t,"/",self.len_test)
            print(int(100*t/self.len_test),"%")
            self.f_phi_temp = []
            for bi,b in enumerate(self.S_b):
                if t not in b:
                    self.f_phi_temp.append(self.f_b[bi].predict(self.X_test.iloc[t:t+1]))
            self.f_phi_t.append(np.quantile(self.f_phi_temp,self.confidence))
            self.w_phi_t = np.quantile(self.eps,self.confidence)
            self.C_t_low.append(self.f_phi_t - self.w_phi_t)
            self.C_t_high.append(self.f_phi_t + self.w_phi_t)
          
        if t % self.batch_size == 0:
            for j in range(self.batch_size):
                self.e_phi_j = float(np.abs(self.y_test[j]-self.f_phi_t[j]))
                self.eps.append(self.e_phi_j)
                del self.eps[0]
        
        return self.C_t_low, self.C_t_high

    def train_cal_split(self):
        if self.cal_size < 1:
            cal_size = int(self.cal_size*len(self.df_train))
        else : 
            cal_size = int(self.cal_size)
        "split data into train, calibration, used in normal mode"
        self.X_train, self.X_cal , self.y_train, self.y_cal = train_test_split(self.df_train, self.target_train,test_size = cal_size,shuffle = False)
        self.xX_train = self.X_train["DT_VALR"]
        self.X_train = self.X_train.drop(["DT_VALR","Valeur"],axis = 1)
        self.xX_cal = self.X_cal["DT_VALR"]
        self.X_cal = self.X_cal.drop(["DT_VALR","Valeur"], axis = 1)
        #return self.xX_train, self.xX_cal, self.xX_val, self.xX_test, self.X_train, self.X_cal, self.X_val, self.X_test, self.y_train, self.y_cal, self.y_val, self.y_test
        self.y_train = np.array(self.y_train)
        self.y_cal = np.array(self.y_cal)


    def train_cal_test_split(self):
        """
        split data into train, calibration validation and test set, used in test mode
        return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_val,self.X_val, self.y_val, self.xX_test, self.X_test, self.y_test
        """
        if self.cal_size <= 1:
            cal_size = int(self.cal_size*len(self.df_train))
        else : 
            cal_size = int(self.cal_size)

        if self.test_size == None :
            test_size = cal_size
        else : 
            test_size = test_size

        self.X_train, self.X_test , self.y_train, self.y_test = train_test_split(self.df_train, self.target_train,test_size = test_size,shuffle = False)
        self.X_train, self.X_cal , self.y_train, self.y_cal = train_test_split(self.X_train, self.y_train,test_size = cal_size,shuffle = False)
        self.xX_train = self.X_train["DT_VALR"]
        self.X_train = self.X_train.drop(["DT_VALR","Valeur"],axis = 1)
        self.xX_cal = self.X_cal["DT_VALR"]
        self.X_cal = self.X_cal.drop(["DT_VALR","Valeur"], axis = 1)
        self.xX_test = self.X_test["DT_VALR"]
        self.X_test = self.X_test.drop(["DT_VALR","Valeur"], axis = 1)
        self.y_train = np.array(self.y_train)
        self.y_cal = np.array(self.y_cal)
        print("train_size = ", self.X_train.shape[0])
        return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_test, self.X_test, self.y_test

    def train_cal_val_test_split(self):
        """
        split data into train, calibration validation and test set, used in test mode
        return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_val,self.X_val, self.y_val, self.xX_test, self.X_test, self.y_test
        """
        cal_size = int(self.cal_size*len(self.df_train))
        val_size = int(self.val_size*len(self.df_train))
        if self.test_size == None :
            test_size = int(self.val_size*len(self.df_train))
        else :
            test_size = int(self.test_size*len(self.df_train))
        self.X_train, self.X_test , self.y_train, self.y_test = train_test_split(self.df_train, self.target_train,test_size = test_size,shuffle = False)
        self.X_train, self.X_val , self.y_train, self.y_val = train_test_split(self.X_train, self.y_train,test_size = val_size,shuffle = False)
        self.X_train, self.X_cal , self.y_train, self.y_cal = train_test_split(self.X_train, self.y_train,test_size = cal_size,shuffle = False)
        self.xX_train = self.X_train["DT_VALR"]
        self.X_train = self.X_train.drop(["DT_VALR","Valeur"],axis = 1)
        self.xX_cal = self.X_cal["DT_VALR"]
        self.xX_val = self.X_val["DT_VALR"]
        self.X_cal = self.X_cal.drop(["DT_VALR","Valeur"], axis = 1)
        self.X_val = self.X_val.drop(["DT_VALR","Valeur"], axis = 1)
        self.xX_test = self.X_test["DT_VALR"]
        self.X_test = self.X_test.drop(["DT_VALR","Valeur"], axis = 1)
        self.y_train = list(self.y_train)
        self.y_cal = list(self.y_cal)
        self.y_val = list(self.y_val)
        self.X_calval = pd.concat([self.X_cal,self.X_val], sort = False)
        self.y_calval = list(self.y_cal) + list(self.y_val)
        print("train_size = ", self.X_train.shape[0])
        return self.xX_train, self.X_train, self.y_train, self.xX_cal, self.X_cal, self.y_cal, self.xX_val,self.X_val, self.y_val, self.xX_test, self.X_test, self.y_test

    def predict_cal_val(self):
        "predict on calibration and validation set"
        pred_cal = self.model.predict(self.X_cal)
        pred_val = self.model.predict(self.X_val)
        self.pred_down_cal = np.array(pred_cal[0])
        self.pred_up_cal = np.array(pred_cal[1])
        self.pred_median_cal = np.array(pred_cal[2])
        self.pred_down_val = np.array(pred_val[0])
        self.pred_up_val = np.array(pred_val[1])
        self.pred_median_val = np.array(pred_val[2])


    def predict_cal(self):
        "predict on calibration and validation set"
        pred_cal = self.model.predict(self.X_cal)
        self.pred_down_cal = np.array(pred_cal[0])
        self.pred_up_cal = np.array(pred_cal[1])
        self.pred_median_cal = np.array(pred_cal[2])

    def predict_test(self,X):
        "predict on predict_set"
        #Initialisation des predictions
        predict = self.model.predict(X)
        #Aggregation des predictions
        pred_down = np.array(predict[0])
        pred_up = np.array(predict[1])
        pred_median = np.array(predict[2])
        return(pred_down,pred_up,pred_median)
    
    def plot(self):
        #Show plot pred test 
        if self.mode == "normal":
            fig = go.Figure()
            fig.add_trace(go.Scatter( y=self.pred_up,
                          mode='lines',
                          name=f'q_{alphas[1]}',
                          line=dict(
                              color='rgb(0, 256, 0)',
                              width=0),
                          showlegend = False))

            fig.add_trace(go.Scatter( y=self.pred_down,
                          mode='lines',
                          name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                          line=dict(
                              color='rgb(0, 256, 0)',
                              width=0),
                          fill='tonexty',
                          fillcolor='rgba(0,176,246,0.2)',
                          line_color='rgba(255,255,255,0)'))
      
            fig.add_trace(go.Scatter( y=self.pred_median,
                        mode='lines',
                        name=f'y_median',
                        line=dict(
                            color='rgb(256,0, 0)',
                            width=1),
                        showlegend = True))

            fig.update_layout(title = f"{self.groupe}, {int(np.round(100*self.confidence))}% confidence prediction interval")
            fig.show()

        if self.mode == "test":
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=self.xX_test, y=self.y_test,
                        mode='lines',
                        name=f'y_true',
                        line=dict(
                            color='rgb(0,0, 256)',
                            width=1),
                        showlegend = True))

            fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_up,
                          mode='lines',
                          name=f'q_{alphas[1]}',
                          line=dict(
                              color='rgb(0, 256, 0)',
                              width=0),
                          showlegend = False))

            fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_down,
                          mode='lines',
                          name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                          line=dict(
                              color='rgb(0, 256, 0)',
                              width=0),
                          fill='tonexty',
                          fillcolor='rgba(0,176,246,0.2)',
                          line_color='rgba(255,255,255,0)'))
            """
            fig.add_trace(go.Scatter(x=self.xX_test, y=self.pred_median,
                        mode='lines',
                        name=f'y_median',
                        line=dict(
                            color='rgb(256,0, 0)',
                            width=1),
                        showlegend = True))
            """

            error = (np.sum(self.y_test<self.pred_down) + np.sum(self.y_test>self.pred_up))/len(self.y_test)
            fig.update_traces(mode='lines')
            fig.update_layout(title = f"Test : {self.groupe}, {1-error}% confidence")                      
            fig.show()


    def f_conformity_score(self,pred_down_cal,pred_up_cal,y_cal):
        """
        Compute the symetric conformity score
        """
        return np.max([pred_down_cal-y_cal,y_cal-pred_up_cal],axis = 0)
  
    def f_conformity_score_down(self,pred_down_cal,y_cal):
        """
        Compute the asymetric conformity score for down bound
        """
        return [pred_down_cal-y_cal]

    def f_conformity_score_up(self,pred_up_cal,y_cal):
        """
        Compute the asymetric conformity score for upper bound
        """
        return [y_cal-pred_up_cal]
  
    def f_conformity_score_median(self,pred_median_cal,y_cal):
        """
        Compute the asymetric conformity score for upper bound
        """
        return [pred_median_cal-y_cal]
  
    def f_miscoverage_rate(self,pred_down_cal,pred_up_cal,pred_down_val,pred_up_val,y_cal,y_val,alpha):
        """
        Compute the miscoverage rate
        """
        csq = np.quantile(self.f_conformity_score(pred_down_cal,pred_up_cal,y_cal),1-alpha)
        return(np.sum(np.max([pred_down_val-y_val,y_val-pred_up_val],axis = 0)>csq)/len(y_val))

    def f_miscoverage_rate_down(self,pred_down_cal,pred_down_val,y_cal,y_val,alpha):
        """
        Compute the asymetric miscoverage rate for down bound
        """
        csq_low = np.quantile(self.f_conformity_score_down(pred_down_cal,y_cal),1-alpha)
        return(np.sum((pred_down_val-y_val)>csq_low)/len(y_val))

    def f_miscoverage_rate_median(self,pred_median_cal,pred_median_val,y_cal,y_val,alpha):
        """
        Compute the asymetric miscoverage rate for median bound
        """
        csq_median = np.quantile(self.f_conformity_score_median(pred_median_cal,y_cal),1-alpha)
        return(np.sum((pred_median_val-y_val)>csq_median)/len(y_val))

    def f_miscoverage_rate_up(self,pred_up_cal,pred_up_val,y_cal,y_val,alpha):
        """
        Compute the asymetric miscoverage rate for upper bound
        """
        csq_up = np.quantile(self.f_conformity_score_up(pred_up_cal,y_cal),1 - alpha)
        return(np.sum((y_val-pred_up_val)>csq_up)/len(y_val))
    
    def err_t(self,y_true,pred_up,pred_down,t):
        """
        Compute the adaptative error of adaptative conformal inference at time t
        """
        return (list(y_true)[-t]>list(pred_up)[-t] or list(y_true)[-t]<list(pred_down)[-t])

    def err_t_down(self,y_true,pred_down,t):
        """
        Compute the adaptative error of asymetric adaptative conformal inference for down bound at time t
        """
        return list(y_true)[-t]<=list(pred_down)[-t]

    def err_t_up(self,y_true,pred_up,t):
        """
        Compute the adaptative error of asymetric adaptative conformal inference for upper down bound at time t
        """
        return list(y_true)[-t]>=list(pred_up)[-t]
  
    def err_t_median(self,y_true,pred_median,t):
        """
        Compute the adaptative error of asymetric adaptative conformal inference for down bound at time t
        """
        return list(y_true)[-t]<=list(pred_median)[-t]
    
    


# COMMAND ----------

class IC_model: #prediction models
    def __init__(self,alphas,groupe,models = ["GB","LGBM","QRF"],dico_hyperparametres = None,gridsearch = None, param_grid_gb=None, param_grid_lgbm=None,n_fold_gridsearch = 3):
        self.models = models
        self.alphas = alphas
        self.confidence = self.alphas[1]-self.alphas[0]
        self.model_down_set = []
        self.model_up_set = []
        self.model_median_set = []
        self.groupe = groupe
        self.dico_hyperparametres = dico_hyperparametres
        self.gridsearch = gridsearch
        self.param_grid_gb=param_grid_gb
        self.param_grid_lgbm=param_grid_lgbm
        self.n_folds_gridsearch = n_fold_gridsearch  



    def fit(self,df_train,y=None):
        
        if y is not None :
            self.y_train = y
            self.X_train = df_train
        else:
            self.y_train = df_train["Valeur"]
            self.index_train = df_train["DT_VALR"]
            self.X_train = df_train.drop(["Valeur","DT_VALR"],axis = 1)
        """
        Fit the model
        """
        if self.dico_hyperparametres == None:
            self.dico_hyperparametres = {}
            self.dico_hyperparametres[self.groupe] = {}
            self.dico_hyperparametres[self.groupe]["LGBM"] = {}
            self.dico_hyperparametres[self.groupe]["GB"] = {}
            self.dico_hyperparametres[self.groupe]["QRF"] = {}
        
        for model in self.models:

            if model == "GB":
                try :
                  self.model_down_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[0],**self.dico_hyperparametres[self.groupe]["GB"]["down"]))
                  self.model_up_set.append(GradientBoostingRegressor(loss="quantile", alpha=alphas[1],**self.dico_hyperparametres[self.groupe]["GB"]["up"]))
                  self.model_median_set.append(GradientBoostingRegressor(loss="quantile", alpha=0.5,**self.dico_hyperparametres[self.groupe]["GB"]["median"]))

                except :
                  self.model_down_set.append(GradientBoostingRegressor(loss="quantile", alpha=self.alphas[0]))
                  self.model_up_set.append(GradientBoostingRegressor(loss="quantile", alpha=self.alphas[1]))
                  self.model_median_set.append(GradientBoostingRegressor(loss="quantile", alpha=0.5))#self.model_down_set.append(LGBMRegressor(alpha=self.alphas[0],  objective='quantile',**self.dico_hyperparametres[self.groupe]["LGBM"]["down"]))

            if model == "LGBM":
                try :
                    self.model_up_set.append(LGBMRegressor(alpha=self.alphas[1],  objective='quantile',**self.dico_hyperparametres[self.groupe]["LGBM"]["up"]))
                    self.model_up_set.append(LGBMRegressor(alpha=self.alphas[0],  objective='quantile',**self.dico_hyperparametres[self.groupe]["LGBM"]["down"]))
                    self.model_median_set.append(LGBMRegressor(alpha=0.5,  objective='quantile',**self.dico_hyperparametres[self.groupe]["LGBM"]["median"]))

                except:
                    self.model_down_set.append(LGBMRegressor(alpha=self.alphas[0],  objective='quantile'))
                    self.model_up_set.append(LGBMRegressor(alpha=self.alphas[1],  objective='quantile'))
                    self.model_median_set.append(LGBMRegressor(alpha=0.5,  objective='quantile'))

            if model == 'QRF':
                    self.qrf =  RandomForestQuantileRegressor( min_samples_leaf = int(math.log(len(df_train))), n_estimators = 128,max_depth = 5)
                    self.qrf.fit(self.X_train,self.y_train)
                    
        if self.gridsearch:
            self.gridsearchCV(self.X_train,self.y_train)

        for i in range(len(self.model_down_set)):
            self.model_down_set[i] = self.model_down_set[i].fit(self.X_train,self.y_train)
            self.model_up_set[i] = self.model_up_set[i].fit(self.X_train,self.y_train)
            self.model_median_set[i] = self.model_median_set[i].fit(self.X_train,self.y_train)
          #self.qrf.fit(self.X_train,self.y_train)
        self.fitted = True
        print("IC_fitted")

    def predict(self,df_test,plot = False):
        "predict on predict_set"
        X = df_test
        self.pred_down_set = []
        self.pred_up_set = []
        self.pred_median_set = []

        for _ in range(len(self.model_down_set)):
            try:
                self.pred_down_set.append(self.model_down_set[_].predict(X))
                self.pred_up_set.append(self.model_up_set[_].predict(X))
                self.pred_median_set.append(self.model_median_set[_].predict(X))
            except:
                pass
            
        if "QRF" in self.models:
            self.pred_down_set.append(self.qrf.predict(X,quantiles = self.alphas[0]))
            self.pred_up_set.append(self.qrf.predict(X,quantiles = self.alphas[1]))
            self.pred_median_set.append(self.qrf.predict(X,quantiles = 0.5))


        self.pred_down = np.mean(self.pred_down_set,axis = 0)
        self.pred_up = np.mean(self.pred_up_set,axis = 0)
        self.pred_median = np.mean(self.pred_median_set,axis = 0)

        if plot :
            self.plot()
        return(self.pred_down,self.pred_up,self.pred_median)
  
    def plot(self):
        fig = go.Figure()
        fig.add_trace(go.Scatter( y=self.pred_up,
                        mode='lines',
                        name=f'q_{alphas[1]}',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        showlegend = False))

        fig.add_trace(go.Scatter( y=self.pred_down,
                        mode='lines',
                        name=f'{int(np.round(100*(self.alphas[1]-self.alphas[0])))}% Confidence Interval',
                        line=dict(
                            color='rgb(0, 256, 0)',
                            width=0),
                        fill='tonexty',
                        fillcolor='rgba(0,176,246,0.2)',
                        line_color='rgba(255,255,255,0)'))

        fig.add_trace(go.Scatter( y=self.pred_median,
                      mode='lines',
                      name=f'y_median',
                      line=dict(
                          color='rgb(256,0, 0)',
                          width=1),
                      showlegend = True))
        fig.update_layout(title = f"{int(np.round(100*self.confidence))} Prediction interval")
        fig.show()
  
  
    def gridsearchCV(self,X = None,y = None): #GridSearchCV
        self.dico_hyperparametres[self.groupe] = {}
        if self.param_grid_gb == None:
            self.param_grid_gb = {'n_estimators': [10,50,100,300,500,1000],
                                          'learning_rate' : [0.001,0.01,0.1,],
                                          'max_depth' : [50,100,200]
                              }
        if self.param_grid_lgbm == None :
            self.param_grid_lgbm = {'n_estimators': [10,50,100,300,500,1000],
                                          'learning_rate' : [0.001,0.01,0.1]
                              }
        self.model_down_set = []
        self.model_up_set = []
        self.model_median_set = []

        #GradientBoosting gridsearch
        scorer_up = make_scorer(ACE_up, alpha_up=self.alphas[1])
        scorer_down = make_scorer(ACE_down, alpha_down=self.alphas[0])
        scorer_median = make_scorer(ACE_up, alpha_up=0.5)

        if "GB" in self.models:
            print("GridSearchCV Gradient_boosting down")
            print("param_grid = ", self.param_grid_gb)
            self.dico_hyperparametres[self.groupe]["GB"] = {}
            GB_down = GridSearchCV(
                                  estimator=GradientBoostingRegressor(loss="quantile", alpha=self.alphas[0]),
                                  param_grid=self.param_grid_gb,
                                  scoring=scorer_down,
                                  cv=TimeSeriesSplit(self.n_folds_gridsearch),
                                  n_jobs=-1,
                                  verbose=1
            )
            self.model_down_set.append(GB_down.fit(X, y).best_estimator_)
            print("GB_down.best_params = ", GB_down.best_params_)
            self.dico_hyperparametres[self.groupe]["GB"]["down"] = GB_down.best_params_

            print("GridSearchCV Gradient_boosting up")
            GB_up = GridSearchCV(
                                  estimator=GradientBoostingRegressor(loss="quantile", alpha=self.alphas[1]),
                                  param_grid=self.param_grid_gb,
                                  cv=TimeSeriesSplit(self.n_folds_gridsearch),
                                  scoring=scorer_up,
                                  n_jobs=-1,
                                  verbose=1
            )
            self.model_up_set.append(GB_up.fit(X, y).best_estimator_)
            print("GB_up.best_params = ", GB_up.best_params_)
            self.dico_hyperparametres[self.groupe]["GB"]["up"] = GB_up.best_params_

            print("GridSearchCV Gradient_boosting median")
            GB_median = GridSearchCV(
                                  estimator=GradientBoostingRegressor(loss="quantile", alpha=0.5),
                                  param_grid=self.param_grid_gb,
                                  cv=TimeSeriesSplit(self.n_folds_gridsearch),
                                  scoring=scorer_median,
                                  n_jobs=-1,
                                  verbose=1
            )
            self.model_median_set.append(GB_median.fit(X, y).best_estimator_)
            print("GB_median.best_params = ", GB_median.best_params_)
            self.dico_hyperparametres[self.groupe]["GB"]["median"] = GB_median.best_params_

        if "LGBM" in self.models:

            #LGBM gridsearch
            self.dico_hyperparametres[self.groupe]["LGBM"] = {}
            print("GridSearchCV LGBM down")
            print("param_grid = ", self.param_grid_lgbm)
            LGBM_down = GridSearchCV(
                                  estimator=LGBMRegressor(alpha=self.alphas[0],  objective='quantile'),
                                  param_grid= self.param_grid_lgbm,
                                  cv=TimeSeriesSplit(self.n_folds_gridsearch),
                                  scoring=scorer_down,
                                  n_jobs=-1,
                                  verbose=1
            )
            self.model_down_set.append(LGBM_down.fit(X, y).best_estimator_)
            print("LGBM_down.best_params = ", LGBM_down.best_params_)
            self.dico_hyperparametres[self.groupe]["LGBM"]["down"] =  LGBM_down.best_params_

            print("GridSearchCV LGBM up")
            LGBM_up = GridSearchCV(
                                  estimator=LGBMRegressor(alpha=self.alphas[1],  objective='quantile'),
                                  param_grid= self.param_grid_lgbm,
                                  cv=TimeSeriesSplit(self.n_folds_gridsearch),
                                  scoring=scorer_up,
                                  n_jobs=-1,
                                  verbose=1
            )
            self.model_up_set.append(LGBM_up.fit(X, y).best_estimator_)
            print("LGBM_up.best_params = ", LGBM_up.best_params_)
            self.dico_hyperparametres[self.groupe]["LGBM"]["up"] =  LGBM_up.best_params_

            print("GridSearchCV LGBM median")
            LGBM_median = GridSearchCV(
                                  estimator=LGBMRegressor(alpha=0.5,  objective='quantile'),
                                  param_grid= self.param_grid_lgbm,
                                  cv=TimeSeriesSplit(self.n_folds_gridsearch),
                                  scoring=scorer_median,
                                  n_jobs=-1,
                                  verbose=1
            )
            self.model_median_set.append(LGBM_median.fit(X, y).best_estimator_)
            print("LGBM_median.best_params = ", LGBM_median.best_params_)
            self.dico_hyperparametres[self.groupe]["LGBM"]["median"] =  LGBM_median.best_params_


        print("GridSearch Terminated")

# COMMAND ----------

def mqloss(y_true, y_pred, alpha):  #Pinball loss
    if (alpha > 0) and (alpha < 1):
        residual = y_true - y_pred 
        return np.mean(residual * (alpha - (residual<0)))
    else:
        return np.nan

# COMMAND ----------

def ACE_up(y_true,pred_up,alpha_up): #Average Coverage Error Up
    return(np.abs(np.mean([y_true[i]<=pred_up[i] for i in range(len(y_true))]) - (alphas[1])))
    

# COMMAND ----------

def ACE_down(y_true,pred_down,alpha_down): #Average Coverage Error Down
    return(np.abs(np.mean([pred_down[i]<=y_true[i] for i in range(len(y_true))]) - (1-alphas[0])))
    

# COMMAND ----------

def integral_score(up,down): #Calcule en millions l'efficience moyenne d'un intervalle
  return(np.sum(np.abs(np.array(up)-np.array(down))/(1000000*len(np.array(down)))))